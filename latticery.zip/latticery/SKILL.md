---
name: latticery
description: Draw diagrams as a single self-contained HTML file (works offline, light/dark theme) from a plain-language request. Supports architecture (people, apps, services, databases, queues, external services, network boundaries), sequence (calls, replies and async messages in order, with alt/opt/loop blocks), workflow (who does what in which order, with swimlanes, decisions and rework), data flow (which data moves from sources through processing and storage to users) and lifecycle diagrams (the states one thing goes through, with waits, retries and endings). You write a small JSON file; the bundled scripts size the boxes, route the lines, validate and build the HTML. Use when the user asks to draw or visualize one of these, e.g. 「構成図を描いて」「アーキテクチャ図」「インフラ構成図」「シーケンス図」「API の呼び出しの流れ」「業務フロー」「ワークフロー図」「申請から承認までの流れ」「データフロー図」「データの流れ」「データパイプライン」「ETL の流れ」「ステータス遷移」「状態遷移図」「ライフサイクル」. If the user's own words do not say which kind (e.g. just "draw the flow" or "how an order moves along"), ask which kind before drawing.
compatibility: Validation and building use Node.js, Deno or Bun when available. Without them, bin/build.sh (macOS/Linux) or bin/build.ps1 (Windows) builds the HTML without validation.
---

# latticery

依頼の文章から、図を HTML ファイル1つで作ります。あなたは図の元データを JSON で書きます。architecture では部品の位置（列・行）を、sequence ではやりとりの順番を、workflow では担当と手順の順番を、dataflow では段と行を、lifecycle では状態の帯と列を決めます。
大きさ・線の経路の計算と検証は、このスキルのプログラムが行います。

以下の `<skill>` は、この SKILL.md があるフォルダです。

## 図の種類

| 種類 | 使う場面 | 書き方ガイド | 例 |
|---|---|---|---|
| `architecture` | システムの構成図：人・アプリ・サーバー・DB・キュー・外部サービスと、そのつながり | `<skill>/types/architecture/guide.md` | `<skill>/types/architecture/examples/`（Web アプリ `ec-site.json`・社内システム `internal-expense.json`・データ基盤 `data-platform.json`） |
| `sequence` | シーケンス図：参加者（人・アプリ・サーバー・DB など）の間のやりとりを、上から起きる順に並べた図。呼び出しと返答、非同期、条件分岐・繰り返し | `<skill>/types/sequence/guide.md` | `<skill>/types/sequence/examples/`（ログイン `login.json`・注文と決済 `checkout.json`・非同期のジョブ（英語）`export-job.json`） |
| `workflow` | 業務フロー：だれが・どの順番で・何をするか。担当ごとの帯（レーン）に手順を並べ、判断で分かれ、差し戻しで前の手順へ戻る | `<skill>/types/workflow/guide.md` | `<skill>/types/workflow/examples/`（経費精算 `expense.json`・問い合わせ対応（縦向き）`support.json`・入社手続き（英語）`onboarding-en.json`） |
| `dataflow` | データの流れの図：どのデータが、どこで生まれ、どこを通って、どう変わり、だれに使われるか。段（発生・取り込み・加工・保存・利用など）を左から右に並べ、線にデータの名前を書き、個人情報などの流れに印を付ける | `<skill>/types/dataflow/guide.md` | `<skill>/types/dataflow/examples/`（購買データ `purchase.json`・売上の夜間集計 `sales-etl.json`・操作ログの分析（英語）`events-en.json`） |
| `lifecycle` | ライフサイクル・状態遷移の図：1つのもの（注文・申請・リリース・処理の実行など）が、どんな状態を通って、どう終わるか。主な局面を上段に左から右へ並べ、途中の待ち・やり直しを中段に、終わり方（取り消し・期限切れ・失敗など）を下段に置く | `<skill>/types/lifecycle/guide.md` | `<skill>/types/lifecycle/examples/`（注文のステータス `order.json`・経費申請のステータス `request.json`・ジョブの実行（英語）`job-run-en.json`） |

### 種類の選び方

**種類は、利用者が書いた依頼文そのもので判断します。** このスキルを呼ぶときにあなたが書いた要約や引数（「〜のシーケンス図」など）は、判断の材料にしません。あなたが種類を思い浮かべたかどうかではなく、利用者がその言葉を書いたかどうかで決めます。

依頼文に、種類が決まる言葉があれば、そのまま作ります。

| 種類 | 種類が決まる言葉 |
|---|---|
| `architecture` | 構成図、アーキテクチャ図、システム構成、インフラ構成、システム間の関係、architecture diagram |
| `sequence` | シーケンス図、処理の順番、呼び出しの順番、API のやりとり、sequence diagram |
| `workflow` | 業務フロー、ワークフロー、申請〜承認の流れ、担当ごとの手順、スイムレーン、workflow diagram |
| `dataflow` | データフロー（図）、データの流れ、データパイプライン、ETL・ELT、データ連携図、データリネージ、data flow diagram、data pipeline |
| `lifecycle` | ライフサイクル、状態遷移（図）、ステータス遷移、ステータスの移り変わり、状態の移り変わり、〜のステータス（「注文のステータスを図に」など）、lifecycle、state diagram、state machine、status transitions |

「連携図」「システム連携」だけのときは、構成図（architecture）とデータの流れ（dataflow）のどちらにも読めるので、決まる言葉として扱いません（下のとおり質問します）。「状態」だけ（「今の状態を図にして」）も、決まる言葉として扱いません。

業務フロー（workflow）とライフサイクル（lifecycle）の違い：workflow は「だれが・どの順番で・何をするか（担当と手順）」、lifecycle は「1つのものが、どんな状態を通って、どう終わるか」です。「申請から承認までの流れ」は workflow、「申請のステータス」は lifecycle です。

決まる言葉がないとき（「流れを図にして」「フロー図を作って」「これを図にして」「注文がどう進むかを図にして」「make a flow diagram」など）は、**書き方ガイドを読む前・JSON を書く前に、利用者に質問して答えを待ちます**。どの種類がよいかあなたに見当が付いていても、質問します（利用者が別の種類を思い描いていることがあるため）。会話の中で利用者がすでに種類を決めていれば、聞き直しません。

質問は、次の形にします。

- 依頼の中身にいちばん合う種類を1つすすめ、なぜそう思うかを1行で書く
- ほかの候補を1〜2つ、どんな図かの短い説明とともに挙げる

例：「『注文の流れ』は、次のどれで描きますか。**シーケンス図**（ブラウザ・API・DB のやりとりを、起きる順に並べる）／業務フロー（担当ごとの帯に、手順を並べる）／構成図（システムの部品とつながり）」

## 手順

1. 利用者の依頼文から図の種類を選ぶ（上の「種類の選び方」）。決まる言葉がなければ、質問して答えを待つ（ここで手順を止める）
2. その種類の書き方ガイドと、依頼に近い例を1つだけ読む
3. JSON を書く。保存先は利用者の指定に従う。指定がなければ、今のフォルダ（`pwd` で確かめる。利用者が開いているプロジェクトなど）に `<名前>.json` で保存し、HTML も同じフォルダに作る。JSON と HTML は利用者に渡す成果物で、一時ファイルではない。scratchpad などの一時フォルダには置かない（利用者が見つけられないため）。図の中の文字は、依頼の言語で書く
4. `node --version`・`deno --version`・`bun --version` のどれかで、JS の実行環境が使えるか確かめる
5. 使える場合（下は node の例。deno は `deno run --allow-read --allow-write --allow-env`、bun は `bun` に置き換える）
   1. 検証する：`node <skill>/bin/latticery.mjs check <名前>.json`。利用者が図の大きさを指定したとき（「横 1200px に収めて」など）は、`--max-width 1200`・`--max-height <px>` を付ける（build にも同じものを付ける）。指定がなければ付けない
   2. エラーがあれば直す（下の「エラーの直し方」）。エラーがなくなるまで、直しては検証する
   3. 警告があれば、直せるものは直して、もう一度検証する。直すと別の問題が出るときは、無理に直さない
   4. HTML を作る：`node <skill>/bin/latticery.mjs build <名前>.json <名前>.html`
6. 使えない場合は、検証せずに HTML を作る
   - macOS・Linux：`sh <skill>/bin/build.sh <名前>.json <名前>.html`
   - Windows：`powershell -ExecutionPolicy Bypass -File <skill>\bin\build.ps1 <名前>.json <名前>.html`
   - 自動の検証はしていないこと、HTML をブラウザで開けば問題があれば表示されることを、利用者に伝える
7. 報告する：HTML と JSON の場所（フルパス）、検証をしたかどうか、その結果（残った警告があれば、それも）。実行していない検証を「した」と言わない

## エラーの直し方

- 各エラーには、直し方の候補が付いている。まず候補に従う。候補に具体的な位置（col・row）があれば、それを使ってよい
- 検証は段階ごとに進む（JSON の書き方 → 部品・枠・線の関係 → 配置したときの見た目）。前の段階のエラーがなくなると、次の段階のエラーが初めて出るので、数が増えることがある
- 打ち切り：直す前よりエラーの数が減らないことが2回続いたら、直すのをやめる。ただし、エラーのコードが前の回とすべて入れ替わったときは、次の段階に進んだので、減ったものとして数える
- 打ち切ったときは HTML を作れない。残ったエラーのメッセージと、試した直し方を利用者に報告する

## 注意

- JSON だけを書き、HTML や SVG を直接書かない。HTML の中にも JSON がそのまま入るので、後から直すときは JSON を直して作り直す
- `<skill>` の中のファイルは変更しない
