---
name: latticery
description: Draw diagrams as a single self-contained HTML file (works offline, light/dark theme) from a plain-language request. Currently supports architecture diagrams — system, infrastructure and cloud architecture showing people, apps, services, databases, queues, external services, network boundaries and how they connect. You write a small JSON file; the bundled scripts size the boxes, route the lines, validate the diagram and build the HTML. Use when the user asks to draw, create or visualize an architecture diagram, e.g. 「構成図を描いて」「アーキテクチャ図」「システム構成図」「インフラ構成図」.
compatibility: Validation and building use Node.js, Deno or Bun when available. Without them, bin/build.sh (macOS/Linux) or bin/build.ps1 (Windows) builds the HTML without validation.
---

# latticery

依頼の文章から、図を HTML ファイル1つで作ります。あなたは図の元データを JSON で書き、部品の位置（列・行）を決めます。
大きさ・線の経路の計算と検証は、このスキルのプログラムが行います。

以下の `<skill>` は、この SKILL.md があるフォルダです。

## 図の種類

| 種類 | 使う場面 | 書き方ガイド | 例 |
|---|---|---|---|
| `architecture` | システムの構成図：人・アプリ・サーバー・DB・キュー・外部サービスと、そのつながり | `<skill>/types/architecture/guide.md` | `<skill>/types/architecture/examples/`（Web アプリ `ec-site.json`・社内システム `internal-expense.json`・データ基盤 `data-platform.json`） |

## 手順

1. 依頼から図の種類を選ぶ（今は `architecture` だけ）
2. その種類の書き方ガイドと、依頼に近い例を1つだけ読む
3. JSON を書く。保存先は利用者の指定に従う。指定がなければ、今のフォルダ（`pwd` で確かめる。利用者が開いているプロジェクトなど）に `<名前>.json` で保存し、HTML も同じフォルダに作る。JSON と HTML は利用者に渡す成果物で、一時ファイルではない。scratchpad などの一時フォルダには置かない（利用者が見つけられないため）。図の中の文字は、依頼の言語で書く
4. `node --version`・`deno --version`・`bun --version` のどれかで、JS の実行環境が使えるか確かめる
5. 使える場合（下は node の例。deno は `deno run --allow-read --allow-write --allow-env`、bun は `bun` に置き換える）
   1. 検証する：`node <skill>/bin/latticery.mjs check <名前>.json`。利用者が図の大きさを指定したとき（「横 1200px に収めて」など）は、`--max-width 1200`・`--max-height <px>` を付ける（build にも同じものを付ける）。指定がなければ付けない
   2. エラーがあれば直す（下の「エラーの直し方」）。エラーがなくなるまで、直しては検証する
   3. 警告があれば、直せるものは直して、もう一度検証する。直すと別の問題が出るときは、無理に直さない
   4. HTML を作る：`node <skill>/bin/latticery.mjs build <名前>.json <名前>.html`
6. 使えない場合は、検証せずに HTML を作る
   - macOS・Linux：`sh <skill>/bin/build.sh <名前>.json <名前>.html`
   - Windows：`powershell -ExecutionPolicy Bypass -File <skill>\bin\build.ps1 <名前>.json <名前>.html`
   - 自動の検証はしていないこと、HTML をブラウザで開けば問題があれば表示されることを、利用者に伝える
7. 報告する：HTML と JSON の場所（フルパス）、検証をしたかどうか、その結果（残った警告があれば、それも）。実行していない検証を「した」と言わない

## エラーの直し方

- 各エラーには、直し方の候補が付いている。まず候補に従う。候補に具体的な位置（col・row）があれば、それを使ってよい
- 検証は段階ごとに進む（JSON の書き方 → 部品・枠・線の関係 → 配置したときの見た目）。前の段階のエラーがなくなると、次の段階のエラーが初めて出るので、数が増えることがある
- 打ち切り：直す前よりエラーの数が減らないことが2回続いたら、直すのをやめる。ただし、エラーのコードが前の回とすべて入れ替わったときは、次の段階に進んだので、減ったものとして数える
- 打ち切ったときは HTML を作れない。残ったエラーのメッセージと、試した直し方を利用者に報告する

## 注意

- JSON だけを書き、HTML や SVG を直接書かない。HTML の中にも JSON がそのまま入るので、後から直すときは JSON を直して作り直す
- `<skill>` の中のファイルは変更しない
