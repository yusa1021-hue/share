// 列・行・通路の幅を決める計算。必要な間隔（制約）を集めてから、位置を1つずつ確定させる。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」の「大きさと位置」
//
// 軸（axis）は、格子の線の位置（px）を並べたもの。位置は、線そのもの（line）か部品の縁（border）で指すので、
// 縁の分の隙間（inset）も一緒に決める。

import { border, line, order } from './grid.mjs';
import { EDGE, labelSides, labelWidth } from './lanes.mjs';

// 1つの軸（横または縦）を、通路 i ごとの3つの幅 L・B・R と、列 j ごとの2つの半マス H で表す。
// 並びは L0 B0 R0 H0 H1 L1 B1 R1 H2 H3 … Lc Bc Rc。通路の中心線は B の中央、列の中心線は2つの H の境目。
// L と R には枠の余白が入り、B にはレーンが入る。
export function createAxis(count, oddInset = 0) {
  const slots = [];
  const index = { L: [], B: [], R: [], H: [] };
  for (let i = 0; i <= count; i += 1) {
    for (const kind of ['L', 'B', 'R']) {
      index[kind][i] = slots.length;
      slots.push({ kind, min: 0 });
    }
    if (i < count) {
      for (const t of [2 * i, 2 * i + 1]) {
        index.H[t] = slots.length;
        slots.push({ kind: 'H', min: 0 });
      }
    }
  }
  return { count, oddInset, slots, index, inset: new Map(), constraints: [] };
}

export const raiseMin = (axis, slot, value) => { axis.slots[slot].min = Math.max(axis.slots[slot].min, value); };

// 位置を「各スロットの幅の係数」と定数で表す。
export function positionForm(axis, spec) {
  const coef = new Array(axis.slots.length).fill(0);
  const upTo = (slot) => { for (let s = 0; s < slot; s += 1) coef[s] = 1; };
  let constant = 0;
  const lineAt = (k) => {
    if (k % 2 === 0) {
      const i = k / 2;
      upTo(axis.index.B[i]);
      coef[axis.index.B[i]] = 0.5;
    } else {
      upTo(axis.index.H[k]);
    }
  };
  if (spec.type === 'line') {
    lineAt(spec.index);
  } else if (spec.boundary % 2 === 0) {
    const i = spec.boundary / 2;
    upTo(spec.dir > 0 ? axis.index.H[spec.boundary] : axis.index.L[i]);
  } else {
    lineAt(spec.boundary);
    constant = spec.dir * insetOf(axis, spec.boundary);
  }
  return { coef, constant };
}

export function insetOf(axis, k) {
  return axis.inset.get(k) ?? axis.oddInset;
}

export function addSpanConstraint(axis, fromSpec, toSpec, need, stretch) {
  const from = positionForm(axis, fromSpec);
  const to = positionForm(axis, toSpec);
  const coef = to.coef.map((value, s) => value - from.coef[s]);
  axis.constraints.push({ coef, need: need - (to.constant - from.constant), stretch });
}

// 制約を、関わるスロットの少ないものから順に満たしていく。足りない分は、指定した種類のスロットに等しく配る。
export function solve(axis) {
  const values = axis.slots.map((slot) => slot.min);
  const constraints = axis.constraints
    .map((constraint, position) => ({ ...constraint, position, span: constraint.coef.filter((c) => c > 0).length }))
    .sort((p, q) => p.span - q.span || p.position - q.position);
  for (const constraint of constraints) {
    const total = constraint.coef.reduce((sum, c, s) => sum + c * values[s], 0);
    if (total >= constraint.need) continue;
    let chosen = [];
    for (const kind of constraint.stretch) {
      chosen = constraint.coef.flatMap((c, s) => (c > 0 && axis.slots[s].kind === kind ? [s] : []));
      if (chosen.length > 0) break;
    }
    if (chosen.length === 0) chosen = constraint.coef.flatMap((c, s) => (c > 0 ? [s] : []));
    if (chosen.length === 0) continue;
    const weight = chosen.reduce((sum, s) => sum + constraint.coef[s], 0);
    const delta = (constraint.need - total) / weight;
    for (const s of chosen) values[s] += delta;
  }
  return values;
}

export function evaluate(axis) {
  const values = solve(axis);
  return {
    total: values.reduce((sum, v) => sum + v, 0),
    at(spec) {
      const form = positionForm(axis, spec);
      return form.coef.reduce((sum, c, s) => sum + c * values[s], 0) + form.constant;
    },
  };
}

/**
 * 図の種類によらない寸法の制約を集める。奇数番の線と部品との間隔（inset）は制約の定数に入るので、最初にすべて決める。
 * grid は格子、edges は線の一覧、runsByEdge・labelRuns・labelAnchors・laneWidths は区間とレーンの計算結果、
 * x・y は軸、gutter は通路の幅の決まり、sizeOf は部品の大きさを返す関数、
 * pads は、奇数番の線に接する部品との間隔に足す余白（図の種類ごとのもの。architecture では枠の余白）。
 * labelMargin は、線のラベルの前後（区間の方向）に空ける余白で、横の区間（h）と縦の区間（v）ごとに決める。
 * 省略すると EDGE.labelMargin（dataflow は横の区間を広げる。決定記録 No.94）。
 * 図の種類ごとの制約は、この関数を呼んだ後に足す（間隔がすべて決まってから、それを使う制約を作るため）。
 */
export function sizeGrid({
  grid, edges, runsByEdge, labelRuns, labelAnchors, laneWidths, x, y, gutter, sizeOf, pads = { x: new Map(), y: new Map() },
  labelMargin = { h: EDGE.labelMargin, v: EDGE.labelMargin },
}) {
  const { labelHeight, laneGap, laneMargin } = EDGE;
  const { base, outer, emptyTrack, oddInset } = gutter;
  // lanes は、線の番号ごとのレーン全体の幅（ラベルの分を含む）。
  const axes = { x: { axis: x, lanes: laneWidths.v }, y: { axis: y, lanes: laneWidths.h } };

  // 列・行の中心線に接する部品（半マスずらし）との間隔。レーンと、図の種類ごとの余白が入るようにする。
  for (const [name, { axis, lanes }] of Object.entries(axes)) {
    for (let k = 1; k < axis.count * 2; k += 2) {
      axis.inset.set(k, Math.max(oddInset, (lanes.get(k) ?? 0) / 2 + (pads[name].get(k) ?? 0)));
    }
  }
  // 中心線をはさんで接する2つの部品の間にラベルが入るときは、間隔を広げる。
  edges.forEach((edge, i) => {
    const run = labelRuns[i];
    if (!run || run.start.type !== 'border' || run.end.type !== 'border' || run.start.boundary !== run.end.boundary) return;
    const k = run.start.boundary;
    if (k % 2 === 0) return;
    const axis = run.axis === 'h' ? x : y;
    const size = run.axis === 'h' ? labelWidth(edge.label) : labelHeight;
    axis.inset.set(k, Math.max(insetOf(axis, k), size / 2 + labelMargin[run.axis]));
  });

  // 通路と半マスの最小幅。
  for (const { axis, lanes } of Object.values(axes)) {
    for (let i = 0; i <= axis.count; i += 1) {
      const floor = i === 0 || i === axis.count ? outer : base;
      raiseMin(axis, axis.index.B[i], Math.max(floor, lanes.get(2 * i) ?? 0));
    }
    for (let t = 0; t < axis.count * 2; t += 1) raiseMin(axis, axis.index.H[t], emptyTrack / 2);
    for (let j = 0; j < axis.count; j += 1) {
      const half = (lanes.get(2 * j + 1) ?? 0) / 2;
      raiseMin(axis, axis.index.H[2 * j], half);
      raiseMin(axis, axis.index.H[2 * j + 1], half);
    }
  }

  // 部品の大きさ。
  for (const box of grid.boxes) {
    const size = sizeOf(box.node);
    addSpanConstraint(x, border(box.a, 1), border(box.b, -1), size.width, ['H', 'B']);
    addSpanConstraint(y, border(box.c, 1), border(box.d, -1), size.height, ['H', 'B']);
  }

  // 部品の辺に出入りする線の端が、辺の中に収まるようにする（レーンでずれた分と、端の余白 portMargin を含める）。
  // ふつうの部品では行・列の幅で足りているが、半マスずらしの部品は接続点が通路の中心線に来るので、ここで広げる。
  const portMargin = laneGap / 2 + laneMargin;
  runsByEdge.forEach((runs, i) => {
    if (!runs) return;
    const ends = [[runs[0], grid.byId.get(edges[i].from)], [runs.at(-1), grid.byId.get(edges[i].to)]];
    for (const [run, box] of ends) {
      const [axis, low, high] = run.axis === 'h' ? [y, box.c, box.d] : [x, box.a, box.b];
      addSpanConstraint(axis, border(low, 1), line(run.line), portMargin - run.offset, ['H', 'B']);
      addSpanConstraint(axis, line(run.line), border(high, -1), portMargin + run.offset, ['H', 'B']);
    }
  });

  // 線のラベル。区間の方向には、ラベルを置く位置のまわりにラベルが入るだけの場所を空ける
  // （区間と直角の方向は、ラベルを置いたレーンを太くして空けている。placeLanes を参照）。
  // 線の中間に置く場合は、両側の線の間隔を、ラベルと、両側の線に並ぶレーン（ほかのラベルの分を含む）が入るだけ空ける。
  const reserve = (axis, lanes, k, size, margin) => {
    if (!Number.isInteger(k)) {
      const [before, after] = labelSides(lanes, k);
      addSpanConstraint(axis, line(Math.floor(k)), line(Math.ceil(k)), before + size + after, ['B', 'H']);
    } else if (k % 2 === 0) {
      raiseMin(axis, axis.index.B[k / 2], size + 2 * margin);
    } else {
      raiseMin(axis, axis.index.H[k - 1], size / 2 + margin);
      raiseMin(axis, axis.index.H[k], size / 2 + margin);
    }
  };
  edges.forEach((edge, i) => {
    const run = labelRuns[i];
    if (!run) return;
    if (run.axis === 'h') reserve(x, laneWidths.v, labelAnchors[i], labelWidth(edge.label), labelMargin.h);
    else reserve(y, laneWidths.h, labelAnchors[i], labelHeight, labelMargin.v);
  });
}
