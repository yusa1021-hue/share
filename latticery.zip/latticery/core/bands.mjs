// 帯（部品の升目の並びに沿って、図を区切る背景）の範囲と描き方。
// workflow の担当の帯・局面の帯、dataflow の段、lifecycle の帯で使う。仕様：docs/latticery/types/workflow.md の「帯」（決定記録 No.88・No.90）
//
// 帯には2つの向きがある。
// - 列の帯（axis 'x'）：横に並ぶ縦長の帯。見出しは図の上端に置く（workflow の縦向きの担当・横向きの局面、dataflow の段）
// - 行の帯（axis 'y'）：縦に並ぶ横長の帯。見出しは図の左端に置く（workflow の横向きの担当・縦向きの局面）
// 帯の描き方も2つある。
// - 塗りの帯（fillBands・fillBandElement）：本体いっぱいに伸び、1つおきに淡く塗る。境目の線は見出しの帯の中だけに引く
// - 見出しだけの帯（headerBands・headerBandElement）：見出しの帯の中だけを占め、破線で区切る
// 見出しの名前は、どちらの向きでも横書きのまま、帯の中央に置く。
//
// 帯の色のテーマの CSS は core/draw.mjs の diagramStyles() に入れる（帯の色の変数と同じ場所。種類ごとに入れると、雛形の中で重複するため）。

import { BASE_COLORS } from './draw.mjs';
import { line } from './grid.mjs';
import { el, formatNumber as n } from './svg.mjs';
import { estimateWidth } from './text.mjs';

// header は見出しの帯の厚み（列の帯の見出し、行の帯の見出しの最小）、labelSize は見出しの文字、labelPad は見出しの左右の余白。
export const BAND = { header: 34, labelSize: 12, labelPad: 12 };

// 帯の線の太さと、見出しだけの帯の区切りの破線。
export const BAND_DRAW = { strokeWidth: 1, dash: '5 4' };

/** 見出しの名前が入る幅（左右の余白を含む）。 */
export const bandLabelWidth = (text) => estimateWidth(text, BAND.labelSize, { bold: true }) + 2 * BAND.labelPad;

/**
 * 見出しの帯の厚み。帯がなければ 0。列の帯は決まった厚みにし、行の帯は、横書きの名前のうち
 * いちばん長いものが入る厚みにする（帯と直角の向きに名前が並ぶため）。
 */
export function headerThickness(labels, axis) {
  if (labels.length === 0) return 0;
  return axis === 'x' ? BAND.header : Math.max(BAND.header, ...labels.map(bandLabelWidth));
}

/**
 * 升目（core/grid.mjs の box）の集まりが、axis の向きに占める格子の線の範囲 [low, high]。升目がなければ null。
 * 格子の線のうち偶数番は升目の境目なので、隣り合う帯はその線でぴったり接する。
 */
export function gridSpan(boxes, axis) {
  if (boxes.length === 0) return null;
  const lows = boxes.map((box) => (axis === 'x' ? box.a : box.c));
  const highs = boxes.map((box) => (axis === 'x' ? box.b : box.d));
  return [Math.min(...lows), Math.max(...highs)];
}

/**
 * 塗りの帯の位置と大きさ。items は帯（{ id, label, style }）、spans は帯ごとの gridSpan（null の帯は作らない）。
 * frame は { at, offset, thickness, width, height }：at は格子の位置から図の px への変換（{ x, y }）、
 * offset は本体の左上（見出しの帯の分だけずれた位置）、thickness はこの帯の見出しの厚み、width・height は図の大きさ。
 * 帯は、並ぶ向きには範囲の格子の線の間を占め（両端の帯は図の端まで伸ばす）、直角の向きには本体いっぱいに伸びる。
 */
export function fillBands(items, spans, axis, { at, offset, thickness, width, height }) {
  const columns = axis === 'x';
  const position = columns ? at.x : at.y;
  const last = items.length - 1;
  return items.map((item, index) => {
    const span = spans[index];
    if (!span) return null;
    const from = index === 0 ? (columns ? offset.x : offset.y) : position(line(span[0]));
    const to = index === last ? (columns ? width : height) : position(line(span[1]));
    const box = columns
      ? { x: from, y: offset.y, width: to - from, height: height - offset.y }
      : { x: offset.x, y: from, width: width - offset.x, height: to - from };
    return {
      id: item.id,
      label: item.label,
      style: item.style ?? 'normal',
      ...box,
      labelBox: columns
        ? { x: box.x, y: offset.y - thickness, width: box.width, height: thickness }
        : { x: offset.x - thickness, y: box.y, width: thickness, height: box.height },
    };
  }).filter(Boolean);
}

/** 見出しだけの帯の位置と大きさ（見出しの帯の中の範囲）。引数は fillBands と同じ（width・height は使わない）。 */
export function headerBands(items, spans, axis, { at, offset, thickness }) {
  const columns = axis === 'x';
  const position = columns ? at.x : at.y;
  return items.map((item, index) => {
    const span = spans[index];
    if (!span) return null;
    const from = position(line(span[0]));
    const to = position(line(span[1]));
    const box = columns
      ? { x: from, y: offset.y - thickness, width: to - from, height: thickness }
      : { x: offset.x - thickness, y: from, width: thickness, height: to - from };
    return { id: item.id ?? null, label: item.label, from, to, ...box };
  }).filter(Boolean);
}

// ---- 描画 ----------------------------------------------------------------------

// 帯の線は太さ 1px なので、座標を 0.5 にそろえて、2ピクセルににじまないようにする（決定記録 No.88）。
const crisp = (value) => Math.floor(value) + 0.5;

/**
 * 見出しの帯の背景。axes は、図にある帯の組の向き（描く順）。図の端から端まで敷く。
 * frame は { width, height, offset }（図の大きさと、本体の左上）。
 */
export function bandHeaderStrips(axes, frame, base = BASE_COLORS.light) {
  const { x, y } = frame.offset;
  return el('g', { class: 'lt-band-headers' }, axes.map((axis) => el('rect', {
    class: 'lt-band-header',
    ...(axis === 'x' ? { x: 0, y: 0, width: frame.width, height: y } : { x: 0, y: 0, width: x, height: frame.height }),
    fill: base.bandHeader,
  })));
}

/** 見出しの帯と図の本体の境目の実線。図の端から端まで引く。帯の色の上に描く（色を敷いた帯に隠れないように）。 */
export function bandRule(axes, frame, base = BASE_COLORS.light) {
  const { x, y } = frame.offset;
  if (axes.length === 0) return null;
  const lines = axes.map((axis) => (axis === 'x' ? `M0 ${n(crisp(y))}H${n(frame.width)}` : `M${n(crisp(x))} 0V${n(frame.height)}`));
  return el('path', {
    class: 'lt-band-rule', d: lines.join(''), fill: 'none', stroke: base.group, 'stroke-width': BAND_DRAW.strokeWidth,
  });
}

/**
 * 塗りの帯（fillBands の1つ）。1つおきに淡く敷き、例外の帯（style 'exception'）は別の色にする。
 * 帯の境目の線は、見出しの帯の中だけに引く（図の本体では、帯の境目を通る線と重なって見分けにくくなるため。決定記録 No.88）。
 * name は帯の組のクラス（workflow の担当は lt-lane、dataflow の段は lt-stage）。塗りの四角のクラスは、どの組でも同じ。
 */
export function fillBandElement(band, index, axis, { name = 'lt-lane', base = BASE_COLORS.light } = {}) {
  const box = band.labelBox;
  const exception = band.style === 'exception';
  const fill = exception ? base.bandException : (index % 2 === 1 ? base.band : null);
  const divider = axis === 'x'
    ? `M${n(crisp(band.x))} ${n(box.y)}V${n(box.y + box.height)}`
    : `M${n(box.x)} ${n(crisp(band.y))}H${n(box.x + box.width)}`;
  return el('g', { class: `${name}${exception ? ' lt-exception' : ''}`, 'data-id': band.id }, [
    fill ? el('rect', {
      class: `lt-lane-box${exception ? '' : ' lt-lane-odd'}`, x: band.x, y: band.y, width: band.width, height: band.height, fill,
    }) : null,
    index === 0 ? null : el('path', {
      class: 'lt-band-line', d: divider, fill: 'none', stroke: base.bandLine, 'stroke-width': BAND_DRAW.strokeWidth,
    }),
    bandLabel(band.label, box, axis, base),
  ]);
}

/** 見出しだけの帯（headerBands の1つ）。見出しの帯の中の区切りの破線と、名前。本体側には何も描かない。 */
export function headerBandElement(band, index, axis, { name = 'lt-phase', base = BASE_COLORS.light } = {}) {
  const box = { x: band.x, y: band.y, width: band.width, height: band.height };
  const divider = axis === 'x'
    ? `M${n(crisp(box.x))} ${n(box.y)}V${n(box.y + box.height)}`
    : `M${n(box.x)} ${n(crisp(box.y))}H${n(box.x + box.width)}`;
  return el('g', { class: name, 'data-id': band.id }, [
    index === 0 ? null : el('path', {
      class: `lt-band-line ${name}-line`, d: divider, fill: 'none', stroke: base.bandLine,
      'stroke-width': BAND_DRAW.strokeWidth, 'stroke-dasharray': BAND_DRAW.dash,
    }),
    bandLabel(band.label, box, axis, base),
  ]);
}

// 帯の見出しの名前。縦書きにはせず、横書きのまま見出しの中央に置く。
// クラスの across は列の帯の見出し、along は行の帯の見出し（workflow で付けた名前のまま）。
function bandLabel(label, box, axis, base) {
  const { labelSize } = BAND;
  return el('text', {
    class: `lt-band-label lt-band-${axis === 'x' ? 'across' : 'along'}`,
    x: box.x + box.width / 2,
    y: box.y + box.height / 2,
    'font-size': labelSize,
    'font-weight': 700,
    'text-anchor': 'middle',
    'dominant-baseline': 'central',
    fill: base.muted,
    'data-width': estimateWidth(label, labelSize, { bold: true }),
  }, label);
}
