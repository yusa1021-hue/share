// JSON の読み込みから、検証と配置の計算までの流れ。結果は check --json と同じ形で返す。
// 各段階でエラーが出たら、次の段階には進まない（前の問題が残っていると、後のチェックが正しく行えないため）。
//
// types は { [図の種類]: { validateSchema, synonyms, check, layout, inspect, messages } }。
// check は構造の検証、layout は配置の計算、inspect は配置の計算結果を使う見た目のチェック（共通仕様「6. 処理の段階」）。
// options.lang は呼び出し側の指定、options.fallbackLang は実行環境の言語（ブラウザの設定や環境変数）。
// options.maxWidth・options.maxHeight は、利用者が図の大きさを指定したときの上限（px）。見た目のチェックに渡す。

import { buildReport, error, fromSchemaErrors } from './diagnostics.mjs';
import { pickLang } from './i18n.mjs';
import { coreMessages } from './messages.mjs';

const hasError = (diagnostics) => diagnostics.some((d) => d.severity === 'error');

/**
 * 検証し、エラーがなければ配置も計算する。
 * 返り値は { report, layout, doc, lang }。layout はエラーがあれば null。
 * doc は読み込んだ JSON（読み込めなければ null）、lang はメッセージに使った言語。
 */
export function analyzeSource(source, types, options = {}) {
  let doc;
  try {
    doc = JSON.parse(source.replace(/^﻿/, ''));
  } catch (cause) {
    const report = buildReport({
      type: null,
      diagnostics: [error('json/invalid', { detail: { reason: cause.message } })],
      lang: pickLang(options.lang, options.fallbackLang),
      catalog: coreMessages,
    });
    return { report, layout: null, doc: null, lang: pickLang(options.lang, options.fallbackLang) };
  }
  return analyzeDocument(doc, types, options);
}

export function analyzeDocument(doc, types, options = {}) {
  const isObject = typeof doc === 'object' && doc !== null && !Array.isArray(doc);
  const lang = pickLang(options.lang, isObject ? doc.lang : undefined, options.fallbackLang);
  const name = isObject ? doc.type : undefined;
  const definition = typeof name === 'string' && Object.hasOwn(types, name) ? types[name] : null;

  if (!definition) {
    const detail = { supported: Object.keys(types) };
    if (name !== undefined) detail.value = name;
    const report = buildReport({ type: null, diagnostics: [error('type/unknown', { detail })], lang, catalog: coreMessages });
    return { report, layout: null, doc, lang };
  }

  const catalog = { ...coreMessages, ...definition.messages };
  const finish = (diagnostics, layout = null) => ({
    report: buildReport({ type: name, diagnostics, lang, catalog }),
    layout: hasError(diagnostics) ? null : layout,
    doc,
    lang,
  });

  const schemaDiagnostics = fromSchemaErrors(definition.validateSchema(doc).errors, doc, definition.synonyms);
  if (schemaDiagnostics.length > 0) return finish(schemaDiagnostics);

  const structure = definition.check(doc);
  if (hasError(structure)) return finish(structure);

  const { layout, diagnostics } = definition.layout(doc);
  if (hasError(diagnostics)) return finish([...structure, ...diagnostics]);

  const visual = definition.inspect(doc, layout, { maxWidth: options.maxWidth, maxHeight: options.maxHeight });
  return finish([...structure, ...diagnostics, ...visual], layout);
}

export function checkSource(source, types, options = {}) {
  return analyzeSource(source, types, options).report;
}

export function checkDocument(doc, types, options = {}) {
  return analyzeDocument(doc, types, options).report;
}
