// 図の種類ごとのチェック（types/<種類>/checks.mjs）で共通に使う道具。
// どれも言語に依存しない診断（core/diagnostics.mjs の error・warning）を返す。メッセージは core/messages.mjs か、図の種類の messages.mjs にある。

import { error, warning } from './diagnostics.mjs';
import { textUnits } from './text.mjs';

/**
 * ID の重複（id/duplicate）。entries は [{ id, path }]（path は JSON Pointer）。id が undefined のものは数えない。
 * 同じ ID が2か所以上で使われていれば、ID ごとに1件のエラーにする。
 */
export function duplicateIds(entries) {
  const places = new Map();
  for (const { id, path } of entries) {
    if (id === undefined) continue;
    if (!places.has(id)) places.set(id, []);
    places.get(id).push(path);
  }
  return [...places]
    .filter(([, paths]) => paths.length > 1)
    .map(([id, paths]) => error('id/duplicate', { target: [id], detail: { id, paths } }));
}

/**
 * 文字列が目安より長い（text/too-long）。entries は [{ text, path, limit, target }]。
 * 長さは表示の幅（半角1・全角2）で数え、limit を超えたものを警告にする。text が文字列でないものは数えない。
 */
export function longTexts(entries) {
  return entries
    .filter(({ text }) => typeof text === 'string')
    .map((entry) => ({ ...entry, units: textUnits(entry.text) }))
    .filter(({ units, limit }) => units > limit)
    .map(({ path, units, limit, target }) => warning('text/too-long', { target, detail: { path, units, limit } }));
}

/**
 * 図が、利用者の指定した大きさ（limits：{ maxWidth, maxHeight }。px）を超えている（size/too-wide・size/too-tall）。
 * 指定がなければ判定しない。extra.width・extra.height は、それぞれの detail に足す値（列の数など、直し方の手がかり）。
 */
export function oversize(layout, { maxWidth, maxHeight } = {}, extra = {}) {
  const problems = [];
  if (maxWidth !== undefined && layout.width > maxWidth) {
    problems.push(warning('size/too-wide', { detail: { width: Math.ceil(layout.width), limit: maxWidth, ...extra.width } }));
  }
  if (maxHeight !== undefined && layout.height > maxHeight) {
    problems.push(warning('size/too-tall', { detail: { height: Math.ceil(layout.height), limit: maxHeight, ...extra.height } }));
  }
  return problems;
}
