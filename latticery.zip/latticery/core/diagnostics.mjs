// エラー・警告（診断）の形と、その組み立て。
// チェックは言語に依存しない { code, severity, target, detail } を返し、
// 最後に buildReport が日英のメッセージと直し方の候補を付ける。

// ID に使える形。スキーマ（schema.json）の $defs/id と同じにする（テストで確かめている）。
export const ID_PATTERN = '^[A-Za-z][A-Za-z0-9_-]*$';

export function error(code, { target = [], detail = {} } = {}) {
  return { code, severity: 'error', target, detail };
}

export function warning(code, { target = [], detail = {} } = {}) {
  return { code, severity: 'warning', target, detail };
}

// core/schema.mjs のエラーを schema/invalid の診断に変える。
// synonyms は、使えない値から意味の近い値の一覧への対応（{ cache: ['datastore'] } など。図の種類ごとに決める）。
// 書き間違いの候補（suggestion）が見つからないとき、意味の近い値を similar に入れる。
export function fromSchemaErrors(schemaErrors, doc, synonyms = {}) {
  return schemaErrors.map(({ path, keyword, params }) => {
    const detail = { path, keyword, ...params };
    const value = valueAt(doc, path);
    if (keyword !== 'additionalProperties' && isPrimitive(value)) detail.value = value;
    if (keyword === 'additionalProperties') {
      const suggestion = closest(params.property, params.allowed);
      if (suggestion) detail.suggestion = suggestion;
    }
    if (keyword === 'enum' && typeof value === 'string') {
      const suggestion = closest(value, params.allowed);
      const similar = (synonyms[value.toLowerCase().replace(/[^a-z0-9]/g, '')] ?? []).find((item) => params.allowed.includes(item));
      if (suggestion) detail.suggestion = suggestion;
      else if (similar) detail.similar = similar;
    }
    return error('schema/invalid', { target: targetAt(doc, path), detail });
  });
}

/**
 * 値ごとの「意味の近い語」の一覧（{ datastore: ['cache', ...] }）から、fromSchemaErrors に渡す synonyms
 * （語 → 意味の近い値の一覧）を作る。同じ語が複数の値に当たるときは、書いた順に並べる。
 */
export function synonymIndex(groups) {
  const index = {};
  for (const [value, words] of Object.entries(groups)) {
    for (const word of words) (index[word] ??= []).push(value);
  }
  return index;
}

// 診断に、指定した言語のメッセージと直し方の候補を付け、check --json の形にまとめる。
export function buildReport({ type, diagnostics, lang, catalog }) {
  const localize = (diagnostic) => {
    const entry = catalog[diagnostic.code]?.[lang];
    if (!entry) throw new Error(`メッセージが定義されていない：${diagnostic.code}（${lang}）`);
    return {
      code: diagnostic.code,
      target: diagnostic.target,
      message: entry.message(diagnostic.detail),
      detail: diagnostic.detail,
      fixes: entry.fixes(diagnostic.detail),
    };
  };
  const errors = diagnostics.filter((d) => d.severity === 'error').map(localize);
  const warnings = diagnostics.filter((d) => d.severity === 'warning').map(localize);
  return { ok: errors.length === 0, type, errors, warnings };
}

// 書き間違いと思われるときに、候補の中からいちばん近いものを返す。なければ null。
// 大文字・小文字は区別しない。短い値どうしの偶然の一致を避けるため、違いが長さの半分未満のものだけを候補にする。
// 前方が一致する場合（例：sub と sublabel）も候補にする。
export function closest(value, candidates) {
  let best = null;
  let bestDistance = Infinity;
  for (const candidate of new Set(candidates)) {
    if (typeof candidate !== 'string') continue;
    const a = value.toLowerCase();
    const b = candidate.toLowerCase();
    const d = editDistance(a, b);
    const near = d <= 2 && d * 2 < Math.max(a.length, b.length);
    const prefix = Math.min(a.length, b.length) >= 3 && (a.startsWith(b) || b.startsWith(a));
    if ((near || prefix) && d < bestDistance) {
      best = candidate;
      bestDistance = d;
    }
  }
  return best;
}

function editDistance(a, b) {
  let previous = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i += 1) {
    const current = [i];
    for (let j = 1; j <= b.length; j += 1) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      current[j] = Math.min(previous[j] + 1, current[j - 1] + 1, previous[j - 1] + cost);
    }
    previous = current;
  }
  return previous[b.length];
}

function segments(pointer) {
  return pointer === '' ? [] : pointer.slice(1).split('/').map((s) => s.replace(/~1/g, '/').replace(/~0/g, '~'));
}

function valueAt(doc, pointer) {
  let current = doc;
  for (const segment of segments(pointer)) {
    if (current === null || typeof current !== 'object' || !Object.hasOwn(current, segment)) return undefined;
    current = current[segment];
  }
  return current;
}

// path をたどり、いちばん深い「ID を持つもの」を対象とする。
// ID のない線は、始点と終点の ID を対象にする。
function targetAt(doc, pointer) {
  let current = doc;
  let target = [];
  for (const segment of segments(pointer)) {
    if (current === null || typeof current !== 'object' || !Object.hasOwn(current, segment)) break;
    current = current[segment];
    if (current === null || typeof current !== 'object' || Array.isArray(current)) continue;
    if (typeof current.id === 'string') target = [current.id];
    else if (typeof current.from === 'string' && typeof current.to === 'string') target = [current.from, current.to];
  }
  return target;
}

function isPrimitive(value) {
  return value === null || ['string', 'number', 'boolean'].includes(typeof value);
}
