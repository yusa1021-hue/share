// 図の描画で、種類によらず使うもの：図全体の色、線の太さと鏃、線の形（角の丸めと線またぎ）、テーマの CSS のうち共通の部分。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」（sequence も同じ値を使う）
//
// 色はライトの値を要素の属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは diagramStyles() と図の種類ごとの styles() の CSS で行う（CSS の指定は属性より優先される）。

import { el, formatNumber as n } from './svg.mjs';
import { estimateWidth } from './text.mjs';
import { KINDS, KIND_COLORS } from './kinds.mjs';

// 図全体の色。tagText は札の文字、edgeStrong は太く強調する線、group は枠の線と名前以外の部分。
// edgeSensitive は機密データの線とラベル（dataflow の sensitive。決定記録 No.94）。
// band：1つおきに敷く帯の色、bandLine：帯の境目の線、bandHeader：見出しの帯の背景、
// bandException：例外の帯の色（決定記録 No.88）。
export const BASE_COLORS = {
  light: {
    page: '#ffffff', text: '#1b1f27', muted: '#525a66', tagText: '#ffffff',
    edge: '#5b6472', edgeStrong: '#2b313b', edgeSensitive: '#a74541', group: '#8a93a0', groupFill: 'rgba(120, 130, 145, 0.05)',
    band: '#f4f6f8', bandLine: '#dfe3e8', bandHeader: '#eceff3', bandException: 'rgba(202, 115, 109, 0.08)',
  },
  dark: {
    page: '#14171c', text: '#eceef2', muted: '#a8afba', tagText: '#14171c',
    edge: '#8d96a3', edgeStrong: '#d3d8df', edgeSensitive: '#fda19a', group: '#6b7480', groupFill: 'rgba(160, 170, 185, 0.05)',
    band: '#1a1e24', bandLine: '#333942', bandHeader: '#20252c', bandException: 'rgba(180, 103, 98, 0.16)',
  },
};

// ふつうの線の描き方。width は太さ、dash は破線の間隔、corner は曲がり角の丸めの半径、
// hop・minHop は線またぎのアーチの半径と、それより小さければ描かない半径、labelRadius はラベルの背景の角の丸め、
// hitWidth はポインターを合わせやすくする見えない線の太さ、arrow は鏃の大きさ、
// arrowClearance は、鏃を曲がり角の手前で止めるときに残す線の長さ（決定記録 No.62）。
export const LINE = {
  width: 1.5, dash: '6 4', corner: 6, hop: 4.5, minHop: 2.5, labelRadius: 4, hitWidth: 12,
  arrow: { length: 11, width: 10 }, arrowClearance: 3,
};

// 線の描き方。ふつうの線は LINE と同じ値を使い、主な経路（太い線）の値をここで足す。
export const EDGE_DRAW = { ...LINE, primaryWidth: 2.5, primaryArrow: { length: 13, width: 11 } };

// ---- 鏃 --------------------------------------------------------------------------

/**
 * 区間 from→to の先に付ける鏃（塗った三角）。
 */
export function arrowHead(from, to, { length, width }, color) {
  const ux = Math.sign(to[0] - from[0]);
  const uy = Math.sign(to[1] - from[1]);
  const bx = to[0] - ux * length;
  const by = to[1] - uy * length;
  const px = (-uy * width) / 2;
  const py = (ux * width) / 2;
  return el('path', {
    class: 'lt-arrow',
    d: `M${n(to[0])} ${n(to[1])}L${n(bx + px)} ${n(by + py)}L${n(bx - px)} ${n(by - py)}Z`,
    fill: color,
  });
}

/**
 * 区間 from→to の先に付ける、開いた形の鏃（先で交わる2本の線。sequence の非同期のメッセージ）。
 * 線の太さは strokeWidth で、色は color の線で描く（塗らない）。
 */
export function openArrowHead(from, to, { length, width }, color, strokeWidth = LINE.width) {
  const ux = Math.sign(to[0] - from[0]);
  const uy = Math.sign(to[1] - from[1]);
  const bx = to[0] - ux * length;
  const by = to[1] - uy * length;
  const px = (-uy * width) / 2;
  const py = (ux * width) / 2;
  return el('path', {
    class: 'lt-arrow-open',
    d: `M${n(bx + px)} ${n(by + py)}L${n(to[0])} ${n(to[1])}L${n(bx - px)} ${n(by - py)}`,
    fill: 'none',
    stroke: color,
    'stroke-width': strokeWidth,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  });
}

// 鏃の大きさ。部品の縁の手前で曲がる線（turns）は、鏃が曲がり角にかからないよう、
// 端の区間の長さから arrowClearance を引いた長さまで縮める（幅も同じ割合で縮める。決定記録 No.62）。
export function fitArrow(arrow, tip, prev, turns) {
  if (!turns) return arrow;
  const room = Math.abs(tip[0] - prev[0]) + Math.abs(tip[1] - prev[1]) - LINE.arrowClearance;
  if (room >= arrow.length) return arrow;
  const scale = Math.max(room, 0) / arrow.length;
  return { length: arrow.length * scale, width: arrow.width * scale };
}

// 端の点 end を、隣の点 next の方へ distance だけ動かす。
export function pullBack(end, next, distance) {
  end[0] += Math.sign(next[0] - end[0]) * distance;
  end[1] += Math.sign(next[1] - end[1]) * distance;
}

// ---- 線の形 --------------------------------------------------------------------

/**
 * 折れ線の path。曲がり角は半径 corner の円弧で丸め、横の区間の hops の位置に上向きのアーチを入れる。
 * 角の半径は、前後の区間の短いほうの半分までにする。アーチを角より優先し、アーチが入らない角は半径を小さくする。
 */
export function edgePath(points, hops = [], { corner = LINE.corner, hop = LINE.hop, minHop = LINE.minHop } = {}) {
  const count = points.length;
  const lengths = points.slice(1).map(([x, y], i) => Math.abs(x - points[i][0]) + Math.abs(y - points[i][1]));
  // 区間ごとのアーチ：区間の始点からの距離 t と半径 r。隣のアーチや区間の端とは重ならない大きさにする。
  const arches = lengths.map((length, i) => {
    const [ax] = points[i];
    const ux = Math.sign(points[i + 1][0] - ax);
    const ts = (hops[i] ?? []).map((x) => (x - ax) * ux).sort((p, q) => p - q);
    return ts
      .map((t, j) => {
        const before = j > 0 ? (t - ts[j - 1]) / 2 : t;
        const after = j + 1 < ts.length ? (ts[j + 1] - t) / 2 : length - t;
        return { t, r: Math.min(hop, before - 0.5, after - 0.5) };
      })
      .filter((arch) => arch.r >= minHop);
  });
  const radii = points.map((point, i) => {
    if (i === 0 || i === count - 1) return 0;
    const last = arches[i - 1].at(-1);
    const first = arches[i][0];
    const roomBefore = last ? lengths[i - 1] - last.t - last.r - 0.5 : Infinity;
    const roomAfter = first ? first.t - first.r - 0.5 : Infinity;
    return Math.max(0, Math.min(corner, lengths[i - 1] / 2, lengths[i] / 2, roomBefore, roomAfter));
  });

  let d = `M${n(points[0][0])} ${n(points[0][1])}`;
  let pen = points[0];
  // 直線で (x, y) まで引く。すでにその位置にいれば何もしない。
  const lineTo = (x, y) => {
    if (n(x) !== n(pen[0]) || n(y) !== n(pen[1])) d += `L${n(x)} ${n(y)}`;
    pen = [x, y];
  };
  const arcTo = (r, sweep, x, y) => {
    d += `A${n(r)} ${n(r)} 0 0 ${sweep} ${n(x)} ${n(y)}`;
    pen = [x, y];
  };
  for (let i = 0; i + 1 < count; i += 1) {
    const [ax, ay] = points[i];
    const [bx, by] = points[i + 1];
    const ux = Math.sign(bx - ax);
    const uy = Math.sign(by - ay);
    for (const { t, r } of arches[i]) {
      lineTo(ax + ux * (t - r), ay);
      arcTo(r, ux > 0 ? 1 : 0, ax + ux * (t + r), ay);
    }
    const r = radii[i + 1];
    if (i + 2 < count && r > 0) {
      const vx = Math.sign(points[i + 2][0] - bx);
      const vy = Math.sign(points[i + 2][1] - by);
      lineTo(bx - ux * r, by - uy * r);
      arcTo(r, ux * vy - uy * vx > 0 ? 1 : 0, bx + vx * r, by + vy * r);
    } else {
      lineTo(bx, by);
    }
  }
  return d;
}

/**
 * 線の要素。points は配置の計算が返した点の並び、hops は線またぎの位置（findHops）、base は図の色（ライト）。
 * primary は太く強い色、async は破線、sensitive（機密データ）は専用の色で描く。sensitive は primary・async と組み合わせられる。
 * 細い線でもポインターを合わせやすいよう、見えない太い線を重ねる。
 */
export function edgeElement(edge, index, hops, base) {
  const e = EDGE_DRAW;
  const width = edge.primary ? e.primaryWidth : e.width;
  const color = edge.sensitive ? base.edgeSensitive : (edge.primary ? base.edgeStrong : base.edge);
  const arrowAt = (tip, prev, turns) => fitArrow(edge.primary ? e.primaryArrow : e.arrow, tip, prev, turns);
  const endArrow = arrowAt(edge.points.at(-1), edge.points.at(-2), edge.points.length > 2);
  const startArrow = edge.both ? arrowAt(edge.points[0], edge.points[1], edge.points.length > 2) : null;
  // 線の端を矢じりの内側まで下げ、太い線の角が矢じりの先からはみ出さないようにする。
  const inset = (arrow) => (width * arrow.length) / arrow.width + 0.5;
  const points = edge.points.map(([x, y]) => [x, y]);
  pullBack(points.at(-1), points.at(-2), inset(endArrow));
  if (startArrow) pullBack(points[0], points[1], inset(startArrow));
  const classes = ['lt-edge', edge.primary ? 'lt-primary' : null, edge.async ? 'lt-async' : null, edge.sensitive ? 'lt-sensitive' : null]
    .filter(Boolean).join(' ');
  const d = edgePath(points, hops);
  return el('g', { class: classes, 'data-edge': index, 'data-from': edge.from, 'data-to': edge.to }, [
    el('path', {
      class: 'lt-edge-line',
      d,
      fill: 'none',
      stroke: color,
      'stroke-width': width,
      'stroke-dasharray': edge.async ? e.dash : null,
    }),
    // 細い線でもポインターを合わせやすくするための、見えない太い線。書き出すときは取り除く（viewer/export.mjs）。
    el('path', { class: 'lt-edge-hit', d, fill: 'none', stroke: 'none', 'stroke-width': e.hitWidth, 'pointer-events': 'stroke', 'data-hit': '' }),
    arrowHead(edge.points.at(-2), edge.points.at(-1), endArrow, color),
    startArrow ? arrowHead(edge.points[1], edge.points[0], startArrow, color) : null,
  ]);
}

/**
 * 線のラベルの要素。背景は、まわりと同じ色にする（画面の背景の上に、tints の数だけ枠の塗りを重ねる）。
 * size は文字の大きさ（core/lanes.mjs の EDGE.labelSize）。機密データ（sensitive）の線のラベルは、線と同じ色の文字にする。
 */
export function edgeLabelElement(edge, index, base, size, tints = 0) {
  const box = edge.labelBox;
  const background = (cls, fill) => el('rect', { class: cls, x: box.x, y: box.y, width: box.width, height: box.height, rx: LINE.labelRadius, fill });
  const cls = edge.sensitive ? 'lt-edge-label lt-sensitive' : 'lt-edge-label';
  return el('g', { class: cls, 'data-edge': index, 'data-from': edge.from, 'data-to': edge.to }, [
    background('lt-edge-label-bg', base.page),
    Array.from({ length: tints }, () => background('lt-edge-label-tint', base.groupFill)),
    el('text', {
      x: box.x + box.width / 2, y: box.y + box.height / 2, 'font-size': size, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: edge.sensitive ? base.edgeSensitive : base.muted,
      'data-width': estimateWidth(edge.label, size),
    }, edge.label),
  ]);
}

/**
 * 線またぎの位置。線ごと・区間ごとに、その横の区間がほかの線の縦の区間を横切る x 座標を返す。
 * 両方の区間の内側で交わるものだけを数える（端が触れるだけの枝分かれ・合流は含めない）。
 */
export function findHops(edges) {
  const segments = edges.map((edge) => edge.points.slice(1).map((point, i) => [edge.points[i], point]));
  return edges.map((edge, i) => segments[i].map(([a, b]) => {
    if (a[1] !== b[1]) return [];
    const [x1, x2] = [Math.min(a[0], b[0]), Math.max(a[0], b[0])];
    const xs = new Set();
    segments.forEach((others, j) => {
      if (j === i) return;
      for (const [c, d] of others) {
        if (c[0] !== d[0]) continue;
        const [y1, y2] = [Math.min(c[1], d[1]), Math.max(c[1], d[1])];
        if (c[0] > x1 && c[0] < x2 && a[1] > y1 && a[1] < y2) xs.add(c[0]);
      }
    });
    return [...xs];
  }));
}

// ---- 凡例の見本 ------------------------------------------------------------------

// 凡例に出す見本の大きさ（px）。
export const SAMPLE = { width: 32, height: 16 };

/** 凡例の見本の SVG。body は見本の中身。色は図と同じクラスとテーマの CSS で決まる。 */
export function sampleSvg(body) {
  return el('svg', {
    class: 'lt-diagram', width: SAMPLE.width, height: SAMPLE.height, viewBox: `0 0 ${SAMPLE.width} ${SAMPLE.height}`, 'aria-hidden': 'true',
  }, [body]);
}

/**
 * 凡例に出す、線の種類の見本（左から右へ引いた短い線と鏃）。
 * classes は線のまとまりに足すクラス、dash は破線の間隔、open は開いた形の鏃、both は両端に鏃を付けるか、
 * reverse は右から左へ向ける（戻る線の見本）か。
 */
export function lineSample({ classes = [], width = LINE.width, color = BASE_COLORS.light.edge, dash = null, arrow = { length: 8.5, width: 8 }, open = false, both = false, reverse = false } = {}) {
  const mid = SAMPLE.height / 2;
  const [start, end] = reverse ? [SAMPLE.width - 1, 1] : [1, SAMPLE.width - 1];
  // 塗った鏃は、線の端を鏃の内側まで下げ、太い線の角が鏃の先からはみ出さないようにする。開いた鏃は、線を先まで引く。
  const inset = open ? 0 : (width * arrow.length) / arrow.width + 0.5;
  const head = (from, to) => (open ? openArrowHead(from, to, arrow, color, width) : arrowHead(from, to, arrow, color));
  return el('g', { class: ['lt-edge', ...classes].filter(Boolean).join(' ') }, [
    el('path', {
      class: 'lt-edge-line',
      d: `M${n(both ? start + Math.sign(end - start) * inset : start)} ${mid}H${n(end - Math.sign(end - start) * inset)}`,
      fill: 'none', stroke: color, 'stroke-width': width,
      'stroke-dasharray': dash,
    }),
    head([start, mid], [end, mid]),
    both ? head([end, mid], [start, mid]) : null,
  ]);
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、図の種類によらない部分。ライトの値を既定にし、祖先の要素が dark
 * （既定は data-theme="dark"）に当てはまるときはダークの値を使う。部品の種類の変数（--lt-fill・--lt-border・--lt-accent）は
 * .lt-kind-<種類> を付けた要素ならどこでも使えるので、凡例や説明カードにも使う。
 */
export function diagramStyles({ dark = '[data-theme="dark"]' } = {}) {
  const baseVars = (c) => `--lt-page:${c.page};--lt-text:${c.text};--lt-muted:${c.muted};--lt-tag-text:${c.tagText};`
    + `--lt-edge:${c.edge};--lt-edge-strong:${c.edgeStrong};--lt-edge-sensitive:${c.edgeSensitive};--lt-group:${c.group};--lt-group-fill:${c.groupFill};`
    + `--lt-band:${c.band};--lt-band-line:${c.bandLine};--lt-band-header:${c.bandHeader};--lt-band-exception:${c.bandException}`;
  const kindVars = ([fill, border, accent]) => `--lt-fill:${fill};--lt-border:${border};--lt-accent:${accent}`;
  return [
    `.lt-diagram{${baseVars(BASE_COLORS.light)}}`,
    `${dark} .lt-diagram{${baseVars(BASE_COLORS.dark)}}`,
    ...KINDS.map((kind) => `.lt-kind-${kind}{${kindVars(KIND_COLORS[kind].light)}}`),
    ...KINDS.map((kind) => `${dark} .lt-kind-${kind}{${kindVars(KIND_COLORS[kind].dark)}}`),
    '.lt-node-box{fill:var(--lt-fill);stroke:var(--lt-border)}',
    '.lt-icon{stroke:var(--lt-accent)}',
    '.lt-node-label{fill:var(--lt-text)}',
    '.lt-node-sublabel,.lt-edge-label text{fill:var(--lt-muted)}',
    '.lt-tag rect{fill:var(--lt-accent)}',
    '.lt-tag text{fill:var(--lt-tag-text)}',
    '.lt-edge-line{stroke:var(--lt-edge)}',
    '.lt-arrow{fill:var(--lt-edge)}',
    '.lt-arrow-open{stroke:var(--lt-edge)}',
    '.lt-edge-label-bg{fill:var(--lt-page)}',
    // 機密データの線（dataflow の sensitive）。主な経路の色（種類ごとの CSS）より強くするため、クラスを2つ重ねる。
    '.lt-edge.lt-sensitive .lt-edge-line{stroke:var(--lt-edge-sensitive)}',
    '.lt-edge.lt-sensitive .lt-arrow{fill:var(--lt-edge-sensitive)}',
    '.lt-edge-label.lt-sensitive text{fill:var(--lt-edge-sensitive)}',
    // 帯（core/bands.mjs）。workflow の担当・局面、dataflow の段、lifecycle の帯で使う。
    '.lt-band-line{stroke:var(--lt-band-line)}',
    '.lt-band-rule{stroke:var(--lt-group)}',
    '.lt-band-label{fill:var(--lt-muted)}',
    '.lt-band-header{fill:var(--lt-band-header)}',
    '.lt-lane-odd{fill:var(--lt-band)}',
    '.lt-exception .lt-lane-box{fill:var(--lt-band-exception)}',
  ].join('\n');
}
