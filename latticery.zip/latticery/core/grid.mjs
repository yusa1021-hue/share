// 格子（半マス単位の升目）と、その上の位置の表し方。architecture のほか、部品を格子に置く図の種類で使う。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」
//
// 向きは 0=右・1=下・2=左・3=上（DIRS）。部品の辺は right・bottom・left・top（SIDES）。
// 位置は、格子の線（line）か、部品の縁（border。線の手前か先）で表し、order で並び順を比べる。

export const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // 右・下・左・上
export const SIDE_DIR = { right: 0, bottom: 1, left: 2, top: 3 };

export const SIDES = ['right', 'bottom', 'left', 'top'];

// 部品の範囲を半マス単位の番号 [a, b) × [c, d) で表す。使われている列・行だけを残し、左上を 0 にそろえる。
export function buildGrid(nodes) {
  const spans = nodes.map((node) => ({
    node,
    a: node.col * 2,
    b: (node.col + (node.colSpan ?? 1)) * 2,
    c: node.row * 2,
    d: (node.row + (node.rowSpan ?? 1)) * 2,
  }));
  const firstCol = Math.floor(Math.min(...spans.map((s) => s.a)) / 2);
  const firstRow = Math.floor(Math.min(...spans.map((s) => s.c)) / 2);
  const cols = Math.ceil(Math.max(...spans.map((s) => s.b)) / 2) - firstCol;
  const rows = Math.ceil(Math.max(...spans.map((s) => s.d)) / 2) - firstRow;
  const boxes = spans.map((s) => ({
    node: s.node,
    a: s.a - 2 * firstCol,
    b: s.b - 2 * firstCol,
    c: s.c - 2 * firstRow,
    d: s.d - 2 * firstRow,
  }));

  // 格子の線の区間のうち、部品の内部を通るものを通れなくする。
  const blocked = new Set();
  for (const box of boxes) {
    for (let k = box.a + 1; k < box.b; k += 1) {
      for (let l = box.c; l < box.d; l += 1) blocked.add(`v${k},${l}`);
    }
    for (let l = box.c + 1; l < box.d; l += 1) {
      for (let k = box.a; k < box.b; k += 1) blocked.add(`h${k},${l}`);
    }
  }
  return { cols, rows, maxK: cols * 2, maxL: rows * 2, boxes, byId: new Map(boxes.map((box) => [box.node.id, box])), blocked };
}

export function canMove(grid, k, l, dir) {
  const [dx, dy] = DIRS[dir];
  const k2 = k + dx;
  const l2 = l + dy;
  if (k2 < 0 || l2 < 0 || k2 > grid.maxK || l2 > grid.maxL) return false;
  return !grid.blocked.has(segmentKey(k, l, dir));
}

export function segmentKey(k, l, dir) {
  const [dx, dy] = DIRS[dir];
  return dx !== 0 ? `h${Math.min(k, k + dx)},${l}` : `v${k},${Math.min(l, l + dy)}`;
}

// 各辺の接続点（格子の頂点）。上辺なら、部品の範囲の内側にある縦の線と、上端の横の線との交点。
export function ports(box, side) {
  const between = (from, to) => Array.from({ length: Math.max(0, to - from - 1) }, (_, i) => from + 1 + i);
  switch (side) {
    case 'top': return between(box.a, box.b).map((k) => [k, box.c]);
    case 'bottom': return between(box.a, box.b).map((k) => [k, box.d]);
    case 'left': return between(box.c, box.d).map((l) => [box.a, l]);
    default: return between(box.c, box.d).map((l) => [box.b, l]);
  }
}

export function directionBetween([k1, l1], [k2, l2]) {
  if (k2 > k1) return 0;
  if (l2 > l1) return 1;
  if (k2 < k1) return 2;
  return 3;
}

// 位置の表し方。格子の線そのものか、部品の縁（boundary の線の手前 dir=-1 か、先 dir=+1）。
export const line = (index) => ({ type: 'line', index });

export const border = (boundary, dir) => ({ type: 'border', boundary, dir });

// 並び順を比べるための数値。縁は、線と隣の線の間に来る。
export const order = (spec) => (spec.type === 'line' ? spec.index : spec.boundary + spec.dir * (spec.boundary % 2 === 0 ? 0.5 : 0.25));

export function borderPoint(box, side, [k, l]) {
  switch (side) {
    case 'top': return { x: line(k), y: border(box.c, 1) };
    case 'bottom': return { x: line(k), y: border(box.d, -1) };
    case 'left': return { x: border(box.a, 1), y: line(l) };
    default: return { x: border(box.b, -1), y: line(l) };
  }
}

// 向き face に対して、向き mine へ分かれる線が、向き theirs へ分かれる線より左なら true。決まらなければ null。
export function leftOf(face, mine, theirs) {
  const p = turnOf(face, mine);
  const q = turnOf(face, theirs);
  return p === null || q === null || p === q ? null : p < q;
}

// 向き d に進むときの、向き x への曲がり方（左 -1・まっすぐ 0・右 1）。x が null（部品の中）なら null。
export const turnOf = (d, x) => (x === null ? null : x === d ? 0 : x === (d + 1) % 4 ? 1 : -1);

export const reverseOf = (d) => (d === null ? null : (d + 2) % 4);

// 座標は 0.5px 単位に丸める（線の太さの半分に合い、出力も短くなる）。
export function round(value) {
  return Math.round(value * 2) / 2;
}
