// 日英の切り替えと、文言の組み立てに使う道具。

export const LANGS = ['ja', 'en'];

// 候補を前から見て、対応している最初の言語を返す。どれも使えなければ英語にする。
export function pickLang(...candidates) {
  return candidates.find((lang) => LANGS.includes(lang)) ?? 'en';
}

// JSON Pointer を読みやすい形にする（"/nodes/2/kind" → "nodes[2].kind"）。
export function formatPath(pointer, lang) {
  if (pointer === '') return lang === 'ja' ? '最上位' : 'the top level';
  return pointer
    .slice(1)
    .split('/')
    .map((segment) => segment.replace(/~1/g, '/').replace(/~0/g, '~'))
    .reduce((text, segment) => {
      if (/^\d+$/.test(segment)) return `${text}[${segment}]`;
      return text ? `${text}.${segment}` : segment;
    }, '');
}

export function parentPath(pointer) {
  return pointer.slice(0, pointer.lastIndexOf('/'));
}

export function joinList(values, lang) {
  return values.map(String).join(lang === 'ja' ? '、' : ', ');
}

// メッセージに値を埋め込むときの表記。文字列はそのまま、それ以外は JSON で書く。
export function show(value) {
  if (value === undefined) return '';
  return typeof value === 'string' ? value : JSON.stringify(value);
}
