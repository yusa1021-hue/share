// 見た目のチェックのうち、図の種類によらないもの：線のラベルの重なりと、線同士の交差。
// 配置の計算の結果（layout）を使う。仕様：docs/latticery/types/architecture.md の「4. チェック」
//
// 図の種類ごとの決まり（兄弟の線、重なってはいけない文字の範囲）は、呼ぶときに渡す。

import { error, warning } from './diagnostics.mjs';
import { edgeTarget } from './route.mjs';

// 2つの長方形が重なるか。
export const overlapsBox = (p, q) => p.x < q.x + q.width && q.x < p.x + p.width && p.y < q.y + q.height && q.y < p.y + p.height;

// 線の区間（[[x1, y1], [x2, y2]]）の並び。
export const segmentsOf = (edge) => edge.points.slice(1).map((point, i) => [edge.points[i], point]);

// 区間が、長方形の内側を通るか。
function segmentEnters([[x1, y1], [x2, y2]], box) {
  const right = box.x + box.width;
  const bottom = box.y + box.height;
  if (y1 === y2) return y1 > box.y && y1 < bottom && Math.max(x1, x2) > box.x && Math.min(x1, x2) < right;
  return x1 > box.x && x1 < right && Math.max(y1, y2) > box.y && Math.min(y1, y2) < bottom;
}

/**
 * 線のラベルと、ほかのラベル・線・部品・帯の名前（boxes）との重なり（edge/label-overlap）。
 * ラベル同士の重なりは、先に書いた線の側で1回だけ報告する。
 * 兄弟の線（sibling が true を返す組）は幹を重ねて描くので、ラベルを置いた区間と同じ直線の上にあるものは数えない。
 * boxes は、図の種類ごとの「重なってはいけない文字の範囲」（[{ kind, id, box }]。architecture は枠の名前）。
 */
export function labelOverlaps(edges, layout, { sibling, boxes = [] }) {
  const problems = [];
  const describe = (j) => ({ kind: 'edge', path: `/edges/${j}`, from: edges[j].from, to: edges[j].to });
  layout.edges.forEach((edge, i) => {
    const box = edge.labelBox;
    if (!box) return;
    const cx = box.x + box.width / 2;
    const cy = box.y + box.height / 2;
    const own = segmentsOf(edge).find(([[x1, y1], [x2, y2]]) => (y1 === y2 && y1 === cy && Math.min(x1, x2) <= cx && cx <= Math.max(x1, x2))
      || (x1 === x2 && x1 === cx && Math.min(y1, y2) <= cy && cy <= Math.max(y1, y2)));
    const onOwnLine = ([[x1, y1], [x2, y2]]) => own && ((own[0][1] === own[1][1] && y1 === y2 && y1 === own[0][1])
      || (own[0][0] === own[1][0] && x1 === x2 && x1 === own[0][0]));
    const overlaps = [];
    for (const node of layout.nodes) {
      if (overlapsBox(box, node) || (node.tagBox && overlapsBox(box, node.tagBox))) overlaps.push({ kind: 'node', id: node.id });
    }
    for (const other of boxes) {
      if (overlapsBox(box, other.box)) overlaps.push({ kind: other.kind, id: other.id });
    }
    layout.edges.forEach((other, j) => {
      if (j === i) return;
      if (j > i && other.labelBox && overlapsBox(box, other.labelBox)) overlaps.push({ ...describe(j), kind: 'label' });
      const twin = sibling(edges[i], edges[j]);
      if (segmentsOf(other).some((segment) => segmentEnters(segment, box) && !(twin && onOwnLine(segment)))) overlaps.push(describe(j));
    });
    if (overlaps.length === 0) return;
    const target = [...new Set([
      ...edgeTarget(edges[i]),
      ...overlaps.flatMap((item) => (item.id ? [item.id] : edgeTarget(edges[Number(item.path.split('/')[2])]))),
    ])];
    problems.push(error('edge/label-overlap', {
      target,
      detail: { path: `/edges/${i}`, label: edges[i].label, from: edges[i].from, to: edges[i].to, overlaps },
    }));
  });
  return problems;
}

// 線同士の交差の一覧（{ i, j, count }。i < j は線の番号）。
// 横の区間と縦の区間が、どちらの内側でも交わる点を数える（端が触れるだけの枝分かれ・合流は数えない）。
export function findCrossings(edgeLayouts) {
  const segments = edgeLayouts.map(segmentsOf);
  const inside = (value, a, b) => value > Math.min(a, b) && value < Math.max(a, b);
  const crossing = ([[x1, y1], [x2, y2]], [[x3, y3], [x4, y4]]) => {
    if (y1 === y2 && x3 === x4) return inside(x3, x1, x2) && inside(y1, y3, y4);
    if (x1 === x2 && y3 === y4) return inside(x1, x3, x4) && inside(y3, y1, y2);
    return false;
  };
  const found = [];
  for (let i = 0; i < segments.length; i += 1) {
    for (let j = i + 1; j < segments.length; j += 1) {
      const count = segments[i].reduce((sum, p) => sum + segments[j].filter((q) => crossing(p, q)).length, 0);
      if (count > 0) found.push({ i, j, count });
    }
  }
  return found;
}


/** 線同士の交差の警告（線の組ごとに1件。直し方の候補は、図の種類ごとのチェックで足す）。 */
export function crossingWarnings(edges, layout) {
  return findCrossings(layout.edges).map(({ i, j, count }) => warning('edge/crossing', {
    target: [...new Set([...edgeTarget(edges[i]), ...edgeTarget(edges[j])])],
    detail: {
      first: { path: `/edges/${i}`, from: edges[i].from, to: edges[i].to },
      second: { path: `/edges/${j}`, from: edges[j].from, to: edges[j].to },
      count,
    },
  }));
}

/** ラベルの重なり（エラー）と線の交差（警告）をまとめて調べる。 */
export function inspectDiagram(edges, layout, options = {}) {
  return [...labelOverlaps(edges, layout, options), ...crossingWarnings(edges, layout)];
}
