// 部品の種類（architecture の部品と sequence の参加者で共通）：8種類の一覧・色・記号・名前・意味の近い語。
// 仕様：docs/latticery/types/architecture.md の「kind（部品の種類）」と「部品の色と記号」

import { el, formatNumber as n } from './svg.mjs';

// 記号の大きさ（px）と線の太さ（16×16 の座標での値）。
export const ICON = { size: 14, stroke: 1.6 };

// 部品の種類ごとの色：[塗り, 枠線, 記号の色]。作り方は仕様の「部品の色と記号」を参照。
export const KIND_COLORS = {
  person: { light: ['#fef0fc', '#b576af', '#914a8c'], dark: ['#322130', '#a26a9d', '#e6a4e0'] },
  client: { light: ['#f5f4fe', '#8e83ce', '#6959ae'], dark: ['#272538', '#7f75b8', '#bcb2ff'] },
  service: { light: ['#eef6fe', '#5894d0', '#1f6cb0'], dark: ['#1a2938', '#4f84ba', '#89c3fe'] },
  datastore: { light: ['#ebfaed', '#5aa26b', '#1d7d3e'], dark: ['#1b2d1e', '#519160', '#89d298'] },
  queue: { light: ['#fef3e7', '#ba823c', '#915b02'], dark: ['#332514', '#a67537', '#ebb16c'] },
  infra: { light: ['#e5fafb', '#04a3aa', '#02787d'], dark: ['#0f2d2e', '#0d9298', '#56d3da'] },
  security: { light: ['#fff2f0', '#ca736d', '#a74541'], dark: ['#37211f', '#b46762', '#fda19a'] },
  external: { light: ['#f3f5f8', '#8b9095', '#646970'], dark: ['#26282a', '#7c8186', '#b9bec6'] },
};

// 歯が8つの歯車の外形。
function gearPath() {
  const teeth = 8;
  const points = [];
  for (let i = 0; i < teeth; i += 1) {
    for (const [t, r] of [[0.08, 4.9], [0.22, 6.6], [0.5, 6.6], [0.64, 4.9]]) {
      const a = ((i + t) / teeth) * Math.PI * 2;
      points.push(`${n(8 + r * Math.cos(a))} ${n(8 + r * Math.sin(a))}`);
    }
  }
  return `M${points.join('L')}Z`;
}

// 部品の種類ごとの記号。16×16 の座標に、塗りのない線で描く。
const ICONS = {
  person: [
    ['circle', { cx: 8, cy: 5, r: 2.8 }],
    ['path', { d: 'M2.5 14.5c0-3.2 2.5-5.3 5.5-5.3s5.5 2.1 5.5 5.3' }],
  ],
  client: [
    ['rect', { x: 1.5, y: 2.5, width: 13, height: 11, rx: 1.5 }],
    ['path', { d: 'M1.5 6h13M4 4.25h0.01M6 4.25h0.01' }],
  ],
  service: [
    ['path', { d: gearPath() }],
    ['circle', { cx: 8, cy: 8, r: 2 }],
  ],
  datastore: [
    ['ellipse', { cx: 8, cy: 3.5, rx: 5.5, ry: 2 }],
    ['path', { d: 'M2.5 3.5v9c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2v-9M2.5 8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2' }],
  ],
  queue: [
    ['rect', { x: 1, y: 3.5, width: 3.5, height: 9, rx: 0.8 }],
    ['rect', { x: 6, y: 3.5, width: 3.5, height: 9, rx: 0.8 }],
    ['path', { d: 'M11 8h4M13.2 6.2L15 8l-1.8 1.8' }],
  ],
  infra: [
    ['rect', { x: 5.5, y: 1.5, width: 5, height: 4, rx: 0.8 }],
    ['rect', { x: 1.5, y: 10.5, width: 5, height: 4, rx: 0.8 }],
    ['rect', { x: 9.5, y: 10.5, width: 5, height: 4, rx: 0.8 }],
    ['path', { d: 'M8 5.5v2.5M4 10.5V8h8v2.5' }],
  ],
  security: [
    ['path', { d: 'M8 1.5l5.5 2v4.2c0 3.3-2.3 5.6-5.5 6.8-3.2-1.2-5.5-3.5-5.5-6.8V3.5z' }],
    ['path', { d: 'M5.5 8l1.8 1.8 3.2-3.3' }],
  ],
  external: [
    ['path', { d: 'M9.5 1.5h5v5M14.5 1.5L7.5 8.5' }],
    ['path', { d: 'M12.5 9.5v4a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h4' }],
  ],
};

export const KINDS = Object.keys(ICONS);

/** 種類の記号。左上を (x, y) にして、size の大きさで描く。凡例や説明カードでも使う。 */
export function iconElement(kind, { x = 0, y = 0, size = ICON.size } = {}) {
  return el('g', {
    class: 'lt-icon',
    transform: `translate(${n(x)} ${n(y)}) scale(${n(size / 16)})`,
    fill: 'none',
    stroke: KIND_COLORS[kind].light[2],
    'stroke-width': ICON.stroke,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  }, ICONS[kind].map(([tag, attrs]) => el(tag, attrs)));
}

// 凡例に出す、部品の種類の名前。
export const kindNames = {
  ja: {
    person: '人', client: 'クライアント', service: 'サービス', datastore: 'データストア',
    queue: 'キュー', infra: '通信・基盤', security: 'セキュリティ', external: '外部サービス',
  },
  en: {
    person: 'Person', client: 'Client', service: 'Service', datastore: 'Data store',
    queue: 'Queue', infra: 'Network & infra', security: 'Security', external: 'External service',
  },
};

/**
 * 凡例の項目のうち、部品の種類の分。used（図で使われている種類の集まり）にあるものだけを、決まった順に並べる。
 * key は CSS のクラス（.lt-kind-<key>）に使い、色は core/draw.mjs の diagramStyles() で決まる。
 */
export function kindLegend(used, lang) {
  return KINDS.filter((kind) => used.has(kind)).map((kind) => ({ key: kind, label: kindNames[lang][kind], icon: iconElement(kind) }));
}

// 使えない値から、意味の近い種類への対応（schema/invalid の直し方の候補に使う）。
// キーは種類、値はその種類に当たる語。語は小文字にして、英数字以外を除いた形で書く。
export const KIND_SYNONYMS = {
  person: ['user', 'users', 'human', 'actor', 'admin', 'operator', 'customer', 'staff', 'employee'],
  client: ['browser', 'frontend', 'web', 'webapp', 'mobile', 'mobileapp', 'spa', 'ui', 'desktop', 'app'],
  service: ['server', 'api', 'backend', 'application', 'worker', 'function', 'lambda', 'job', 'batch', 'microservice', 'compute', 'container'],
  datastore: ['database', 'db', 'rdb', 'rdbms', 'sql', 'nosql', 'cache', 'storage', 'bucket', 'objectstorage', 'store', 'table', 'dwh', 'warehouse', 'datalake', 'lake', 'file', 'filesystem', 'disk'],
  queue: ['mq', 'message', 'messagequeue', 'messaging', 'broker', 'topic', 'stream', 'bus', 'eventbus', 'event', 'pubsub'],
  infra: ['network', 'cdn', 'lb', 'loadbalancer', 'gateway', 'apigateway', 'proxy', 'reverseproxy', 'dns', 'router', 'vpn'],
  security: ['auth', 'authentication', 'authorization', 'iam', 'idp', 'sso', 'waf', 'firewall', 'kms', 'vault', 'secret'],
  external: ['saas', 'thirdparty', 'partner', 'vendor', 'externalservice', 'externalapi', 'ext'],
};
