// 同じ格子の線の上を通る経路を、少しずつずらして並べる（レーン）。ラベルを置く場所も決める。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」の「線」、決定記録 No.35〜37・No.60・No.83
//
// 経路は、まっすぐな区間（run）の並びにしてから、線ごとにレーンへ割り当てる。
// 並べる順番は、2本が一緒に通る部分（共有区間）の両端で、どちら側へ分かれるかから決める。

import { border, borderPoint, leftOf, line, order, reverseOf, round, turnOf } from './grid.mjs';
import { describePath } from './route.mjs';
import { estimateWidth } from './text.mjs';

// 線とラベルの寸法（px）。laneGap はレーンの間隔、laneMargin はレーン全体の外の余白、
// labelMargin はラベルとほかの線・ラベルとの間、labelHeight はラベルの背景の高さ。
export const EDGE = { labelSize: 11, labelPaddingX: 6, labelHeight: 18, labelMargin: 8, laneGap: 12, laneMargin: 8 };

// 経路を、まっすぐな区間（run）の並びにする。最初と最後は部品の縁から始まり、縁で終わる。
export function buildRuns(route, grid) {
  const points = [
    borderPoint(grid.byId.get(route.from), route.fromSide, route.vertices[0]),
    ...route.vertices.map(([k, l]) => ({ x: line(k), y: line(l) })),
    borderPoint(grid.byId.get(route.to), route.toSide, route.vertices.at(-1)),
  ];
  const corners = [points[0]];
  for (let i = 1; i < points.length - 1; i += 1) {
    const prev = corners.at(-1);
    const here = points[i];
    const next = points[i + 1];
    const sameX = order(prev.x) === order(here.x) && order(here.x) === order(next.x);
    const sameY = order(prev.y) === order(here.y) && order(here.y) === order(next.y);
    if (!sameX && !sameY) corners.push(here);
  }
  corners.push(points.at(-1));

  const runs = [];
  for (let i = 0; i + 1 < corners.length; i += 1) {
    const p = corners[i];
    const q = corners[i + 1];
    if (order(p.x) === order(q.x)) runs.push({ axis: 'v', line: p.x.index, start: p.y, end: q.y, lane: 0, offset: 0, shared: false });
    else runs.push({ axis: 'h', line: p.y.index, start: p.x, end: q.x, lane: 0, offset: 0, shared: false });
  }
  return runs;
}

export const lowOf = (run) => Math.min(order(run.start), order(run.end));

export const highOf = (run) => Math.max(order(run.start), order(run.end));

// 区間の端で、隣の区間がどちらへ曲がるか（横の区間なら上へ -1・下へ +1、縦の区間なら左へ -1・右へ +1）。
// 部品の縁で終わる端は 0。
export function turnAt(runs, index, atHigh) {
  const run = runs[index];
  const startIsLow = order(run.start) <= order(run.end);
  const neighbourIndex = atHigh === startIsLow ? index + 1 : index - 1;
  const neighbour = runs[neighbourIndex];
  if (!neighbour) return 0;
  const far = neighbourIndex > index ? neighbour.end : neighbour.start;
  return order(far) < run.line ? -1 : 1;
}

// 幹を重ねられる線の組（sameStyle が true を返す組）ごとに、同じ接続点から出る場合の共通の先頭と、
// 同じ接続点に入る場合の共通の末尾の頂点を集める。
// 返り値のキーは "i,j"（i < j は線の番号）。
export function sharedVertices(edges, routes, sameStyle) {
  const shared = new Map();
  const key = ([k, l]) => `${k},${l}`;
  for (let i = 0; i < routes.length; i += 1) {
    for (let j = i + 1; j < routes.length; j += 1) {
      const a = routes[i];
      const b = routes[j];
      if (!a || !b || !sameStyle(edges[i], edges[j])) continue;
      const length = Math.min(a.vertices.length, b.vertices.length);
      const vertices = new Set();
      if (a.from === b.from && a.fromSide === b.fromSide) {
        for (let t = 0; t < length && key(a.vertices[t]) === key(b.vertices[t]); t += 1) vertices.add(key(a.vertices[t]));
      }
      if (a.to === b.to && a.toSide === b.toSide) {
        for (let t = 1; t <= length && key(a.vertices.at(-t)) === key(b.vertices.at(-t)); t += 1) vertices.add(key(a.vertices.at(-t)));
      }
      if (vertices.size > 0) shared.set(`${i},${j}`, vertices);
    }
  }
  return shared;
}

// 2本の経路が、格子の区間を続けて共有する部分（共有区間）。a の区間 from〜to が、b の区間 start〜finish に当たる。
// forward は、b が a と同じ向きに通るか。
export function sharedChains(a, b) {
  const chains = [];
  let t = 0;
  while (t < a.dirs.length) {
    const u = b.segments.get(a.keys[t]);
    if (u === undefined) {
      t += 1;
      continue;
    }
    const forward = b.dirs[u] === a.dirs[t];
    let to = t;
    let finish = u;
    while (to + 1 < a.dirs.length && b.segments.get(a.keys[to + 1]) === (forward ? finish + 1 : finish - 1)) {
      to += 1;
      finish = b.segments.get(a.keys[to]);
    }
    chains.push({ from: t, to, start: u, finish, forward });
    t = to + 1;
  }
  return chains;
}

// 共有区間で、a が b の左（a の進む向きに対して）にあるべきなら true、右なら false、決まらなければ null。
// 共有区間の終わりで2本が分かれる向き（より左へ曲がるほうが左）と、始まりで分かれる向き（逆向きにたどって同じように決める）から決める。
// 部品に出入りする端では、部品の中へ向かって分かれると考える（同じ接続点に出入りする2本は、そこでは決まらない）。
// 両端の結果が食い違うときは、どう並べても1回は交差するので、終わりの側の結果を使う。
export function chainSide(a, b, chain) {
  // 2本の曲がり方から、a が左なら true。どちらかが部品の中へ入る（null）か、曲がり方が同じなら null。
  const compare = leftOf;
  const end = a.dirs[chain.to];
  const bOut = chain.forward ? b.out(chain.finish + 1) : reverseOf(b.into(chain.finish));
  const atEnd = compare(end, a.out(chain.to + 1), bOut);

  const back = reverseOf(a.dirs[chain.from]);
  const bBack = chain.forward ? reverseOf(b.into(chain.start)) : b.out(chain.start + 1);
  // 逆向きにたどって左なら、進む向きに対しては右。
  const atStart = compare(back, reverseOf(a.into(chain.from)), bBack);
  return atEnd ?? (atStart === null ? null : !atStart);
}

// 共有区間から、レーンの順番を決める。返り値は、区間の組 "i:r|j:s"（線 i の r 番目の区間と、線 j の s 番目の区間）→
// 前者を上（縦の線なら左）のレーンに置くなら true。左右の関係は曲がり角を越えても変わらないので、共有区間の中のすべての区間で
// 同じ関係からレーンの順番を決める（角で内側と外側が入れ替わって交差するのを防ぐ）。
// 進む向きに対して左は、右へ進むなら上、下へ進むなら右、左へ進むなら下、上へ進むなら左。
export function pairOrders(routes) {
  const paths = routes.map((route) => (route ? describePath(route) : null));
  const orders = new Map();
  for (let i = 0; i < paths.length; i += 1) {
    for (let j = i + 1; j < paths.length; j += 1) {
      const a = paths[i];
      const b = paths[j];
      if (!a || !b) continue;
      for (const chain of sharedChains(a, b)) {
        // 両端とも決まらない（両端とも同じ接続点に出入りする）ときは、どちらでも交差しないので、i を左にそろえる。
        const left = chainSide(a, b, chain) ?? true;
        for (let t = chain.from; t <= chain.to; t += 1) {
          const u = chain.forward ? chain.start + (t - chain.from) : chain.start - (t - chain.from);
          const aFirst = left !== (a.dirs[t] === 1 || a.dirs[t] === 2);
          orders.set(`${i}:${a.runOf[t]}|${j}:${b.runOf[u]}`, aFirst);
          orders.set(`${j}:${b.runOf[u]}|${i}:${a.runOf[t]}`, !aFirst);
        }
      }
    }
  }
  return orders;
}

// 同じ線の上で重なる区間（端が触れるだけのものも含む）に、別々のレーンを割り当てる。
// ただし兄弟の線の区間は、重なる部分が共通の先頭・末尾に収まるなら、同じレーンに置く（重ねて1本の幹にする）。
// 幹として重ねた区間には shared を付ける（ラベルを置かないため）。
// また、端が格子の頂点で触れるだけの2つの区間は、そこで同じ向きへ曲がり、曲がった先で、低い側（上・左）から来る区間のほうが
// 上（左）のレーンにあるなら、同じレーンに置く（ずらさなくても重ならず、縦の線（横の線）が1本にそろう。決定記録 No.60）。
// 重なる区間の組の上下（左右）は、共有区間から決めた順番（pairOrders）に従う。決まっていない組は、端が触れるだけなら
// その点で上（左）へ曲がるほうを上（左）にし、それ以外は、上（左）へ曲がる区間ほど上（左）に置く。
// 返り値は、線（軸と番号）ごとの { axis, line, items, count }。items は区間の一覧、count はレーンの数。
export function assignLanes(runsByEdge, shared, orders) {
  const canShare = (p, q) => {
    const vertices = shared.get(`${Math.min(p.edgeIndex, q.edgeIndex)},${Math.max(p.edgeIndex, q.edgeIndex)}`);
    if (!vertices) return false;
    const lo = Math.max(p.lo, q.lo);
    const hi = Math.min(p.hi, q.hi);
    if (Math.ceil(lo) > Math.floor(hi)) return false;
    for (let t = Math.ceil(lo); t <= Math.floor(hi); t += 1) {
      if (!vertices.has(p.run.axis === 'h' ? `${t},${p.run.line}` : `${p.run.line},${t}`)) return false;
    }
    return true;
  };
  const groups = new Map();
  runsByEdge.forEach((runs, edgeIndex) => runs?.forEach((run, index) => {
    const key = `${run.axis}${run.line}`;
    const turns = [turnAt(runs, index, false), turnAt(runs, index, true)];
    // 低い側の端と高い側の端で曲がった先の区間（部品の縁で終わる端は null）。
    const startIsLow = order(run.start) <= order(run.end);
    const next = [runs[startIsLow ? index - 1 : index + 1] ?? null, runs[startIsLow ? index + 1 : index - 1] ?? null];
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push({ run, index, lo: lowOf(run), hi: highOf(run), turns, next, tendency: turns[0] + turns[1], edgeIndex });
  }));
  const rank = (p, q) => p.tendency - q.tendency || p.lo - q.lo || p.hi - q.hi || p.edgeIndex - q.edgeIndex;
  const touching = (p, q) => Math.min(p.hi, q.hi) === Math.max(p.lo, q.lo);
  // p を q より上（左）に置くか。
  const first = (p, q) => {
    const decided = orders.get(`${p.edgeIndex}:${p.index}|${q.edgeIndex}:${q.index}`);
    if (decided !== undefined) return decided;
    const point = Math.max(p.lo, q.lo);
    if (point === Math.min(p.hi, q.hi)) {
      const turn = (item) => (item.lo === point ? item.turns[0] : item.turns[1]);
      if (turn(p) !== turn(q)) return turn(p) < turn(q);
    }
    return rank(p, q) < 0;
  };

  // 同じレーンに置ける、端が触れるだけの組か（上のコメントの条件）。曲がった先のレーンは、今の割り当てで見る。
  const alignable = (p, q) => {
    if (!touching(p, q)) return false;
    const point = Math.max(p.lo, q.lo);
    if (!Number.isInteger(point) || p.lo === q.lo) return false;
    const [low, high] = p.hi === point ? [p, q] : [q, p];
    const [lowTurn, highTurn] = [low.turns[1], high.turns[0]];
    const [lowNext, highNext] = [low.next[1], high.next[0]];
    return lowTurn !== 0 && lowTurn === highTurn && lowNext && highNext && lowNext.lane < highNext.lane;
  };

  // 1つの線の区間にレーンを割り当てる。aligned は、同じレーンに置いてよい組（Set。キーは pairKey）。
  const ids = new Map();
  const pairKey = (p, q) => {
    const [a, b] = [ids.get(p), ids.get(q)].sort((m, n) => m - n);
    return `${a},${b}`;
  };
  const place = (items, aligned) => {
    const overlapping = (p, q) => Math.min(p.hi, q.hi) >= Math.max(p.lo, q.lo) && !aligned.has(pairKey(p, q));
    // 順番の決まりに従って並べる（決まりが循環するときは、rank がいちばん小さいものから置く）。
    const before = new Map(items.map((item) => [item, new Set()]));
    items.forEach((p, i) => items.slice(i + 1).forEach((q) => {
      if (!overlapping(p, q) || canShare(p, q)) return;
      if (first(p, q)) before.get(q).add(p);
      else before.get(p).add(q);
    }));
    const sequence = [];
    const rest = new Set(items);
    while (rest.size > 0) {
      const ready = [...rest].filter((item) => [...before.get(item)].every((p) => !rest.has(p)));
      const next = (ready.length > 0 ? ready : [...rest]).sort(rank)[0];
      sequence.push(next);
      rest.delete(next);
    }
    // レーンは、重なる区間のうち先に置いたものより下（右）にする。兄弟の線と重ねられるなら、そのレーンに置く。
    // 幹として重ねた範囲は sharedSpans（区間の方向の格子の番号 [low, high] の一覧）に残す（chooseLabels の avoidSharedPart で使う）。
    for (const item of items) {
      item.run.shared = false;
      item.run.sharedSpans = [];
    }
    let count = 0;
    sequence.forEach((item, i) => {
      const placed = sequence.slice(0, i);
      let lane = Math.max(0, ...placed.filter((p) => overlapping(p, item) && !canShare(p, item)).map((p) => p.run.lane + 1));
      const partner = placed.filter((p) => canShare(p, item) && overlapping(p, item) && p.run.lane >= lane).sort((p, q) => p.run.lane - q.run.lane)[0];
      if (partner) lane = partner.run.lane;
      for (const p of placed) {
        if (p.run.lane === lane && Math.min(p.hi, item.hi) > Math.max(p.lo, item.lo)) {
          p.run.shared = item.run.shared = true;
          const span = [Math.max(p.lo, item.lo), Math.min(p.hi, item.hi)];
          p.run.sharedSpans.push(span);
          item.run.sharedSpans.push(span);
        }
      }
      item.run.lane = lane;
      count = Math.max(count, lane + 1);
    });
    return count;
  };

  const all = [...groups.values()];
  all.flat().forEach((item, i) => ids.set(item, i));
  const candidates = () => {
    const found = [];
    for (const items of all) {
      items.forEach((p, i) => items.slice(i + 1).forEach((q) => {
        if (alignable(p, q)) found.push([p, q]);
      }));
    }
    return found;
  };
  // まずふつうに割り当て、そろえられる組を選んで割り当て直す。割り当て直した後に条件を満たさなくなった組は外して、やり直す。
  let aligned = new Map();
  const counts = new Map(all.map((items) => [items, place(items, new Set())]));
  let chosen = candidates();
  while (chosen.length > 0) {
    aligned = new Map(chosen.map(([p, q]) => [pairKey(p, q), [p, q]]));
    const keys = new Set(aligned.keys());
    for (const items of all) counts.set(items, place(items, keys));
    const broken = chosen.filter(([p, q]) => !alignable(p, q));
    if (broken.length === 0) break;
    chosen = chosen.filter((pair) => !broken.includes(pair));
    if (chosen.length === 0) for (const items of all) counts.set(items, place(items, new Set()));
  }
  return all.map((items) => ({ axis: items[0].run.axis, line: items[0].run.line, items, count: counts.get(items) }));
}

// レーンの位置（線からのずれ）を決める。返り値は、線ごとのレーン全体の幅（{ v: 縦の線, h: 横の線 }。どちらも 番号 → px）。
// ふつうのレーンは laneGap の間隔で並べる。ラベルは、区間の方向には anchor の前後 0.5（格子の番号）の範囲を占め、
// 区間と直角の方向にはラベルの太さ（横の区間なら高さ、縦の区間なら幅）を占める。ラベルの範囲にかかる区間やラベルがあるレーンとの間は、
// ラベルの太さの半分と labelMargin の分だけ離し、並んだ線がラベルに重ならないようにする。レーン全体の両端にも、ラベルの外に labelMargin を空ける。
// ほかの線が横切る位置に置いたラベル（crossed）のために、横切る線の側にもラベルだけのレーンを真ん中に足し、
// 横切る線をラベルの上下（左右）に分ける。そのレーンのずれを label.across に入れる。
export function placeLanes(buckets, labels, edges) {
  const { laneGap, laneMargin, labelMargin, labelHeight } = EDGE;
  const newLane = () => ({ runs: [], labels: [], offset: 0 });
  const linesByKey = new Map();
  const laneOfRun = new Map();
  for (const bucket of buckets) {
    const lanes = Array.from({ length: bucket.count }, newLane);
    for (const { run, lo, hi } of bucket.items) {
      lanes[run.lane].runs.push({ lo, hi });
      laneOfRun.set(run, lanes[run.lane]);
    }
    linesByKey.set(`${bucket.axis}${bucket.line}`, lanes);
  }
  const extra = new Map();
  labels.forEach((label, i) => {
    if (!label) return;
    const { run, anchor } = label;
    const width = labelWidth(edges[i].label);
    const [along, across] = run.axis === 'h' ? [width, labelHeight] : [labelHeight, width];
    laneOfRun.get(run).labels.push({ lo: anchor - 0.5, hi: anchor + 0.5, radius: across / 2 });
    if (label.crossed) {
      const lanes = linesByKey.get(`${run.axis === 'h' ? 'v' : 'h'}${anchor}`);
      const lane = newLane();
      lane.labels.push({ lo: run.line - 0.5, hi: run.line + 0.5, radius: along / 2 });
      lanes.splice(Math.floor(lanes.length / 2), 0, lane);
      extra.set(label, lane);
    }
  });

  const hits = (label, span) => span.lo < label.hi && span.hi > label.lo;
  // レーン p と q（p < q）の間に必要な間隔。
  const need = (p, q) => {
    let value = laneGap;
    for (const label of p.labels) {
      if (q.runs.some((span) => hits(label, span))) value = Math.max(value, label.radius + labelMargin);
      for (const other of q.labels) if (hits(label, other)) value = Math.max(value, label.radius + other.radius + labelMargin);
    }
    for (const label of q.labels) {
      if (p.runs.some((span) => hits(label, span))) value = Math.max(value, label.radius + labelMargin);
    }
    return value;
  };
  const reach = (lane) => Math.max(0, ...lane.labels.map((label) => label.radius + labelMargin));
  const end = laneGap / 2 + laneMargin;
  const widths = { v: new Map(), h: new Map() };
  for (const [key, lanes] of linesByKey) {
    const positions = [];
    lanes.forEach((lane, q) => {
      let position = Math.max(q === 0 ? end : positions[q - 1] + laneGap, reach(lane));
      for (let p = 0; p < q; p += 1) position = Math.max(position, positions[p] + need(lanes[p], lane));
      positions.push(position);
    });
    const width = Math.max(positions.at(-1) + end, ...lanes.map((lane, p) => positions[p] + reach(lane)));
    lanes.forEach((lane, p) => { lane.offset = positions[p] - width / 2; });
    widths[key[0]].set(Number(key.slice(1)), width);
  }
  for (const [run, lane] of laneOfRun) run.offset = lane.offset;
  for (const [label, lane] of extra) label.across = lane.offset;
  return widths;
}

// ラベルを置く区間と位置を決める。返り値は線ごとの { run, anchor }（ラベルがなければ null）。
// 位置 anchor は区間の方向に沿った格子の番号で、格子の線（整数）か、隣り合う線の中間（.5）。区間の両端（曲がり角や部品の縁）には置かない。
// 区間は、幹として重ねていないもの → 横向き → 長いもの の順に試す（幹にラベルがあると、どの線のラベルか分からなくなるため）。
// 区間の中では中央に近い位置を優先し（同じ近さなら 通路の中心線 → 線の中間 → 列・行の中心線 の順）、
// ほかの線が横切る位置と、同じレーンの別のラベルに近すぎる位置は避ける。どの区間にも避けられる位置がなければ、
// ほかのラベルに近すぎない位置のうち、いちばん好ましい区間の、中央にいちばん近い位置に置き、crossed を付ける
// （横切る線をラベルの上下（左右）に分ける。placeLanes を参照）。どこもほかのラベルに近すぎるときだけ、近すぎる位置に置く。
// ラベルは、置ける位置（横切られない位置）の少ない線から順に置く。幹を重ねた兄弟の線で、置ける位置が幹の上の1つしかない線より先に、
// ほかにも置ける線がその位置を取ると、2つのラベルが重なるため。
// avoidSharedPart を true にすると、区間の一部だけを幹として重ねているとき、重ねていない部分の位置を先に試す
// （区間は、重ねていない位置が1つもないときだけ「幹」として後回しにする）。今は lifecycle だけが使う（決定記録 No.98）。
export function chooseLabels(edges, runsByEdge, { avoidSharedPart = false } = {}) {
  const pointKey = (run, t) => (run.axis === 'h' ? `${t},${run.line}` : `${run.line},${t}`);
  const through = new Map();
  runsByEdge.forEach((runs, edgeIndex) => runs?.forEach((run) => {
    for (let t = Math.ceil(lowOf(run)); t <= Math.floor(highOf(run)); t += 1) {
      const key = pointKey(run, t);
      if (!through.has(key)) through.set(key, []);
      through.get(key).push({ edgeIndex, axis: run.axis });
    }
  }));
  const kindRank = (t) => (Number.isInteger(t) ? (t % 2 === 0 ? 0 : 2) : 1);
  const inShared = (run, t) => avoidSharedPart && (run.sharedSpans ?? []).some(([lo, hi]) => t >= lo && t <= hi);
  const candidatesOf = (run) => {
    const lo = lowOf(run);
    const hi = highOf(run);
    const middle = (lo + hi) / 2;
    const list = [];
    for (let t = Math.ceil(lo * 2) / 2; t <= hi; t += 0.5) if (t > lo && t < hi) list.push(t);
    return list.sort((p, q) => Number(inShared(run, p)) - Number(inShared(run, q))
      || Math.abs(p - middle) - Math.abs(q - middle) || kindRank(p) - kindRank(q) || p - q);
  };
  // 幹として後回しにする区間か。avoidSharedPart のときは、重ねていない位置が1つもない区間だけ。
  const trunk = (run) => (avoidSharedPart ? candidatesOf(run).every((t) => inShared(run, t)) : run.shared);
  // 同じレーンに置いたラベルの位置。隣り合う位置（差が1未満）には置かない。
  const placed = new Map();
  const laneKey = (run) => `${run.axis}${run.line}:${run.lane}`;
  const crowded = (run, t) => (placed.get(laneKey(run)) ?? []).some((other) => Math.abs(other - t) < 1);
  const crossed = (run, t, edgeIndex) => Number.isInteger(t)
    && (through.get(pointKey(run, t)) ?? []).some((other) => other.edgeIndex !== edgeIndex && other.axis !== run.axis);
  const score = (run) => Math.abs(order(run.end) - order(run.start)) * (run.axis === 'h' ? 1.5 : 1);

  const room = (edgeIndex) => runsByEdge[edgeIndex].reduce((sum, run) => sum + candidatesOf(run).filter((t) => !crossed(run, t, edgeIndex)).length, 0);
  const labeled = edges.map((edge, edgeIndex) => edgeIndex).filter((edgeIndex) => edges[edgeIndex].label && runsByEdge[edgeIndex]);
  const rooms = new Map(labeled.map((edgeIndex) => [edgeIndex, room(edgeIndex)]));
  const choices = new Array(edges.length).fill(null);
  for (const edgeIndex of labeled.sort((p, q) => rooms.get(p) - rooms.get(q) || p - q)) choices[edgeIndex] = choose(edgeIndex);
  return choices;

  function choose(edgeIndex) {
    const runs = runsByEdge[edgeIndex];
    const ranked = [...runs].sort((p, q) => Number(trunk(p)) - Number(trunk(q)) || score(q) - score(p));
    let choice = null;
    let fallback = null;
    for (const run of ranked) {
      const candidates = candidatesOf(run);
      if (candidates.length === 0) continue;
      const roomy = candidates.find((t) => !crowded(run, t));
      if (roomy !== undefined) choice ??= { run, anchor: roomy };
      fallback ??= { run, anchor: candidates[0] };
      const free = candidates.find((t) => !crowded(run, t) && !crossed(run, t, edgeIndex));
      if (free !== undefined) {
        choice = { run, anchor: free };
        break;
      }
    }
    choice ??= fallback;
    // どの区間にも置ける位置がない（区間がすべて部品の縁から通路の中心線までの短いもの）ことは、今の経路の作り方では起きない。
    choice ??= { run: ranked[0], anchor: (lowOf(ranked[0]) + highOf(ranked[0])) / 2 };
    choice.crossed = crossed(choice.run, choice.anchor, edgeIndex);
    const key = laneKey(choice.run);
    if (!placed.has(key)) placed.set(key, []);
    placed.get(key).push(choice.anchor);
    return choice;
  }
}

// 線の中間に置くラベルと、両側の線との間に空ける幅。両側の線に並ぶレーン（ほかのラベルの分を含む）の半分か、labelMargin の大きいほう。
// lanes は、その方向の線の番号ごとのレーン全体の幅（placeLanes の返り値）。
export function labelSides(lanes, t) {
  const side = (k) => Math.max(EDGE.labelMargin, (lanes.get(k) ?? 0) / 2);
  return [side(Math.floor(t)), side(Math.ceil(t))];
}

// ラベルの位置（格子の番号）の座標。線の中間なら、両側に空ける幅を除いた範囲の中央。
export function anchorAt(A, lanes, t) {
  if (Number.isInteger(t)) return A.at(line(t));
  const [before, after] = labelSides(lanes, t);
  return (A.at(line(Math.floor(t))) + before + A.at(line(Math.ceil(t))) - after) / 2;
}

export function labelWidth(text) {
  return estimateWidth(text, EDGE.labelSize) + 2 * EDGE.labelPaddingX;
}

export function edgePoints(runs, X, Y) {
  const across = (run) => (run.axis === 'v' ? X.at(line(run.line)) : Y.at(line(run.line))) + run.offset;
  const first = runs[0];
  const last = runs.at(-1);
  const points = [first.axis === 'v' ? [across(first), Y.at(first.start)] : [X.at(first.start), across(first)]];
  for (let i = 0; i + 1 < runs.length; i += 1) {
    const run = runs[i];
    const next = runs[i + 1];
    points.push(run.axis === 'v' ? [across(run), across(next)] : [across(next), across(run)]);
  }
  points.push(last.axis === 'v' ? [across(last), Y.at(last.end)] : [X.at(last.end), across(last)]);
  return points.map(([px, py]) => [round(px), round(py)]);
}
