// 図の種類によらない診断のメッセージ（日英）。図の種類の messages.mjs に同じコードがあれば、そちらを使う（core/check.mjs）。
// 各項目は { ja: { message, fixes }, en: { message, fixes } } で、どちらも detail を受け取る関数。

import { ID_PATTERN } from './diagnostics.mjs';
import { formatPath, joinList, parentPath, show } from './i18n.mjs';

const TYPE_NAMES = {
  ja: {
    object: 'オブジェクト', array: '配列', string: '文字列', number: '数値',
    integer: '整数', boolean: '真偽値（true か false）', null: 'null',
  },
  en: {
    object: 'an object', array: 'an array', string: 'a string', number: 'a number',
    integer: 'an integer', boolean: 'a boolean (true or false)', null: 'null',
  },
};

const round = (n) => Number(n.toFixed(6));
const neighbours = (value, step) => {
  const lower = round(Math.floor(value / step) * step);
  return [lower, round(lower + step)];
};

const SCHEMA_MESSAGES = {
  type: {
    ja: (p, d) => `${p} の型が違います（${TYPE_NAMES.ja[d.expected]}が必要ですが、${TYPE_NAMES.ja[d.actual]}になっています）`,
    en: (p, d) => `${p} has the wrong type (expected ${TYPE_NAMES.en[d.expected]}, got ${TYPE_NAMES.en[d.actual]})`,
  },
  required: {
    ja: (p, d) => `${p} に必須の項目「${d.property}」がありません`,
    en: (p, d) => `${p} is missing the required field "${d.property}"`,
  },
  additionalProperties: {
    ja: (p) => `${p} は定義されていない項目です`,
    en: (p) => `${p} is not a defined field`,
  },
  enum: {
    ja: (p, d) => `${p} の値「${show(d.value)}」は使えません`,
    en: (p, d) => `${p} has an unsupported value "${show(d.value)}"`,
  },
  const: {
    ja: (p, d) => `${p} の値が違います（${show(d.expected)} にする必要があります）`,
    en: (p, d) => `${p} must be ${show(d.expected)}`,
  },
  minLength: {
    ja: (p, d) => (d.limit === 1 ? `${p} が空です` : `${p} が短すぎます（${d.actual}文字。${d.limit}文字以上が必要です）`),
    en: (p, d) => (d.limit === 1 ? `${p} is empty` : `${p} is too short (${d.actual} characters; at least ${d.limit} are required)`),
  },
  maxLength: {
    ja: (p, d) => `${p} が長すぎます（${d.actual}文字。上限は${d.limit}文字です）`,
    en: (p, d) => `${p} is too long (${d.actual} characters; the limit is ${d.limit})`,
  },
  pattern: {
    ja: (p, d) => (d.pattern === ID_PATTERN
      ? `${p} の「${show(d.value)}」は ID に使えない形です`
      : `${p} の「${show(d.value)}」が決められた形になっていません`),
    en: (p, d) => (d.pattern === ID_PATTERN
      ? `${p} "${show(d.value)}" is not a valid ID`
      : `${p} "${show(d.value)}" does not match the required format`),
  },
  minimum: {
    ja: (p, d) => `${p} の値 ${d.actual} は小さすぎます（${d.limit} 以上が必要です）`,
    en: (p, d) => `${p} is ${d.actual}, below the minimum of ${d.limit}`,
  },
  maximum: {
    ja: (p, d) => `${p} の値 ${d.actual} は大きすぎます（${d.limit} 以下が必要です）`,
    en: (p, d) => `${p} is ${d.actual}, above the maximum of ${d.limit}`,
  },
  multipleOf: {
    ja: (p, d) => `${p} の値 ${d.actual} は ${d.step} 刻みになっていません`,
    en: (p, d) => `${p} is ${d.actual}, which is not a multiple of ${d.step}`,
  },
  minItems: {
    ja: (p, d) => `${p} の数が足りません（${d.actual}個。${d.limit}個以上が必要です）`,
    en: (p, d) => `${p} has too few items (${d.actual}; at least ${d.limit} are required)`,
  },
  maxItems: {
    ja: (p, d) => `${p} の数が多すぎます（${d.actual}個。上限は${d.limit}個です）`,
    en: (p, d) => `${p} has too many items (${d.actual}; the limit is ${d.limit})`,
  },
  uniqueItems: {
    ja: (p, d) => `${p} は ${formatPath(`${parentPath(d.path)}/${d.duplicateOf}`, 'ja')} と同じ値です`,
    en: (p, d) => `${p} duplicates ${formatPath(`${parentPath(d.path)}/${d.duplicateOf}`, 'en')}`,
  },
};

const SCHEMA_FIXES = {
  type: {
    ja: (d) => [`${TYPE_NAMES.ja[d.expected]}に直す`],
    en: (d) => [`Change it to ${TYPE_NAMES.en[d.expected]}`],
  },
  required: {
    ja: (d) => [`「${d.property}」を追加する`],
    en: (d) => [`Add "${d.property}"`],
  },
  additionalProperties: {
    ja: (d) => (d.suggestion
      ? [`「${d.suggestion}」の書き間違いなら直す`, '不要なら消す']
      : [`この項目を消す（使える項目：${joinList(d.allowed, 'ja')}）`]),
    en: (d) => (d.suggestion
      ? [`If this is a typo for "${d.suggestion}", fix it`, 'Otherwise remove it']
      : [`Remove this field (allowed fields: ${joinList(d.allowed, 'en')})`]),
  },
  enum: {
    ja: (d) => [
      ...(d.suggestion ? [`「${d.suggestion}」に直す`] : []),
      ...(d.similar ? [`意味の近い「${d.similar}」に直す`] : []),
      `使える値：${joinList(d.allowed, 'ja')}`,
    ],
    en: (d) => [
      ...(d.suggestion ? [`Change it to "${d.suggestion}"`] : []),
      ...(d.similar ? [`Change it to "${d.similar}", the closest in meaning`] : []),
      `Allowed values: ${joinList(d.allowed, 'en')}`,
    ],
  },
  const: {
    ja: (d) => [`${show(d.expected)} にする`],
    en: (d) => [`Set it to ${show(d.expected)}`],
  },
  minLength: {
    ja: (d) => (d.limit === 1 ? ['空にせず、値を入れる'] : [`${d.limit}文字以上にする`]),
    en: (d) => (d.limit === 1 ? ['Enter a value instead of leaving it empty'] : [`Use at least ${d.limit} characters`]),
  },
  maxLength: {
    ja: (d) => [`${d.limit}文字以内に短くする`],
    en: (d) => [`Shorten it to ${d.limit} characters or fewer`],
  },
  pattern: {
    ja: (d) => (d.pattern === ID_PATTERN ? ['英字で始め、英数字・「-」・「_」だけを使う'] : [`形式 ${d.pattern} に合わせる`]),
    en: (d) => (d.pattern === ID_PATTERN
      ? ['Start with a letter and use only letters, digits, "-", and "_"']
      : [`Match the format ${d.pattern}`]),
  },
  minimum: {
    ja: (d) => [`${d.limit} 以上にする`],
    en: (d) => [`Use ${d.limit} or more`],
  },
  maximum: {
    ja: (d) => [`${d.limit} 以下にする`],
    en: (d) => [`Use ${d.limit} or less`],
  },
  multipleOf: {
    ja: (d) => {
      const [lower, upper] = neighbours(d.actual, d.step);
      return [`${d.step} 刻みの値（${lower} か ${upper} など）にする`];
    },
    en: (d) => {
      const [lower, upper] = neighbours(d.actual, d.step);
      return [`Use a multiple of ${d.step}, such as ${lower} or ${upper}`];
    },
  },
  minItems: {
    ja: (d) => [`${d.limit}個以上にする`],
    en: (d) => [`Add items until there are at least ${d.limit}`],
  },
  maxItems: {
    ja: (d) => [`${d.limit}個以下に減らす`],
    en: (d) => [`Reduce it to ${d.limit} items or fewer`],
  },
  uniqueItems: {
    ja: () => ['重複している値を消す'],
    en: () => ['Remove the duplicate'],
  },
};

export const coreMessages = {
  'json/invalid': {
    ja: {
      message: (d) => `JSON として読み込めません（${d.reason}）`,
      fixes: () => ['カンマ・括弧・引用符などの書き方の誤りを直す'],
    },
    en: {
      message: (d) => `The input is not valid JSON (${d.reason})`,
      fixes: () => ['Fix the syntax error (commas, brackets, quotes, etc.)'],
    },
  },
  'type/unknown': {
    ja: {
      message: (d) => (d.value === undefined ? '図の種類（type）が指定されていません' : `図の種類「${show(d.value)}」には対応していません`),
      fixes: (d) => [`type に ${joinList(d.supported, 'ja')} のどれかを書く`],
    },
    en: {
      message: (d) => (d.value === undefined ? 'The diagram type ("type") is missing' : `The diagram type "${show(d.value)}" is not supported`),
      fixes: (d) => [`Set type to one of: ${joinList(d.supported, 'en')}`],
    },
  },
  'schema/invalid': {
    ja: {
      message: (d) => SCHEMA_MESSAGES[d.keyword].ja(formatPath(d.path, 'ja'), d),
      fixes: (d) => SCHEMA_FIXES[d.keyword].ja(d),
    },
    en: {
      message: (d) => SCHEMA_MESSAGES[d.keyword].en(formatPath(d.path, 'en'), d),
      fixes: (d) => SCHEMA_FIXES[d.keyword].en(d),
    },
  },
  'id/duplicate': {
    ja: {
      message: (d) => `ID「${d.id}」が${d.paths.length}か所で使われています（${joinList(d.paths.map((path) => formatPath(path, 'ja')), 'ja')}）`,
      fixes: () => ['重複しないように、ID を変える'],
    },
    en: {
      message: (d) => `The ID "${d.id}" is used ${d.paths.length} times (${joinList(d.paths.map((path) => formatPath(path, 'en')), 'en')})`,
      fixes: () => ['Change the IDs so that each one is unique'],
    },
  },
  'text/too-long': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} が長めです（表示幅 ${d.units}。目安は ${d.limit} まで：全角${d.limit / 2}文字・半角${d.limit}文字）`,
      fixes: () => ['短い言い方にする', '詳しい説明は説明カード（notes）に移す'],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')} is longer than recommended (display width ${d.units}; aim for ${d.limit} or less, i.e. ${d.limit / 2} full-width or ${d.limit} half-width characters)`,
      fixes: () => ['Use shorter wording', 'Move the details to a note card (notes)'],
    },
  },
};
