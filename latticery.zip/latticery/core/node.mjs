// 部品の箱（architecture の部品・sequence の参加者・workflow の手順で共通）：寸法の計算と描き方。
// 箱は、淡い塗りと色付きの枠線で描き、名前の左に種類の記号を置く。補足（sublabel）は名前の下、札（tag）は右上。
// 形は四角のほかに、カプセル（角の丸みが高さの半分）とひし形があり、種類ごとに style で決める（決定記録 No.87）。
// 仕様：docs/latticery/types/architecture.md の「大きさと位置」「部品の色と記号」、
// docs/latticery/types/workflow.md の「手順の形」

import { el } from './svg.mjs';
import { estimateWidth } from './text.mjs';
import { ICON, KIND_COLORS, iconElement } from './kinds.mjs';
import { BASE_COLORS } from './draw.mjs';

// 箱の寸法（px）。文字の大きさ・余白・最小幅と、補足の有無による2通りの高さ。
export const NODE = {
  minWidth: 112, paddingX: 14, iconSize: ICON.size, iconGap: 6,
  labelSize: 14, sublabelSize: 12, tagSize: 10, tagPaddingX: 6, tagInset: 12, tagHeight: 16,
  height: 44, heightWithSublabel: 60,
};

// 箱の描き方。radius は角の丸め、sublabelOffset は名前と補足の間隔。
export const NODE_DRAW = { radius: 6, strokeWidth: 1.25, sublabelOffset: 18, iconStroke: ICON.stroke };

// 種類ごとの色・クラス・記号・形。既定は部品の種類（core/kinds.mjs）。
export const KIND_STYLE = {
  colors: KIND_COLORS,
  className: (kind) => `lt-kind-${kind}`,
  icon: iconElement,
  hasIcon: () => true,
  shape: () => 'box',
};

// カプセルとひし形の寸法。capsuleEnds は左右の丸い端の分の幅、diamond は文字の帯の外に取る余白と、いちばん低い高さ。
const SHAPE = { capsuleEnds: 24, diamondPad: 10, diamondMinHeight: 64 };

/**
 * 箱の大きさ。名前（記号を含む）・補足・札が収まる幅と、補足の有無で決まる高さ。
 * カプセルは左右の丸い端の分だけ広げ、ひし形は文字の帯（名前と補足の高さ）が中に収まるまで広げる。
 */
export function nodeSize(node, style = KIND_STYLE) {
  const m = NODE;
  const icon = style.hasIcon(node.kind) ? m.iconSize + m.iconGap : 0;
  const labelLine = icon + estimateWidth(node.label, m.labelSize, { bold: true });
  const sublabel = node.sublabel ? estimateWidth(node.sublabel, m.sublabelSize) : 0;
  const tag = node.tag ? estimateWidth(node.tag, m.tagSize, { bold: true }) + 2 * m.tagPaddingX + 2 * m.tagInset : 0;
  const width = Math.ceil(Math.max(m.minWidth, labelLine + 2 * m.paddingX, sublabel + 2 * m.paddingX, tag));
  const height = node.sublabel ? m.heightWithSublabel : m.height;
  const shape = style.shape(node.kind);
  if (shape === 'capsule') return { width: width + SHAPE.capsuleEnds, height };
  if (shape !== 'diamond') return { width, height };
  // ひし形：高さ d のひし形の、中心から上下 b/2 の帯の幅は d の (1 - b/d) 倍。その幅に文字が収まるようにする。
  const band = (node.sublabel ? NODE_DRAW.sublabelOffset + m.sublabelSize : m.labelSize) + 2 * SHAPE.diamondPad;
  const diamondHeight = Math.max(SHAPE.diamondMinHeight, Math.ceil(band * 2));
  const text = Math.max(labelLine, sublabel) + 2 * SHAPE.diamondPad;
  return { width: Math.ceil(Math.max(m.minWidth, text / (1 - band / diamondHeight))), height: diamondHeight };
}

/** 札（tag）の範囲。箱の右上に、枠線に重ねて置く。node は位置（x・y）と大きさ（width）を持つもの。 */
export function tagBox(node) {
  const m = NODE;
  const width = estimateWidth(node.tag, m.tagSize, { bold: true }) + 2 * m.tagPaddingX;
  return { x: node.x + node.width - m.tagInset - width, y: node.y - m.tagHeight / 2, width, height: m.tagHeight };
}

/**
 * 線の端を避けた札の範囲。ends は線の端の点（[x, y]）の一覧。上の辺に着く線の端が右上の札に重なる
 * （鏃の幅の分の gap を含む）ときは、札を上の辺に沿って動かす。候補は、左端と、線の端のすぐ右・すぐ左。
 * 箱の幅に収まる候補を先に、その中で右上に近いものを選ぶ。どこも重なるなら、右上のままにする。
 * bottom を true にすると、上の辺に箱の幅に収まる候補がないとき、下の辺（右下から）で同じように探し、
 * 収まる候補があればそこに置く。今は dataflow と lifecycle が使い、bottom は lifecycle だけ（決定記録 No.94・No.98）。
 */
export function tagBoxAvoiding(node, ends, { gap = 8, bottom = false } = {}) {
  const right = tagBox(node);
  const inside = (x) => x >= node.x && x + right.width <= node.x + node.width;
  // 辺の y にある線の端を避けた候補を、好ましい順に並べる。
  const along = (edgeY) => {
    const onEdge = ends.filter(([, y]) => Math.abs(y - edgeY) < 1).map(([x]) => x);
    const hits = (x) => onEdge.some((end) => end > x - gap && end < x + right.width + gap);
    return [right.x, node.x + NODE.tagInset, ...onEdge.flatMap((end) => [end + gap, end - gap - right.width])]
      .filter((x) => !hits(x))
      .sort((p, q) => Number(inside(q)) - Number(inside(p)) || Math.abs(p - right.x) - Math.abs(q - right.x));
  };
  const top = along(node.y);
  if (top.length > 0 && (inside(top[0]) || !bottom)) return { ...right, x: top[0] };
  if (bottom) {
    const [x] = along(node.y + node.height).filter(inside);
    if (x !== undefined) return { ...right, x, y: node.y + node.height - NODE.tagHeight / 2 };
  }
  return top.length > 0 ? { ...right, x: top[0] } : right;
}

/**
 * 箱の要素。node は種類・名前・補足・札と、位置と大きさ（x・y・width・height）、札があれば範囲（tagBox）を持つもの。
 * attrs は、いちばん外の要素に足す属性（つながりの強調の目印など）。
 */
export function nodeElement(node, attrs = {}, style = KIND_STYLE) {
  const m = NODE;
  const base = BASE_COLORS.light;
  const [fill, border, accent] = style.colors[node.kind].light;
  const cx = node.x + node.width / 2;
  const cy = node.y + node.height / 2;
  const iconWidth = style.hasIcon(node.kind) ? m.iconSize + m.iconGap : 0;
  const labelWidth = estimateWidth(node.label, m.labelSize, { bold: true });
  // 記号と名前をひとまとまりとして、左右の中央に置く。
  const left = cx - (iconWidth + labelWidth) / 2;
  const titleY = node.sublabel ? cy - NODE_DRAW.sublabelOffset / 2 : cy;
  return el('g', { class: `lt-node ${style.className(node.kind)}`, ...attrs }, [
    shapeElement(node, style.shape(node.kind), fill, border),
    style.icon(node.kind, { x: left, y: titleY - m.iconSize / 2 }),
    el('text', {
      class: 'lt-node-label',
      x: left + iconWidth, y: titleY, 'font-size': m.labelSize, 'font-weight': 700, 'dominant-baseline': 'central',
      fill: base.text,
      'data-width': labelWidth,
    }, node.label),
    node.sublabel ? el('text', {
      class: 'lt-node-sublabel',
      x: cx, y: titleY + NODE_DRAW.sublabelOffset, 'font-size': m.sublabelSize, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': estimateWidth(node.sublabel, m.sublabelSize),
    }, node.sublabel) : null,
    node.tag ? tagElement(node, accent, base) : null,
  ]);
}

// 箱の形。四角・カプセル（角の丸みが高さの半分）・ひし形。
function shapeElement(node, shape, fill, border) {
  const paint = { fill, stroke: border, 'stroke-width': NODE_DRAW.strokeWidth };
  if (shape === 'diamond') {
    const [cx, cy] = [node.x + node.width / 2, node.y + node.height / 2];
    const points = [[cx, node.y], [node.x + node.width, cy], [cx, node.y + node.height], [node.x, cy]];
    return el('path', { class: 'lt-node-box', d: `M${points.map(([x, y]) => `${x} ${y}`).join('L')}Z`, ...paint });
  }
  return el('rect', {
    class: 'lt-node-box',
    x: node.x, y: node.y, width: node.width, height: node.height,
    rx: shape === 'capsule' ? node.height / 2 : NODE_DRAW.radius,
    ...paint,
  });
}

// 札は箱の右上に、枠線に重ねて置く（範囲は tagBox）。
function tagElement(node, accent, base) {
  const m = NODE;
  const box = node.tagBox;
  return el('g', { class: 'lt-tag' }, [
    el('rect', { x: box.x, y: box.y, width: box.width, height: box.height, rx: box.height / 2, fill: accent }),
    el('text', {
      x: box.x + box.width / 2, y: box.y + box.height / 2, 'font-size': m.tagSize, 'font-weight': 700, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.tagText,
      'data-width': estimateWidth(node.tag, m.tagSize, { bold: true }),
    }, node.tag),
  ]);
}
