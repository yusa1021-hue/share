// 図の種類の登録。種類を増やすときは、ここに1行足す（共通仕様「12. 図の種類を増やすとき」）。
//
// schema は skills/latticery/ からのスキーマの場所。読み込み方が実行環境ごとに違うため、ここでは読み込まない
// （コマンドはファイルから、閲覧画面は雛形 HTML に埋め込んだものから読む）。

import { createArchitectureType } from '../types/architecture/index.mjs';

export const TYPE_ENTRIES = {
  architecture: { create: createArchitectureType, schema: 'types/architecture/schema.json' },
};

/** schemas（{ 種類: スキーマの中身 }）から、core/check.mjs に渡す types を作る。 */
export function createTypes(schemas) {
  return Object.fromEntries(Object.entries(TYPE_ENTRIES).map(([name, entry]) => [name, entry.create(schemas[name])]));
}
