// 格子の上で、部品と部品をつなぐ直角の線の経路を探す。architecture のほか、線でつなぐ図の種類で使う。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」の「線」、決定記録 No.82
//
// 状態（頂点・進む向き・一緒に通っている線）についてのダイクストラ法で、長さ・曲がる回数・交差・込み合いの重み（COST）が
// 少ない経路を選ぶ。すべて決めた後、主な経路以外をもう一度探し直す。

import { error } from './diagnostics.mjs';
import { DIRS, SIDES, SIDE_DIR, canMove, directionBetween, leftOf, ports, reverseOf, segmentKey } from './grid.mjs';

// 線についての診断の対象。ID があればその ID、なければ始点と終点の部品の ID。
export function edgeTarget(edge) {
  return edge.id ? [edge.id] : [...new Set([edge.from, edge.to])];
}

// 経路の選び方の重み。小さいほど好ましい。
// 辺の重み：相手の方を向いた辺は 0、横を向いた辺は sidePerpendicular、反対を向いた辺は sideAway。
// axis は、相手の方を向いた2つの辺のうち、主な向き（相手が主に左右にあれば左右）でない辺に加える重み。
// 曲がる回数が1回増えるより重くし、左右に並ぶ部品どうしは左右の辺でつなぐ（枝分かれする線が木の形になる）ようにする。
// junction は、ほかの線が通る頂点で曲がる場合の重み。touch は、ほかの線が曲がる頂点をまっすぐ通る場合の重み。
// どちらも、線が込み合って見分けにくくなるのを避けるため（両端の部品の接続点では加えない）。
// mixedPort は、同じ接続点に「出ていく線」と「入ってくる線」が混ざる場合の重み（同じ2つの部品の間の往復は除く）。
export const COST = {
  step: 1, bend: 3, cross: 5, junction: 3, touch: 1, share: 0.5, mixedPort: 4,
  sidePerpendicular: 2, sideAway: 5, axis: 3.5,
};

export function routeEdges(edges, grid, { sibling, priority = (edge) => Number(!edge.primary) }) {
  const decided = [];
  const routes = new Array(edges.length).fill(null);
  const diagnostics = [];
  // priority の小さい線から先に決める（0 は architecture の主な経路。同じ順位の線は書いた順）。
  const sequence = edges
    .map((edge, index) => ({ edge, index }))
    .sort((p, q) => priority(p.edge) - priority(q.edge) || p.index - q.index);
  for (const { edge, index } of sequence) {
    const route = findRoute(edge, grid, usageOf(edge, decided, sibling));
    if (!route) {
      diagnostics.push(error('edge/no-route', {
        target: edgeTarget(edge),
        detail: { path: `/edges/${index}`, from: edge.from, to: edge.to },
      }));
      continue;
    }
    decided.push({ edge, index, route, path: describePath(route) });
    routes[index] = route;
  }
  // 引き直し：主な経路以外の線を、ほかのすべての線（後から決めた線も含む）が決まった状態で、同じ順にもう一度探す。
  // 先に決めた線は、後の線の接続点や通り道を知らずに選んでいるため。priority が 0 の線（architecture の主な経路）は、
  // まっすぐに保つため引き直さない。
  // 2回目の引き直しは、乱数の図 1000枚で交差が 1% も減らなかったので、1回だけにする（決定記録 No.82）。
  for (const entry of decided) {
    if (priority(entry.edge) === 0) continue;
    entry.route = findRoute(entry.edge, grid, usageOf(entry.edge, decided.filter((done) => done !== entry), sibling));
    entry.path = describePath(entry.route);
    routes[entry.index] = entry.route;
  }
  return { routes, diagnostics };
}

// 経路を探すときに避けるものとして、決まった経路（done の一覧）の使い方を記録する。
// all は交差を数えるため、すべての線を記録する。
// others は重なりと込み合いを数えるため、兄弟の線（sibling が true を返す組。幹を共有して同じ位置で枝分かれする線）を除く。
// chains は、共有区間の両端での分かれ方による交差を見込むため、すべての線の区間と各頂点での向きを記録する（chainStep を参照）。
export function usageOf(edge, done, sibling) {
  const usage = { all: createUsage(), others: createUsage(), chains: createChains(done.map((item) => item.path)) };
  for (const item of done) {
    recordUsage(item.route, usage.all);
    if (!sibling(item.edge, edge)) recordUsage(item.route, usage.others);
  }
  return usage;
}

export function createUsage() {
  return { pass: new Map(), segments: new Map(), ports: new Map() };
}

// 辺を指定していないときに、相手の方を向いた辺を優先するための点数。
export function sidePenalty(box, other, side) {
  const dx = (other.a + other.b - box.a - box.b) / 2;
  const dy = (other.c + other.d - box.c - box.d) / 2;
  const [ox, oy] = DIRS[SIDE_DIR[side]];
  const dot = ox * dx + oy * dy;
  if (dot < 0) return COST.sideAway;
  if (dot === 0) return COST.sidePerpendicular;
  const minorAxis = (ox !== 0 && Math.abs(dy) > Math.abs(dx)) || (oy !== 0 && Math.abs(dx) > Math.abs(dy));
  return minorAxis ? COST.axis : 0;
}

// 状態（頂点・進む向き）についてのダイクストラ法。曲がる・交差する・ほかの線と重なる、に重みを付ける。
// usage は routeEdges の { all, others }。
export function findRoute(edge, grid, usage) {
  const fromBox = grid.byId.get(edge.from);
  const toBox = grid.byId.get(edge.to);
  const goals = new Map();
  for (const side of edge.toSide ? [edge.toSide] : SIDES) {
    const penalty = edge.toSide ? 0 : sidePenalty(toBox, fromBox, side);
    for (const [k, l] of ports(toBox, side)) {
      const key = `${k},${l}`;
      if (!goals.has(key)) goals.set(key, []);
      const mixed = portUsedAs(usage.all, edge.to, k, l, 'out', edge.from) ? COST.mixedPort : 0;
      goals.get(key).push({ side, inward: (SIDE_DIR[side] + 2) % 4, penalty: penalty + mixed });
    }
  }

  const ownPorts = new Set(SIDES.flatMap((side) => [...ports(fromBox, side), ...ports(toBox, side)].map(([k, l]) => `${k},${l}`)));
  const heap = new MinHeap();
  for (const side of edge.fromSide ? [edge.fromSide] : SIDES) {
    const penalty = edge.fromSide ? 0 : sidePenalty(fromBox, toBox, side);
    for (const [k, l] of ports(fromBox, side)) {
      const mixed = portUsedAs(usage.all, edge.from, k, l, 'in', edge.to) ? COST.mixedPort : 0;
      // 同じ接続点から部品の縁まで一緒の線とは、縁から共有区間が始まる（そこでは左右が決まらない）。
      const shares = new Map((usage.chains.owners.get(`${edge.from}:${side}:${k},${l}`) ?? []).map((other) => [other, null]));
      heap.push(penalty + mixed, { k, l, dir: SIDE_DIR[side], side, prev: null, shares });
    }
  }

  const done = new Set();
  while (heap.size > 0) {
    const { cost, value: state } = heap.pop();
    if (state.goal) return finishRoute(edge, state);
    const key = `${state.k},${state.l},${state.dir}${[...state.shares].map(([other, left]) => `|${other}${left}`).join('')}`;
    if (done.has(key)) continue;
    done.add(key);

    for (const goal of goals.get(`${state.k},${state.l}`) ?? []) {
      if (state.dir === (goal.inward + 2) % 4) continue;
      let finish = cost + (state.dir === goal.inward ? 0 : COST.bend) + goal.penalty;
      // まっすぐ入るとき、接続点をほかの線が横切っていれば交差する。
      if (state.dir === goal.inward && crossesAt(usage.all, state.k, state.l, state.dir)) finish += COST.cross;
      finish += chainStep(state, goal.inward, `${edge.to}:${goal.side}:${state.k},${state.l}`, usage.chains).cost;
      heap.push(finish, { goal: true, side: goal.side, last: state });
    }
    for (let dir = 0; dir < 4; dir += 1) {
      if (dir === (state.dir + 2) % 4 || !canMove(grid, state.k, state.l, dir)) continue;
      let next = cost + COST.step + COST.share * (usage.others.segments.get(segmentKey(state.k, state.l, dir)) ?? 0);
      const here = usage.others.pass.get(`${state.k},${state.l}`);
      const busy = here && !ownPorts.has(`${state.k},${state.l}`);
      if (dir !== state.dir) {
        next += COST.bend;
        if (busy) next += COST.junction;
      } else if (crossesAt(usage.all, state.k, state.l, dir)) {
        next += COST.cross;
      } else if (busy && here.turn > 0) {
        next += COST.touch;
      }
      const step = chainStep(state, dir, segmentKey(state.k, state.l, dir), usage.chains);
      const [dx, dy] = DIRS[dir];
      heap.push(next + step.cost, { k: state.k + dx, l: state.l + dy, dir, side: state.side, prev: state, shares: step.shares });
    }
  }
  return null;
}

// 決まった経路の区間（部品の縁から接続点までの部分を含む。describePath の keys）の持ち主と、各頂点で使う2つの向き。
// owners：区間の名前 → 経路の番号の一覧。arms："番号@k,l" → [来た方への向き, 出ていく向き]。
export function createChains(paths) {
  const owners = new Map();
  const arms = new Map();
  paths.forEach((path, index) => {
    for (const key of path.keys) {
      if (!owners.has(key)) owners.set(key, []);
      owners.get(key).push(index);
    }
    path.vertices.forEach(([k, l], i) => arms.set(`${index}@${k},${l}`, [reverseOf(path.dirs[i]), path.dirs[i + 1]]));
  });
  return { owners, arms };
}

export const NO_CHAIN = { cost: 0, shares: new Map() };

// 経路を探しながら、決まった経路との共有区間（chainSide と同じもの）の出入りをたどる。
// state.shares は、今いる区間まで一緒に通ってきた経路の番号 → 共有区間に入ったとき、進む向きに対して左にいたか
// （部品の縁から一緒なら null）。頂点 state から向き dir へ区間 key を進むときの、新しい shares と重みを返す。
// 共有区間を抜けるとき、入ったときと左右が入れ替わっていれば、レーンをどう並べても1回は交差するので COST.cross を加える。
export function chainStep(state, dir, key, chains) {
  const owners = chains.owners.get(key);
  // ほかの線と一緒に通っていない区間（多くの区間がそう）は、たどるものがない。
  if (!owners && state.shares.size === 0) return NO_CHAIN;
  const at = `${state.k},${state.l}`;
  const back = reverseOf(state.dir);
  const shares = new Map();
  for (const other of owners ?? []) {
    if (state.shares.has(other)) {
      shares.set(other, state.shares.get(other));
      continue;
    }
    // 共有区間の始まり：来た方を向いて左なら、進む向きに対しては右。
    const theirs = chains.arms.get(`${other}@${at}`)?.find((arm) => arm !== dir) ?? null;
    const left = leftOf(reverseOf(dir), back, theirs);
    shares.set(other, left === null ? null : !left);
  }
  let cost = 0;
  for (const [other, entered] of state.shares) {
    if (shares.has(other) || entered === null) continue;
    const theirs = chains.arms.get(`${other}@${at}`)?.find((arm) => arm !== back) ?? null;
    const left = leftOf(state.dir, dir, theirs);
    if (left !== null && left !== entered) cost += COST.cross;
  }
  return { cost, shares };
}

export function finishRoute(edge, goal) {
  const states = [];
  for (let state = goal.last; state; state = state.prev) states.push(state);
  states.reverse();
  return {
    from: edge.from,
    to: edge.to,
    fromSide: states[0].side,
    toSide: goal.side,
    vertices: states.map((state) => [state.k, state.l]),
  };
}

// 部品 nodeId の接続点 (k, l) を、別の相手（other 以外）とつながる線が role（'in' か 'out'）として使っているか。
export function portUsedAs(usage, nodeId, k, l, role, other) {
  return (usage.ports.get(`${nodeId}:${k},${l}`) ?? []).some((entry) => entry.role === role && entry.other !== other);
}

export function crossesAt(usage, k, l, dir) {
  const pass = usage.pass.get(`${k},${l}`);
  if (!pass) return false;
  return dir % 2 === 0 ? pass.v > 0 : pass.h > 0;
}

// 決まった経路を記録し、後の経路が交差や重なりを避けられるようにする。
export function recordUsage(route, usage) {
  const { vertices } = route;
  const incoming = [SIDE_DIR[route.fromSide]];
  for (let i = 1; i < vertices.length; i += 1) incoming.push(directionBetween(vertices[i - 1], vertices[i]));
  const outgoing = [...incoming.slice(1), (SIDE_DIR[route.toSide] + 2) % 4];
  vertices.forEach(([k, l], i) => {
    const key = `${k},${l}`;
    const pass = usage.pass.get(key) ?? { h: 0, v: 0, turn: 0 };
    if (incoming[i] !== outgoing[i]) pass.turn += 1;
    else if (incoming[i] % 2 === 0) pass.h += 1;
    else pass.v += 1;
    usage.pass.set(key, pass);
  });
  for (let i = 1; i < vertices.length; i += 1) {
    const key = segmentKey(vertices[i - 1][0], vertices[i - 1][1], incoming[i]);
    usage.segments.set(key, (usage.segments.get(key) ?? 0) + 1);
  }
  const notePort = (nodeId, [k, l], role, other) => {
    const key = `${nodeId}:${k},${l}`;
    if (!usage.ports.has(key)) usage.ports.set(key, []);
    usage.ports.get(key).push({ role, other });
  };
  notePort(route.from, vertices[0], 'out', route.to);
  notePort(route.to, vertices.at(-1), 'in', route.from);
}

// 経路を、部品の縁から縁までの点の並びとして表す。点 0 は始点の部品の縁、点 1〜n は格子の頂点、点 n+1 は終点の部品の縁。
// dirs[t] は点 t から t+1 への向き、keys[t] はその部分の名前（部品の縁から接続点までの部分は、部品・辺・接続点で決まる名前）、
// runOf[t] はその部分が入る区間（buildRuns の run）の番号。
export function describePath(route) {
  const { vertices } = route;
  const grid = vertices.slice(1).map((point, t) => directionBetween(vertices[t], point));
  const dirs = [SIDE_DIR[route.fromSide], ...grid, (SIDE_DIR[route.toSide] + 2) % 4];
  const keys = [
    `${route.from}:${route.fromSide}:${vertices[0]}`,
    ...grid.map((dir, t) => segmentKey(vertices[t][0], vertices[t][1], dir)),
    `${route.to}:${route.toSide}:${vertices.at(-1)}`,
  ];
  const runOf = [];
  dirs.forEach((dir, t) => runOf.push(t === 0 ? 0 : runOf[t - 1] + Number(dir !== dirs[t - 1])));
  return {
    vertices,
    dirs,
    keys,
    runOf,
    segments: new Map(keys.map((key, t) => [key, t])),
    // 点 t に入る向きと、点 t から出る向き。部品の縁（両端の点）では null。
    into: (t) => (t === 0 ? null : dirs[t - 1]),
    out: (t) => (t === dirs.length ? null : dirs[t]),
  };
}

export class MinHeap {
  constructor() {
    this.items = [];
    this.sequence = 0;
  }

  get size() {
    return this.items.length;
  }

  push(cost, value) {
    const item = { cost, order: this.sequence, value };
    this.sequence += 1;
    const { items } = this;
    items.push(item);
    let i = items.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (!before(items[i], items[parent])) break;
      [items[i], items[parent]] = [items[parent], items[i]];
      i = parent;
    }
  }

  pop() {
    const { items } = this;
    const top = items[0];
    const last = items.pop();
    if (items.length > 0) {
      items[0] = last;
      let i = 0;
      for (;;) {
        const left = 2 * i + 1;
        const right = left + 1;
        let smallest = i;
        if (left < items.length && before(items[left], items[smallest])) smallest = left;
        if (right < items.length && before(items[right], items[smallest])) smallest = right;
        if (smallest === i) break;
        [items[i], items[smallest]] = [items[smallest], items[i]];
        i = smallest;
      }
    }
    return top;
  }
}

export function before(a, b) {
  return a.cost < b.cost || (a.cost === b.cost && a.order < b.order);
}
