// JSON Schema（draft 2020-12）のうち、latticery のスキーマが使う機能だけを検証する。
// 対応していないキーワードは createValidator の時点で例外にし、条件が黙って無視されないようにする。
// ブラウザでも動かすため、Node.js 専用の機能は使わない。

const SUPPORTED = new Set([
  '$ref', 'type', 'const', 'enum',
  'required', 'properties', 'additionalProperties',
  'items', 'minItems', 'maxItems', 'uniqueItems',
  'minLength', 'maxLength', 'pattern',
  'minimum', 'maximum', 'multipleOf',
]);
const ANNOTATIONS = new Set(['$schema', '$id', '$comment', '$defs', 'title', 'description']);
const TYPES = new Set(['object', 'array', 'string', 'number', 'integer', 'boolean', 'null']);

/**
 * スキーマから検証関数を作る。
 * 検証関数は { valid, errors } を返す。errors の各要素は { path, keyword, params }。
 * path は JSON Pointer（例："/nodes/0/kind"。最上位は ""）。
 */
export function createValidator(schema) {
  const patterns = new Map();
  prepare(schema, schema, '#', patterns);
  return function validate(value) {
    const errors = [];
    check(schema, value, '', { root: schema, patterns, errors });
    return { valid: errors.length === 0, errors };
  };
}

function prepare(node, root, where, patterns) {
  if (!isPlainObject(node)) throw new Error(`スキーマ ${where} はオブジェクトでなければならない`);
  for (const key of Object.keys(node)) {
    if (!SUPPORTED.has(key) && !ANNOTATIONS.has(key)) {
      throw new Error(`スキーマ ${where} のキーワード "${key}" には対応していない`);
    }
  }
  if (node.$ref !== undefined) resolveRef(root, node.$ref);
  if (node.type !== undefined && !TYPES.has(node.type)) {
    throw new Error(`スキーマ ${where} の type "${node.type}" には対応していない`);
  }
  if (node.additionalProperties !== undefined
    && typeof node.additionalProperties !== 'boolean' && !isPlainObject(node.additionalProperties)) {
    throw new Error(`スキーマ ${where} の additionalProperties は真偽値かスキーマでなければならない`);
  }
  if (node.pattern !== undefined && !patterns.has(node.pattern)) {
    patterns.set(node.pattern, new RegExp(node.pattern, 'u'));
  }
  for (const [name, sub] of Object.entries(node.properties ?? {})) {
    prepare(sub, root, `${where}/properties/${name}`, patterns);
  }
  if (isPlainObject(node.additionalProperties)) {
    prepare(node.additionalProperties, root, `${where}/additionalProperties`, patterns);
  }
  if (node.items !== undefined) prepare(node.items, root, `${where}/items`, patterns);
  for (const [name, sub] of Object.entries(node.$defs ?? {})) {
    prepare(sub, root, `${where}/$defs/${name}`, patterns);
  }
}

// 同じスキーマの中を指す "#/..." だけに対応する。
function resolveRef(root, ref) {
  if (typeof ref !== 'string' || !ref.startsWith('#/')) {
    throw new Error(`$ref "${ref}" には対応していない（"#/..." の形だけ使える）`);
  }
  let target = root;
  for (const raw of ref.slice(2).split('/')) {
    const key = raw.replace(/~1/g, '/').replace(/~0/g, '~');
    if (!isPlainObject(target) || !Object.hasOwn(target, key)) {
      throw new Error(`$ref "${ref}" の参照先が見つからない`);
    }
    target = target[key];
  }
  return target;
}

function check(schema, value, path, ctx) {
  if (schema.$ref !== undefined) check(resolveRef(ctx.root, schema.$ref), value, path, ctx);

  // 型が違えば、ほかの条件を調べても意味のないエラーが増えるだけなので、ここで止める。
  if (schema.type !== undefined && !hasType(value, schema.type)) {
    report(ctx, path, 'type', { expected: schema.type, actual: typeName(value) });
    return;
  }
  if (Object.hasOwn(schema, 'const') && !deepEqual(value, schema.const)) {
    report(ctx, path, 'const', { expected: schema.const });
  }
  if (schema.enum !== undefined && !schema.enum.some((candidate) => deepEqual(value, candidate))) {
    report(ctx, path, 'enum', { allowed: schema.enum });
  }

  if (typeof value === 'string') checkString(schema, value, path, ctx);
  else if (typeof value === 'number') checkNumber(schema, value, path, ctx);
  else if (Array.isArray(value)) checkArray(schema, value, path, ctx);
  else if (isPlainObject(value)) checkObject(schema, value, path, ctx);
}

function checkString(schema, value, path, ctx) {
  // 文字数はコードポイントで数える（絵文字なども1文字）。
  const length = [...value].length;
  if (schema.minLength !== undefined && length < schema.minLength) {
    report(ctx, path, 'minLength', { limit: schema.minLength, actual: length });
  }
  if (schema.maxLength !== undefined && length > schema.maxLength) {
    report(ctx, path, 'maxLength', { limit: schema.maxLength, actual: length });
  }
  if (schema.pattern !== undefined && !ctx.patterns.get(schema.pattern).test(value)) {
    report(ctx, path, 'pattern', { pattern: schema.pattern });
  }
}

function checkNumber(schema, value, path, ctx) {
  if (schema.minimum !== undefined && value < schema.minimum) {
    report(ctx, path, 'minimum', { limit: schema.minimum, actual: value });
  }
  if (schema.maximum !== undefined && value > schema.maximum) {
    report(ctx, path, 'maximum', { limit: schema.maximum, actual: value });
  }
  if (schema.multipleOf !== undefined) {
    const quotient = value / schema.multipleOf;
    if (Math.abs(quotient - Math.round(quotient)) > 1e-9) {
      report(ctx, path, 'multipleOf', { step: schema.multipleOf, actual: value });
    }
  }
}

function checkArray(schema, value, path, ctx) {
  if (schema.minItems !== undefined && value.length < schema.minItems) {
    report(ctx, path, 'minItems', { limit: schema.minItems, actual: value.length });
  }
  if (schema.maxItems !== undefined && value.length > schema.maxItems) {
    report(ctx, path, 'maxItems', { limit: schema.maxItems, actual: value.length });
  }
  if (schema.uniqueItems === true) {
    value.forEach((item, index) => {
      const first = value.findIndex((other) => deepEqual(other, item));
      if (first < index) report(ctx, `${path}/${index}`, 'uniqueItems', { duplicateOf: first });
    });
  }
  if (schema.items !== undefined) {
    value.forEach((item, index) => check(schema.items, item, `${path}/${index}`, ctx));
  }
}

function checkObject(schema, value, path, ctx) {
  for (const name of schema.required ?? []) {
    if (!Object.hasOwn(value, name)) report(ctx, path, 'required', { property: name });
  }
  const properties = schema.properties ?? {};
  for (const [name, item] of Object.entries(value)) {
    const childPath = `${path}/${escapePointer(name)}`;
    if (Object.hasOwn(properties, name)) {
      check(properties[name], item, childPath, ctx);
    } else if (schema.additionalProperties === false) {
      report(ctx, childPath, 'additionalProperties', { property: name, allowed: Object.keys(properties) });
    } else if (isPlainObject(schema.additionalProperties)) {
      check(schema.additionalProperties, item, childPath, ctx);
    }
  }
}

function report(ctx, path, keyword, params) {
  ctx.errors.push({ path, keyword, params });
}

function hasType(value, type) {
  switch (type) {
    case 'object': return isPlainObject(value);
    case 'array': return Array.isArray(value);
    case 'string': return typeof value === 'string';
    case 'number': return typeof value === 'number' && Number.isFinite(value);
    case 'integer': return Number.isInteger(value);
    case 'boolean': return typeof value === 'boolean';
    case 'null': return value === null;
    default: return false;
  }
}

function typeName(value) {
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'array';
  if (Number.isInteger(value)) return 'integer';
  return typeof value;
}

function isPlainObject(value) {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function deepEqual(a, b) {
  if (a === b) return true;
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  return keysA.length === keysB.length && keysA.every((key) => Object.hasOwn(b, key) && deepEqual(a[key], b[key]));
}

function escapePointer(name) {
  return name.replace(/~/g, '~0').replace(/\//g, '~1');
}
