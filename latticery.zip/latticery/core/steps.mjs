// 手順の種類（workflow と、後で足す flowchart で共通）：8種類の一覧・色・記号・形・名前。
// 仕様：docs/latticery/types/workflow.md の「kind（手順の種類）」
//
// 色は、部品の種類（core/kinds.mjs）と同じ作り方・同じ組み合わせを使い、手順の意味に合わせて割り当てる
// （始まり＝緑、終わり＝紫、人の作業＝桃、システム＝青、判断＝橙、待ち＝赤、書類＝青緑、外部＝灰。決定記録 No.87）。

import { el, formatNumber as n } from './svg.mjs';

// 記号の大きさ（px）と線の太さ（16×16 の座標での値）。部品の種類と同じ。
export const STEP_ICON = { size: 14, stroke: 1.6 };

// 手順の種類ごとの色：[塗り, 枠線, 記号の色]。
export const STEP_COLORS = {
  start: { light: ['#ebfaed', '#5aa26b', '#1d7d3e'], dark: ['#1b2d1e', '#519160', '#89d298'] },
  end: { light: ['#f5f4fe', '#8e83ce', '#6959ae'], dark: ['#272538', '#7f75b8', '#bcb2ff'] },
  task: { light: ['#fef0fc', '#b576af', '#914a8c'], dark: ['#322130', '#a26a9d', '#e6a4e0'] },
  system: { light: ['#eef6fe', '#5894d0', '#1f6cb0'], dark: ['#1a2938', '#4f84ba', '#89c3fe'] },
  decision: { light: ['#fef3e7', '#ba823c', '#915b02'], dark: ['#332514', '#a67537', '#ebb16c'] },
  wait: { light: ['#fff2f0', '#ca736d', '#a74541'], dark: ['#37211f', '#b46762', '#fda19a'] },
  document: { light: ['#e5fafb', '#04a3aa', '#02787d'], dark: ['#0f2d2e', '#0d9298', '#56d3da'] },
  external: { light: ['#f3f5f8', '#8b9095', '#646970'], dark: ['#26282a', '#7c8186', '#b9bec6'] },
};

// 歯が8つの歯車の外形（システム処理の記号。部品の種類の service と同じ形）。
function gearPath() {
  const teeth = 8;
  const points = [];
  for (let i = 0; i < teeth; i += 1) {
    for (const [t, r] of [[0.08, 4.9], [0.22, 6.6], [0.5, 6.6], [0.64, 4.9]]) {
      const a = ((i + t) / teeth) * Math.PI * 2;
      points.push(`${n(8 + r * Math.cos(a))} ${n(8 + r * Math.sin(a))}`);
    }
  }
  return `M${points.join('L')}Z`;
}

// 手順の種類ごとの記号。16×16 の座標に、塗りのない線で描く。判断（decision）はひし形が種類を表すので、記号を付けない。
const ICONS = {
  start: [
    ['circle', { cx: 8, cy: 8, r: 6.5 }],
    ['path', { d: 'M6.5 4.8l4.7 3.2-4.7 3.2z' }],
  ],
  end: [
    ['circle', { cx: 8, cy: 8, r: 6.5 }],
    ['path', { d: 'M5 8.2l2.2 2.3 4-4.8' }],
  ],
  task: [
    ['path', { d: 'M2.5 13.5l1-3.2 7.2-7.2 2.2 2.2-7.2 7.2z' }],
    ['path', { d: 'M9.8 3.9l2.2 2.2' }],
  ],
  system: [
    ['path', { d: gearPath() }],
    ['circle', { cx: 8, cy: 8, r: 2 }],
  ],
  decision: [],
  wait: [
    ['circle', { cx: 8, cy: 8, r: 6.3 }],
    ['path', { d: 'M8 4.2V8l2.6 1.8' }],
  ],
  document: [
    ['path', { d: 'M3.5 1.7h5.5l3.5 3.5v9.1h-9z' }],
    ['path', { d: 'M9 1.7v3.5h3.5' }],
    ['path', { d: 'M5.6 8.4h4.8M5.6 11h4.8' }],
  ],
  external: [
    ['path', { d: 'M9.5 1.5h5v5M14.5 1.5L7.5 8.5' }],
    ['path', { d: 'M12.5 9.5v4a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h4' }],
  ],
};

export const STEP_KINDS = Object.keys(ICONS);

// 記号の形（[タグ, 属性] の一覧）。lifecycle の状態の種類で、意味が同じ記号（始まり・待ち・完了）を使うため。
export const STEP_ICON_SHAPES = ICONS;

// 種類ごとの形。box：四角、capsule：角丸のカプセル、diamond：ひし形。
export const STEP_SHAPES = {
  start: 'capsule', end: 'capsule', task: 'box', system: 'box',
  decision: 'diamond', wait: 'box', document: 'box', external: 'box',
};

/** 手順の種類の記号。左上を (x, y) にして、size の大きさで描く。記号のない種類（判断）は null。 */
export function stepIcon(kind, { x = 0, y = 0, size = STEP_ICON.size } = {}) {
  if (ICONS[kind].length === 0) return null;
  return el('g', {
    class: 'lt-icon',
    transform: `translate(${n(x)} ${n(y)}) scale(${n(size / 16)})`,
    fill: 'none',
    stroke: STEP_COLORS[kind].light[2],
    'stroke-width': STEP_ICON.stroke,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  }, ICONS[kind].map(([tag, attrs]) => el(tag, attrs)));
}

// 凡例と説明カードに出す、手順の種類の名前。
export const stepNames = {
  ja: {
    start: '始まり', end: '終わり', task: '作業', system: 'システム処理',
    decision: '判断', wait: '待ち', document: '書類・データ', external: '外部',
  },
  en: {
    start: 'Start', end: 'End', task: 'Manual task', system: 'System step',
    decision: 'Decision', wait: 'Wait', document: 'Document', external: 'External',
  },
};

// 箱の描き方（core/node.mjs に渡すもの）。色・クラス・記号・形を、手順の種類のものにする。
export const STEP_STYLE = {
  colors: STEP_COLORS,
  className: (kind) => `lt-step-${kind}`,
  icon: stepIcon,
  hasIcon: (kind) => ICONS[kind].length > 0,
  shape: (kind) => STEP_SHAPES[kind],
};

/**
 * 手順の種類の色を決める CSS。core/draw.mjs の diagramStyles() と同じ作りで、.lt-step-<種類> に変数を入れる。
 * 変数の名前は部品の種類と同じなので、箱・記号・文字の CSS はそのまま使える。
 */
export function stepStyles({ dark = '[data-theme="dark"]' } = {}) {
  const vars = ([fill, border, accent]) => `--lt-fill:${fill};--lt-border:${border};--lt-accent:${accent}`;
  return [
    ...STEP_KINDS.map((kind) => `.lt-step-${kind}{${vars(STEP_COLORS[kind].light)}}`),
    ...STEP_KINDS.map((kind) => `${dark} .lt-step-${kind}{${vars(STEP_COLORS[kind].dark)}}`),
  ].join('\n');
}

// 使えない値から、意味の近い種類への対応（schema/invalid の直し方の候補に使う）。
export const STEP_SYNONYMS = {
  start: ['begin', 'trigger', 'entry', 'request', 'init'],
  end: ['finish', 'done', 'complete', 'completed', 'terminal', 'exit', 'result'],
  task: ['manual', 'work', 'action', 'human', 'person', 'activity', 'step', 'operation'],
  system: ['auto', 'automatic', 'service', 'api', 'batch', 'job', 'backend', 'process', 'server'],
  decision: ['branch', 'condition', 'if', 'choice', 'gateway', 'check', 'judge', 'approval'],
  wait: ['pending', 'hold', 'delay', 'queue', 'timer', 'sleep', 'waiting'],
  document: ['doc', 'file', 'form', 'record', 'data', 'report', 'datastore', 'database'],
  external: ['partner', 'vendor', 'thirdparty', 'customer', 'outside', 'saas'],
};
