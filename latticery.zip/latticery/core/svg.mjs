// 描画の要素の木と、SVG の文字列・DOM への変換。
//
// 要素は { tag, attrs, children }。children の文字列は必ず文字として扱い、HTML や SVG として解釈させない
// （文字列にするときはエスケープし、DOM にするときは文字のノードにする）。
// 要素名と属性名はプログラムの中で決めたものだけを使う。利用者の入力は、属性の値と文字にだけ入れる。

export const SVG_NS = 'http://www.w3.org/2000/svg';

/**
 * 要素を作る。属性の値が null・undefined・false なら、その属性は付けない。
 * children の null・undefined・false は無視する（条件によって要素を省くときに使う）。
 */
export function el(tag, attrs = {}, children = []) {
  const list = (Array.isArray(children) ? children : [children]).flat(Infinity);
  return { tag, attrs, children: list.filter((child) => child !== null && child !== undefined && child !== false) };
}

// 数値は小数第2位までにする（出力を短くし、実行環境による細かな誤差を出さないため）。
export function formatNumber(value) {
  const rounded = Math.round(value * 100) / 100;
  return Object.is(rounded, -0) ? '0' : String(rounded);
}

const formatValue = (value) => (typeof value === 'number' ? formatNumber(value) : String(value));
const hasValue = (value) => value !== null && value !== undefined && value !== false;

const escapeText = (text) => text.replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[c]);
const escapeAttr = (text) => text.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);

/** 要素の木を SVG の文字列にする。いちばん外の svg 要素には xmlns を付ける。 */
export function toSvgString(node, { root = true } = {}) {
  if (typeof node === 'string') return escapeText(node);
  const attrs = { ...(root && node.tag === 'svg' ? { xmlns: SVG_NS } : {}), ...node.attrs };
  const text = Object.entries(attrs)
    .filter(([, value]) => hasValue(value))
    .map(([name, value]) => ` ${name}="${escapeAttr(formatValue(value))}"`)
    .join('');
  if (node.children.length === 0) return `<${node.tag}${text}/>`;
  const inner = node.children.map((child) => toSvgString(child, { root: false })).join('');
  return `<${node.tag}${text}>${inner}</${node.tag}>`;
}

/** 要素の木を DOM の要素にする（ブラウザ用）。document はブラウザの document。 */
export function toDom(node, document) {
  if (typeof node === 'string') return document.createTextNode(node);
  const element = document.createElementNS(SVG_NS, node.tag);
  for (const [name, value] of Object.entries(node.attrs)) {
    if (hasValue(value)) element.setAttribute(name, formatValue(value));
  }
  for (const child of node.children) element.appendChild(toDom(child, document));
  return element;
}

/**
 * ブラウザで実際の文字の幅を測り、見積もり（data-width）を超えた文字だけを見積もりの幅に詰める（ブラウザ用）。
 * 配置は見積もりのまま変えない（共通仕様「10. 見た目」）。
 */
export function fitText(svg) {
  for (const text of svg.querySelectorAll('text[data-width]')) {
    const estimate = Number(text.getAttribute('data-width'));
    if (text.getComputedTextLength() > estimate) {
      text.setAttribute('textLength', estimate);
      text.setAttribute('lengthAdjust', 'spacingAndGlyphs');
    }
  }
}
