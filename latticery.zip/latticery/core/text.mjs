// 文字の表示幅を「半角1・全角2」の単位で数える。
// Unicode の East Asian Width が W（全角）・F（全角英数など）の文字を2とし、結合文字などは0とする。

const ZERO_WIDTH = [
  [0x0300, 0x036f], // 結合用の記号
  [0x200b, 0x200f], // ゼロ幅スペース・ゼロ幅接合子など
  [0x20d0, 0x20ff], // 記号用の結合文字
  [0xfe00, 0xfe0f], // 異体字セレクタ
  [0xe0100, 0xe01ef], // 異体字セレクタ（補助）
];

const WIDE = [
  [0x1100, 0x115f], // ハングル字母
  [0x2e80, 0x303e], // CJK 部首・記号・句読点（「」、。など）
  [0x3041, 0x33ff], // ひらがな・カタカナ・CJK 互換文字など
  [0x3400, 0x4dbf], // CJK 統合漢字拡張 A
  [0x4e00, 0x9fff], // CJK 統合漢字
  [0xa000, 0xa4cf], // イ文字
  [0xac00, 0xd7a3], // ハングル音節
  [0xf900, 0xfaff], // CJK 互換漢字
  [0xfe10, 0xfe19], // 縦書き用の記号
  [0xfe30, 0xfe6f], // CJK 互換形・小字形
  [0xff00, 0xff60], // 全角英数・記号
  [0xffe0, 0xffe6], // 全角の通貨記号など
  [0x1f300, 0x1f64f], // 絵文字
  [0x1f900, 0x1f9ff], // 絵文字（補助）
  [0x20000, 0x3fffd], // CJK 統合漢字拡張 B 以降
];

function inRanges(codePoint, ranges) {
  return ranges.some(([start, end]) => codePoint >= start && codePoint <= end);
}

export function charUnits(codePoint) {
  if (inRanges(codePoint, ZERO_WIDTH)) return 0;
  if (inRanges(codePoint, WIDE)) return 2;
  return 1;
}

export function textUnits(text) {
  let units = 0;
  for (const char of text) units += charUnits(char.codePointAt(0));
  return units;
}

// 図の文字に使うフォント。埋め込まず、OS 標準のゴシック体を使う（macOS・Windows・Linux の順）。
// 下の見積もりは、これらのフォントを想定している。
export const FONT_FAMILY = "'Hiragino Sans', 'Hiragino Kaku Gothic ProN', 'Yu Gothic UI', 'Yu Gothic', Meiryo, 'Noto Sans JP', 'Noto Sans CJK JP', system-ui, sans-serif";

// 文字列の描画幅（px）の見積もり。フォントは埋め込まないので、OS 標準のゴシック体を想定して少し広めに見積もる。
// ブラウザでもコマンドでも同じ値になるよう、実際のフォントでは測らない。
const EM_NARROW = new Set([...'ijl|!.,:;\'`']);
const EM_SEMI_NARROW = new Set([...'frtI()[]{}/\\-" ']);
const EM_WIDE = new Set([...'MWmw@%&']);
const SAFETY = 1.05;
const BOLD = 1.06;

function charEm(char) {
  const codePoint = char.codePointAt(0);
  const units = charUnits(codePoint);
  if (units === 0) return 0;
  if (units === 2) return 1;
  if (codePoint > 0x7e) return 0.65;
  if (EM_NARROW.has(char)) return 0.3;
  if (EM_SEMI_NARROW.has(char)) return 0.4;
  if (EM_WIDE.has(char)) return 0.9;
  if (char >= 'A' && char <= 'Z') return 0.72;
  return 0.6;
}

export function estimateWidth(text, fontSize, { bold = false } = {}) {
  let em = 0;
  for (const char of text) em += charEm(char);
  return Math.ceil(em * fontSize * SAFETY * (bold ? BOLD : 1));
}
