// architecture のチェック。仕様：docs/latticery/types/architecture.md の「4. チェック」
// checkArchitecture：構造のチェック。スキーマ検証を通った図に対して、配置を計算しなくても分かる問題を調べる。
// inspectArchitecture：見た目のチェック。配置の計算の結果（layout.mjs の layoutArchitecture が返す layout）を使う。

import { duplicateIds, longTexts, oversize } from '../../core/checks.mjs';
import { findCrossings, labelOverlaps, segmentsOf } from '../../core/inspect.mjs';
import { closest, error, synonymIndex, warning } from '../../core/diagnostics.mjs';
import { KIND_SYNONYMS } from '../../core/kinds.mjs';
import { edgeTarget } from '../../core/route.mjs';
import { isSibling, isSubset, layoutArchitecture, nestGroups } from './layout.mjs';

export const GRID_SIZE = 10;
export const MAX_GROUP_DEPTH = 3;
export const NODE_COUNT_GUIDELINE = 20;

// 使えない値から、意味の近い使える値への対応（schema/invalid の直し方の候補に使う）。
// 部品の種類（kind）は core/kinds.mjs の語を使い、枠の線（style）の語だけをここで決める。
// 語は小文字にして、英数字以外を除いた形で書く。同じ語が、部品の種類と枠の線の両方に当たることがある。
export const VALUE_SYNONYMS = synonymIndex({
  ...KIND_SYNONYMS,
  boundary: ['solid', 'region', 'vpc', 'network'],
  zone: ['dashed', 'dotted', 'subnet', 'securitygroup', 'trust'],
});

// 表示幅の目安（半角1・全角2で数える）。
const TEXT_GUIDELINES = [
  { collection: 'nodes', field: 'label', limit: 24 },
  { collection: 'nodes', field: 'sublabel', limit: 32 },
  { collection: 'nodes', field: 'tag', limit: 16 },
  { collection: 'groups', field: 'label', limit: 32 },
  { collection: 'edges', field: 'label', limit: 16 },
];

export function checkArchitecture(doc) {
  const parts = { nodes: doc.nodes, groups: doc.groups ?? [], edges: doc.edges ?? [] };
  return [
    ...checkIds(parts),
    ...checkReferences(parts),
    ...checkPlacement(parts.nodes),
    ...checkEdges(parts),
    ...checkGroups(parts.groups),
    ...checkTextLength(parts),
    ...checkNodeCount(parts.nodes),
  ];
}

function checkIds({ nodes, groups, edges }) {
  return duplicateIds([
    ...nodes.map((node, i) => ({ id: node.id, path: `/nodes/${i}/id` })),
    ...groups.map((group, i) => ({ id: group.id, path: `/groups/${i}/id` })),
    ...edges.map((edge, i) => ({ id: edge.id, path: `/edges/${i}/id` })),
  ]);
}

function checkReferences({ nodes, groups, edges }) {
  const nodeIds = nodes.map((node) => node.id);
  const nodeSet = new Set(nodeIds);
  const groupById = new Map(groups.map((group) => [group.id, group]));
  const problems = [];
  const verify = (value, path, target) => {
    if (nodeSet.has(value)) return;
    const detail = { path, value };
    if (groupById.has(value)) {
      // 枠の中の部品（枠の ID を書いた contains の中身のうち、部品の ID であるもの）を、書き直す候補にする。
      detail.isGroup = true;
      detail.members = groupById.get(value).contains.filter((id) => nodeSet.has(id));
    } else {
      const suggestion = closest(value, nodeIds);
      if (suggestion) detail.suggestion = suggestion;
    }
    problems.push(error('ref/unknown', { target, detail }));
  };
  edges.forEach((edge, i) => {
    verify(edge.from, `/edges/${i}/from`, edgeTarget(edge));
    verify(edge.to, `/edges/${i}/to`, edgeTarget(edge));
  });
  groups.forEach((group, i) => {
    group.contains.forEach((id, j) => verify(id, `/groups/${i}/contains/${j}`, [group.id]));
  });
  return problems;
}

// col・row は 0.5 の倍数、span は整数なので、そのまま比べても誤差は出ない。
function checkPlacement(nodes) {
  const boxes = nodes.map((node) => ({
    node,
    left: node.col,
    top: node.row,
    right: node.col + (node.colSpan ?? 1),
    bottom: node.row + (node.rowSpan ?? 1),
  }));
  const problems = [];
  for (const box of boxes) {
    if (box.right > GRID_SIZE || box.bottom > GRID_SIZE) {
      problems.push(error('layout/out-of-range', {
        target: [box.node.id],
        detail: { id: box.node.id, col: box.left, row: box.top, right: box.right, bottom: box.bottom, limit: GRID_SIZE },
      }));
    }
  }
  for (let i = 0; i < boxes.length; i += 1) {
    for (let j = i + 1; j < boxes.length; j += 1) {
      const a = boxes[i];
      const b = boxes[j];
      if (a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom) {
        const detail = { first: a.node.id, second: b.node.id, col: Math.max(a.left, b.left), row: Math.max(a.top, b.top) };
        // 後に書いた部品の移し先の候補。
        const place = freePlace(b.node, nodes.filter((node) => node !== b.node).map(extentOf));
        if (place) detail.suggestion = place;
        problems.push(error('layout/overlap', { target: [a.node.id, b.node.id], detail }));
      }
    }
  }
  return problems;
}

function checkEdges({ nodes, edges }) {
  const problems = [];
  const routes = new Map();
  edges.forEach((edge, i) => {
    if (edge.from === edge.to) {
      problems.push(error('edge/self-loop', { target: edgeTarget(edge), detail: { path: `/edges/${i}`, id: edge.from } }));
    }
    // 双方向の線は向きを問わず、片方向の線は向きも含めて同じなら重複とみなす。
    const key = edge.both ? `both ${[edge.from, edge.to].sort().join(' ')}` : `${edge.from} ${edge.to}`;
    if (!routes.has(key)) routes.set(key, { edge, paths: [] });
    routes.get(key).paths.push(`/edges/${i}`);
  });
  for (const { edge, paths } of routes.values()) {
    if (paths.length > 1) {
      problems.push(warning('edge/duplicate', {
        target: [edge.from, edge.to],
        detail: { from: edge.from, to: edge.to, both: Boolean(edge.both), paths },
      }));
    }
  }
  // 部品が1つだけの図では、線がないのは当然なので警告しない。
  if (nodes.length > 1) {
    const linked = new Set(edges.flatMap((edge) => [edge.from, edge.to]));
    for (const node of nodes) {
      if (!linked.has(node.id)) problems.push(warning('node/isolated', { target: [node.id], detail: { id: node.id } }));
    }
  }
  return problems;
}

function checkGroups(groups) {
  const problems = [];
  const sets = groups.map((group) => new Set(group.contains));
  for (let i = 0; i < groups.length; i += 1) {
    for (let j = i + 1; j < groups.length; j += 1) {
      const shared = [...sets[i]].filter((id) => sets[j].has(id));
      if (shared.length > 0 && !isSubset(sets[i], sets[j]) && !isSubset(sets[j], sets[i])) {
        problems.push(error('group/partial-membership', {
          target: [groups[i].id, groups[j].id],
          detail: {
            first: groups[i].id,
            second: groups[j].id,
            shared,
            onlyInFirst: [...sets[i]].filter((id) => !sets[j].has(id)),
            onlyInSecond: [...sets[j]].filter((id) => !sets[i].has(id)),
          },
        }));
      }
    }
  }
  // 上限を超えた最初の段だけを報告する（さらに深い段まで報告すると、同じ問題が重なって見えるため）。
  for (const entry of nestGroups(groups)) {
    if (entry.depth === MAX_GROUP_DEPTH + 1) {
      problems.push(error('group/too-deep', { target: [entry.id], detail: { chain: entry.chain, limit: MAX_GROUP_DEPTH } }));
    }
  }
  return problems;
}

function checkTextLength(parts) {
  return longTexts(TEXT_GUIDELINES.flatMap(({ collection, field, limit }) => parts[collection].map((item, i) => ({
    text: item[field],
    path: `/${collection}/${i}/${field}`,
    limit,
    target: collection === 'edges' ? edgeTarget(item) : [item.id],
  }))));
}

function checkNodeCount(nodes) {
  if (nodes.length <= NODE_COUNT_GUIDELINE) return [];
  return [warning('size/too-many-nodes', { detail: { count: nodes.length, limit: NODE_COUNT_GUIDELINE } })];
}

// ---- 見た目のチェック -----------------------------------------------------------

// 線のラベルの重なり。architecture では、枠の名前とも重なってはいけない。
function architectureLabelOverlaps(doc, layout) {
  return labelOverlaps(doc.edges ?? [], layout, {
    sibling: isSibling,
    boxes: layout.groups.map((group) => ({ kind: 'group', id: group.id, box: group.labelBox })),
  });
}

// limits は、利用者が図の大きさを指定したときの上限（{ maxWidth, maxHeight }。px）。指定がなければ、大きさは判定しない。
export function inspectArchitecture(doc, layout, limits = {}) {
  const groups = doc.groups ?? [];
  const edges = doc.edges ?? [];
  return [
    ...checkGroupFrames(doc.nodes, groups),
    ...architectureLabelOverlaps(doc, layout),
    ...checkCrossings(doc, layout),
    ...checkSize(doc.nodes, layout, limits),
  ];
}

// 部品の範囲（列・行の座標）。right・bottom は範囲の右端・下端。
const extentOf = (node) => ({ col: node.col, row: node.row, right: node.col + (node.colSpan ?? 1), bottom: node.row + (node.rowSpan ?? 1) });
const intersects = (p, q) => p.col < q.right && q.col < p.right && p.row < q.bottom && q.row < p.bottom;
const includes = (outer, inner) => outer.col <= inner.col && inner.right <= outer.right && outer.row <= inner.row && inner.bottom <= outer.bottom;

// 枠の範囲は、中の部品を囲む最小の長方形（列・行の座標）。枠の余白は通路に入るので、部品との重なりはこの範囲で決まる。
function frameOf(group, extents) {
  const members = group.contains.map((id) => extents.get(id));
  return {
    col: Math.min(...members.map((m) => m.col)),
    row: Math.min(...members.map((m) => m.row)),
    right: Math.max(...members.map((m) => m.right)),
    bottom: Math.max(...members.map((m) => m.bottom)),
  };
}

function checkGroupFrames(nodes, groups) {
  const extents = new Map(nodes.map((node) => [node.id, extentOf(node)]));
  const frames = groups.map((group) => frameOf(group, extents));
  const problems = [];
  groups.forEach((group, i) => {
    const members = new Set(group.contains);
    for (const node of nodes) {
      if (members.has(node.id) || !intersects(frames[i], extents.get(node.id))) continue;
      // 入り込んだ部品が入っている枠（入れ子にし忘れた内側の枠の候補）。
      const others = groups.filter((other) => other !== group && other.contains.includes(node.id)).map((other) => other.id);
      const detail = { group: group.id, node: node.id, frame: frames[i], groups: others };
      const blockers = [
        ...nodes.filter((other) => other !== node).map((other) => extents.get(other.id)),
        ...groups.flatMap((other, j) => (other.contains.includes(node.id) ? [] : [frames[j]])),
      ];
      const place = freePlace(node, blockers);
      if (place) detail.suggestion = place;
      problems.push(error('group/encloses-outsider', { target: [group.id, node.id], detail }));
    }
  });
  const sets = groups.map((group) => new Set(group.contains));
  for (let i = 0; i < groups.length; i += 1) {
    for (let j = i + 1; j < groups.length; j += 1) {
      // 中身が入れ子の枠は、長方形も必ず入れ子になる。中身が別々の枠だけを調べる。
      if (isSubset(sets[i], sets[j]) || isSubset(sets[j], sets[i])) continue;
      const [p, q] = [frames[i], frames[j]];
      if (!intersects(p, q) || includes(p, q) || includes(q, p)) continue;
      problems.push(error('group/partial-overlap', {
        target: [groups[i].id, groups[j].id],
        detail: { first: groups[i].id, second: groups[j].id, firstFrame: p, secondFrame: q },
      }));
    }
  }
  return problems;
}

// 部品の移し先の候補。blockers（部品や枠の範囲）のどれにもかからない整数の位置のうち、今の位置にいちばん近いもの
// （同じ近さなら、上の行・左の列を優先する）。見つからなければ null。
function freePlace(node, blockers) {
  const colSpan = node.colSpan ?? 1;
  const rowSpan = node.rowSpan ?? 1;
  let best = null;
  let bestDistance = Infinity;
  for (let row = 0; row + rowSpan <= GRID_SIZE; row += 1) {
    for (let col = 0; col + colSpan <= GRID_SIZE; col += 1) {
      const place = { col, row, right: col + colSpan, bottom: row + rowSpan };
      if (blockers.some((blocker) => intersects(place, blocker))) continue;
      const distance = Math.abs(col - node.col) + Math.abs(row - node.row);
      if (distance < bestDistance) {
        best = { col, row };
        bestDistance = distance;
      }
    }
  }
  return best;
}

// 交差の移し先を探す組の数と、そのために配置を計算し直す回数の上限（1回のチェックで）。
// ブラウザでも図を開くたびに行うので、図が大きくても時間がかかりすぎないようにする。
const CROSSING_SUGGESTIONS = 3;
const RELAYOUT_BUDGET = 150;

// 線同士の交差。線の組ごとに1つの警告にする。
// 初めのいくつかの組には、移し先の候補（detail.suggestion）を付ける（suggestUncrossing を参照）。
function checkCrossings(doc, layout) {
  const edges = doc.edges ?? [];
  const found = findCrossings(layout.edges);
  const total = found.reduce((sum, item) => sum + item.count, 0);
  const budget = { left: RELAYOUT_BUDGET };
  const describe = (j) => ({ path: `/edges/${j}`, from: edges[j].from, to: edges[j].to });
  return found.map(({ i, j, count }, index) => {
    const detail = { first: describe(i), second: describe(j), count };
    const suggestion = index < CROSSING_SUGGESTIONS ? suggestUncrossing(doc, i, j, total, budget) : null;
    if (suggestion) detail.suggestion = suggestion;
    return warning('edge/crossing', { target: [...new Set([...edgeTarget(edges[i]), ...edgeTarget(edges[j])])], detail });
  });
}

// 線 i と j の交差をなくす直し方の候補。2本の線の端の部品について、次の2通りを試して配置を計算し直す。
// - 1つの部品を、近く（2マス以内）の空いている整数の位置に動かす（{ node, col, row }）
// - 2つの部品の位置を入れ替える（大きさが同じものだけ。{ swap: [a, b] }）
// この組の交差がなくなり、図全体の交差も減るもののうち、図全体の交差 → 主な経路（primary）の線の曲がる回数 → 線の長さの合計
// の順に少ないものを返す（主な経路をまっすぐに保ち、遠回りの少ない直し方を選ぶため）。
// 動かすと別のエラー（枠の範囲・ラベルの重なりなど）が出るものは使わない。見つからなければ null。
function suggestUncrossing(doc, i, j, total, budget) {
  const edges = doc.edges;
  const groups = doc.groups ?? [];
  const ids = [...new Set([edges[i].from, edges[i].to, edges[j].from, edges[j].to])];
  const byId = new Map(doc.nodes.map((node) => [node.id, node]));
  const candidates = [];
  for (const [index, a] of ids.entries()) {
    for (const b of ids.slice(index + 1)) {
      const p = byId.get(a);
      const q = byId.get(b);
      if ((p.colSpan ?? 1) === (q.colSpan ?? 1) && (p.rowSpan ?? 1) === (q.rowSpan ?? 1)) {
        candidates.push({ suggestion: { swap: [a, b] }, moves: { [a]: q, [b]: p } });
      }
    }
  }
  for (const id of ids) {
    const node = byId.get(id);
    const colSpan = node.colSpan ?? 1;
    const rowSpan = node.rowSpan ?? 1;
    const blockers = doc.nodes.filter((item) => item !== node).map(extentOf);
    const places = [];
    for (let row = Math.floor(node.row) - 2; row <= Math.ceil(node.row) + 2; row += 1) {
      for (let col = Math.floor(node.col) - 2; col <= Math.ceil(node.col) + 2; col += 1) {
        const distance = Math.abs(col - node.col) + Math.abs(row - node.row);
        if (distance === 0 || distance > 2 || col < 0 || row < 0 || col + colSpan > GRID_SIZE || row + rowSpan > GRID_SIZE) continue;
        const place = { col, row, right: col + colSpan, bottom: row + rowSpan };
        if (!blockers.some((blocker) => intersects(place, blocker))) places.push({ col, row, distance });
      }
    }
    places.sort((p, q) => p.distance - q.distance || p.row - q.row || p.col - q.col);
    for (const { col, row } of places) candidates.push({ suggestion: { node: id, col, row }, moves: { [id]: { col, row } } });
  }

  const lengthOf = (edgeLayouts) => edgeLayouts.reduce((sum, edge) => sum + segmentsOf(edge)
    .reduce((part, [[x1, y1], [x2, y2]]) => part + Math.abs(x2 - x1) + Math.abs(y2 - y1), 0), 0);
  const primaryBends = (edgeLayouts) => edgeLayouts.reduce((sum, edge) => sum + (edge.primary ? edge.points.length - 2 : 0), 0);
  const score = (after, edgeLayouts) => [after, primaryBends(edgeLayouts), lengthOf(edgeLayouts)];
  const better = (p, q) => p[0] - q[0] || p[1] - q[1] || p[2] - q[2];
  let best = null;
  for (const { suggestion, moves } of candidates) {
    if (budget.left <= 0) break;
    budget.left -= 1;
    const nodes = doc.nodes.map((node) => (moves[node.id] ? { ...node, col: moves[node.id].col, row: moves[node.id].row } : node));
    if (checkGroupFrames(nodes, groups).length > 0) continue;
    const result = layoutArchitecture({ ...doc, nodes });
    if (result.diagnostics.some((d) => d.severity === 'error') || architectureLabelOverlaps(doc, result.layout).length > 0) continue;
    const crossings = findCrossings(result.layout.edges);
    if (crossings.some((item) => item.i === i && item.j === j)) continue;
    const after = crossings.reduce((sum, item) => sum + item.count, 0);
    if (after >= total) continue;
    const value = score(after, result.layout.edges);
    if (!best || better(value, best.value) < 0) best = { suggestion, value };
  }
  return best ? best.suggestion : null;
}

// 列・行の数（部品の範囲の端から端まで）を、直し方の手がかりとして detail に入れる。
function checkSize(nodes, layout, limits) {
  const count = (start, span) => Math.ceil(Math.max(...nodes.map((node) => node[start] + (node[span] ?? 1))))
    - Math.floor(Math.min(...nodes.map((node) => node[start])));
  return oversize(layout, limits, { width: { columns: count('col', 'colSpan') }, height: { rows: count('row', 'rowSpan') } });
}
