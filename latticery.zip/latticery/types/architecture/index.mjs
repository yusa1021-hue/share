// 図の種類「architecture」の定義。core/check.mjs に渡して使う。

import { createValidator } from '../../core/schema.mjs';
import { VALUE_SYNONYMS, checkArchitecture, inspectArchitecture } from './checks.mjs';
import { layoutArchitecture } from './layout.mjs';
import { architectureMessages, kindNames } from './messages.mjs';
import { KINDS, architectureStyles, iconElement, renderArchitecture } from './render.mjs';

// schema には types/architecture/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createArchitectureType(schema) {
  return {
    name: 'architecture',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkArchitecture,
    layout: layoutArchitecture,
    inspect: inspectArchitecture,
    render: renderArchitecture,
    styles: architectureStyles,
    legend: legendItems,
    icon: (kind, options) => (KINDS.includes(kind) ? iconElement(kind, options) : null),
    messages: architectureMessages,
  };
}

// 凡例の項目。図で使われている種類だけを、決まった順に並べる。
// key は CSS のクラス（.lt-kind-<key>）に使い、色は types の styles() の CSS で決まる。
function legendItems(doc, lang) {
  const used = new Set(doc.nodes.map((node) => node.kind));
  return KINDS.filter((kind) => used.has(kind)).map((kind) => ({ key: kind, label: kindNames[lang][kind], icon: iconElement(kind) }));
}
