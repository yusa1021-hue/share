// 図の種類「architecture」の定義。core/check.mjs に渡して使う。

import { KINDS, iconElement, kindLegend } from '../../core/kinds.mjs';
import { createValidator } from '../../core/schema.mjs';
import { VALUE_SYNONYMS, checkArchitecture, inspectArchitecture } from './checks.mjs';
import { layoutArchitecture } from './layout.mjs';
import { architectureMessages, styleNames } from './messages.mjs';
import { LEGEND_STYLES, architectureStyles, renderArchitecture, styleSample } from './render.mjs';

// schema には types/architecture/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createArchitectureType(schema) {
  return {
    name: 'architecture',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkArchitecture,
    layout: layoutArchitecture,
    inspect: inspectArchitecture,
    render: renderArchitecture,
    styles: architectureStyles,
    legend: legendItems,
    icon: (kind, options) => (KINDS.includes(kind) ? iconElement(kind, options) : null),
    messages: architectureMessages,
  };
}

// 凡例の項目。図で使われている部品の種類・線の種類・枠の種類だけを、決まった順に並べる。
// 部品の種類は icon（記号）を返す（core/kinds.mjs の kindLegend）。
// 線と枠の種類は sample（見本の SVG）を返す。ふつうの線（どの種類も付けない線）は出さない。
function legendItems(doc, lang) {
  const kinds = new Set(doc.nodes.map((node) => node.kind));
  const edges = doc.edges ?? [];
  const groups = doc.groups ?? [];
  const styles = new Set([
    ...['primary', 'async', 'both'].filter((style) => edges.some((edge) => edge[style])),
    ...groups.map((group) => group.style ?? 'boundary'),
  ]);
  return [
    ...kindLegend(kinds, lang),
    ...LEGEND_STYLES.filter((style) => styles.has(style)).map((style) => ({ key: style, label: styleNames[lang][style], sample: styleSample(style) })),
  ];
}
