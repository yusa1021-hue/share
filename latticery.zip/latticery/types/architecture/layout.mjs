// architecture の配置の計算。仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」
//
// 1. 部品を「半マス」単位の格子に置く（core/grid.mjs）。格子の線は、通路の中心線（偶数番）と列・行の中心線（奇数番）
// 2. 格子の線の上で、つながりの経路を探す（core/route.mjs）。部品の内部は通らない
// 3. 同じ線の上を通る経路を、少しずつずらして並べ、ラベルの場所を決める（core/lanes.mjs）。
//    兄弟の線（下の isSibling）は、分かれるまでを重ねる
// 4. 文字の幅・レーン・ラベル・枠の余白から、列・行・通路の幅を決める（下の sizeAxes と core/axis.mjs）
// 5. 座標（px）に変換する
//
// 1〜4 の図の種類によらない部分は core/ にあり、このファイルには architecture だけのもの
// （枠、兄弟の線の決まり、寸法の組み立て）を置く（決定記録 No.84）。
// 入力は、スキーマ検証と構造のチェックを通った図であること。

import { addSpanConstraint, createAxis, evaluate, raiseMin, sizeGrid } from '../../core/axis.mjs';
import { border, buildGrid, line, round } from '../../core/grid.mjs';
import { EDGE, anchorAt, assignLanes, buildRuns, chooseLabels, edgePoints, highOf, labelWidth, lowOf, pairOrders, placeLanes, sharedVertices } from '../../core/lanes.mjs';
import { NODE, nodeSize, tagBox } from '../../core/node.mjs';
import { routeEdges } from '../../core/route.mjs';
import { estimateWidth } from '../../core/text.mjs';

// ---- チェック（checks.mjs）と共通で使うもの ------------------------------------------

// 枠の入れ子を、contains の包含関係から決める。
// ある枠の部品がすべて別の枠にも入っていれば、その枠は内側になる。中身がまったく同じ枠は、配列で先に書いたほうを外側にする。
// 返り値は枠ごとの { id, parent, depth, chain }（chain は外側から順に並べた ID）。
export function nestGroups(groups) {
  const sets = groups.map((group) => new Set(group.contains));
  const encloses = (outer, inner) => outer !== inner
    && isSubset(sets[inner], sets[outer])
    && (sets[inner].size < sets[outer].size || outer < inner);

  // 自分を囲む枠のうち、いちばん小さいもの（同じ大きさなら、配列で後に書いたもの）を親とする。
  const parents = groups.map((_, inner) => {
    let parent = null;
    groups.forEach((_, outer) => {
      if (!encloses(outer, inner)) return;
      if (parent === null || sets[outer].size < sets[parent].size
        || (sets[outer].size === sets[parent].size && outer > parent)) parent = outer;
    });
    return parent;
  });

  const chainOf = (index) => (parents[index] === null ? [index] : [...chainOf(parents[index]), index]);
  return groups.map((group, index) => {
    const chain = chainOf(index).map((i) => groups[i].id);
    const parent = parents[index] === null ? null : groups[parents[index]].id;
    return { id: group.id, parent, depth: chain.length, chain };
  });
}

// 同じ部品から出る線、または同じ部品に入る線で、種類（primary・async・both）が同じものを「兄弟」と呼ぶ。
// 兄弟の線は、同じ接続点から出る（入る）なら、分かれるまで（合流してから）を重ねて1本の幹として描く。
// 種類が違う線を重ねると、実線と破線が混ざって読めなくなるので、兄弟にしない。
export const sameStyle = (a, b) => Boolean(a.primary) === Boolean(b.primary)
  && Boolean(a.async) === Boolean(b.async) && Boolean(a.both) === Boolean(b.both);
export const isSibling = (a, b) => sameStyle(a, b) && (a.from === b.from || a.to === b.to);

export function isSubset(small, large) {
  return [...small].every((item) => large.has(item));
}

// ---- 寸法と重み ----------------------------------------------------------------

export const METRICS = {
  node: NODE, // 部品の箱の寸法（sequence と共通。core/node.mjs）
  edge: EDGE, // 線とラベルの寸法（core/lanes.mjs）
  group: { pad: 14, labelSize: 12, labelBand: 20, labelInset: 10 },
  // base：内側の通路の最小幅。outer：外周の通路の最小幅。emptyTrack：部品のない列・行の幅。
  // oddInset：列・行の中心線に接する部品（半マスずらし）と中心線との間隔。
  gutter: { base: 44, outer: 12, emptyTrack: 16, oddInset: 22 },
};

/**
 * 配置を計算する。返り値は { layout, diagnostics }。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutArchitecture(doc) {
  const edges = doc.edges ?? [];
  const groups = doc.groups ?? [];
  const grid = buildGrid(doc.nodes);
  const { routes, diagnostics } = routeEdges(edges, grid, { sibling: isSibling });
  const runsByEdge = routes.map((route) => (route ? buildRuns(route, grid) : null));
  const buckets = assignLanes(runsByEdge, sharedVertices(edges, routes, sameStyle), pairOrders(routes));
  const labels = chooseLabels(edges, runsByEdge);
  const labelRuns = labels.map((label) => label?.run ?? null);
  const labelAnchors = labels.map((label) => label?.anchor ?? null);
  const laneWidths = placeLanes(buckets, labels, edges);
  const frames = frameGroups(groups, grid);

  const x = createAxis(grid.cols, METRICS.gutter.oddInset);
  const y = createAxis(grid.rows, METRICS.gutter.oddInset);
  sizeAxes({ doc, grid, runsByEdge, labelRuns, labelAnchors, laneWidths, frames, x, y });
  const X = evaluate(x);
  const Y = evaluate(y);

  const nodes = grid.boxes.map((box) => {
    const left = X.at(border(box.a, 1));
    const top = Y.at(border(box.c, 1));
    const result = {
      id: box.node.id,
      kind: box.node.kind,
      label: box.node.label,
      sublabel: box.node.sublabel ?? null,
      tag: box.node.tag ?? null,
      x: round(left),
      y: round(top),
      width: round(X.at(border(box.b, -1))) - round(left),
      height: round(Y.at(border(box.d, -1))) - round(top),
      tagBox: null,
    };
    if (result.tag) result.tagBox = tagBox(result);
    return result;
  });

  const edgeLayouts = [];
  edges.forEach((edge, i) => {
    const runs = runsByEdge[i];
    if (!runs) return;
    const points = edgePoints(runs, X, Y);
    const labelRun = labelRuns[i];
    let labelBox = null;
    if (labelRun) {
      const width = labelWidth(edge.label);
      const height = METRICS.edge.labelHeight;
      const anchor = labelAnchors[i];
      const across = labels[i].across ?? 0;
      const cx = labelRun.axis === 'h' ? anchorAt(X, laneWidths.v, anchor) + across : X.at(line(labelRun.line)) + labelRun.offset;
      const cy = labelRun.axis === 'h' ? Y.at(line(labelRun.line)) + labelRun.offset : anchorAt(Y, laneWidths.h, anchor) + across;
      labelBox = { x: round(cx - width / 2), y: round(cy - height / 2), width, height };
    }
    edgeLayouts.push({
      id: edge.id ?? null,
      from: edge.from,
      to: edge.to,
      label: edge.label ?? null,
      async: Boolean(edge.async),
      primary: Boolean(edge.primary),
      both: Boolean(edge.both),
      points,
      labelBox,
    });
  });

  const groupLayouts = frames.map((frame) => {
    const left = X.at(border(frame.a, 1)) - frame.pads.left;
    const top = Y.at(border(frame.c, 1)) - frame.pads.top;
    const box = {
      id: frame.group.id,
      label: frame.group.label,
      style: frame.group.style ?? 'boundary',
      depth: frame.depth,
      x: round(left),
      y: round(top),
      width: round(X.at(border(frame.b, -1)) + frame.pads.right) - round(left),
      height: round(Y.at(border(frame.d, -1)) + frame.pads.bottom) - round(top),
      labelY: round(top + METRICS.group.pad / 2 + METRICS.group.labelBand / 2),
    };
    box.labelX = round(placeGroupLabel(box, edgeLayouts));
    // 枠の名前が占める範囲。高さは名前を置く帯の高さ（placeGroupLabel が線を避ける範囲と同じ）。
    const { labelSize, labelBand } = METRICS.group;
    box.labelBox = { x: box.labelX, y: box.labelY - labelBand / 2, width: estimateWidth(box.label, labelSize, { bold: true }), height: labelBand };
    return box;
  });

  return {
    layout: { width: round(X.total), height: round(Y.total), nodes, groups: groupLayouts, edges: edgeLayouts },
    diagnostics,
  };
}

// ---- 寸法 ----------------------------------------------------------------

// 枠の範囲（半マス単位）と、各辺の余白を決める。
// 余白は、内側の枠と縁が同じ位置に来る辺だけ、内側の枠の余白の分だけ広げる（外側の枠ほど余白が大きくなる）。
// 上辺の余白には、枠の名前を書く帯を含める。
function frameGroups(groups, grid) {
  const nesting = nestGroups(groups);
  const { pad, labelBand } = METRICS.group;
  const frames = groups.map((group, i) => {
    const members = group.contains.map((id) => grid.byId.get(id));
    return {
      group,
      depth: nesting[i].depth,
      parent: nesting[i].parent,
      a: Math.min(...members.map((m) => m.a)),
      b: Math.max(...members.map((m) => m.b)),
      c: Math.min(...members.map((m) => m.c)),
      d: Math.max(...members.map((m) => m.d)),
      pads: null,
    };
  });
  const padsOf = (frame) => {
    if (frame.pads) return frame.pads;
    const kids = frames.filter((other) => other.parent === frame.group.id).map((kid) => ({ kid, pads: padsOf(kid) }));
    const extra = (side, edge) => Math.max(0, ...kids.filter(({ kid }) => kid[edge] === frame[edge]).map(({ pads }) => pads[side]));
    frame.pads = {
      left: pad + extra('left', 'a'),
      right: pad + extra('right', 'b'),
      top: pad + labelBand + extra('top', 'c'),
      bottom: pad + extra('bottom', 'd'),
    };
    return frame.pads;
  };
  frames.forEach(padsOf);
  return frames;
}

// 枠の名前と、それを横切る線との間隔。
const GROUP_LABEL_GAP = 6;

// 枠の名前は左上に置く。縦の線やラベルが名前の帯を横切る場合は、右へずらす。入りきらなければ左上のままにする。
function placeGroupLabel(box, edgeLayouts) {
  const { labelInset, labelSize, labelBand } = METRICS.group;
  const width = estimateWidth(box.label, labelSize, { bold: true });
  const top = box.labelY - labelBand / 2;
  const bottom = box.labelY + labelBand / 2;
  const gap = GROUP_LABEL_GAP;
  const blocked = [];
  for (const edge of edgeLayouts) {
    for (let i = 0; i + 1 < edge.points.length; i += 1) {
      const [x1, y1] = edge.points[i];
      const [x2, y2] = edge.points[i + 1];
      if (x1 === x2 && Math.max(y1, y2) > top && Math.min(y1, y2) < bottom) blocked.push([x1, x1]);
    }
    const label = edge.labelBox;
    if (label && label.y + label.height > top && label.y < bottom) blocked.push([label.x, label.x + label.width]);
  }
  blocked.sort((p, q) => p[0] - q[0]);
  const start = box.x + labelInset;
  let x = start;
  for (const [from, to] of blocked) {
    if (to < x - gap || from > x + width + gap) continue;
    x = to + gap;
  }
  return x + width <= box.x + box.width - labelInset ? x : start;
}

// 寸法の制約を集める。共通の分（部品の大きさ・通路・線の端・ラベル）は core/axis.mjs の sizeGrid が行い、
// ここでは枠の余白と枠の名前の分を足す。
function sizeAxes({ doc, grid, runsByEdge, labelRuns, labelAnchors, laneWidths, frames, x, y }) {
  const edges = doc.edges ?? [];
  // 列・行の中心線に接する部品（半マスずらし）との間隔に、枠の余白を入れる。
  const pads = { x: new Map(), y: new Map() };
  const notePad = (map, k, value) => { if (k % 2 === 1) map.set(k, Math.max(map.get(k) ?? 0, value)); };
  for (const frame of frames) {
    notePad(pads.x, frame.a, frame.pads.left);
    notePad(pads.x, frame.b, frame.pads.right);
    notePad(pads.y, frame.c, frame.pads.top);
    notePad(pads.y, frame.d, frame.pads.bottom);
  }
  sizeGrid({ grid, edges, runsByEdge, labelRuns, labelAnchors, laneWidths, x, y, gutter: METRICS.gutter, sizeOf: nodeSize, pads });

  // 枠の余白。通路側の縁は L・R に入れる（奇数番の線に接する縁は、上の間隔に含めた）。
  for (const frame of frames) {
    if (frame.a % 2 === 0) raiseMin(x, x.index.R[frame.a / 2], frame.pads.left);
    if (frame.b % 2 === 0) raiseMin(x, x.index.L[frame.b / 2], frame.pads.right);
    if (frame.c % 2 === 0) raiseMin(y, y.index.R[frame.c / 2], frame.pads.top);
    if (frame.d % 2 === 0) raiseMin(y, y.index.L[frame.d / 2], frame.pads.bottom);
    const { labelSize, labelInset } = METRICS.group;
    const nameWidth = estimateWidth(frame.group.label, labelSize, { bold: true });
    addSpanConstraint(x, border(frame.a, 1), border(frame.b, -1), nameWidth + 2 * labelInset - frame.pads.left - frame.pads.right, ['H', 'B']);
    // 枠の上辺を縦に横切る線があれば、いちばん右の線より右に、枠の名前が入るだけの幅を空ける（placeGroupLabel と対応）。
    const crossings = runsByEdge.flatMap((runs) => (runs ?? [])
      .filter((run) => run.axis === 'v' && run.line > frame.a && run.line < frame.b && lowOf(run) <= frame.c && highOf(run) > frame.c)
      .map((run) => run.line));
    if (crossings.length > 0) {
      const need = nameWidth + GROUP_LABEL_GAP + labelInset - frame.pads.right;
      addSpanConstraint(x, line(Math.max(...crossings)), border(frame.b, -1), need, ['H', 'B']);
    }
  }
}

// ---- 座標 ----------------------------------------------------------------

