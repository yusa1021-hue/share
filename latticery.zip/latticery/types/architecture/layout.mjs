// architecture の配置の計算。仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」
//
// 1. 部品を「半マス」単位の格子に置く。格子の線は、通路の中心線（偶数番）と列・行の中心線（奇数番）
// 2. 格子の線の上で、つながりの経路を探す。部品の内部は通らない
// 3. 同じ線の上を通る経路を、少しずつずらして並べる（レーン）。兄弟の線（下の isSibling）は、分かれるまでを重ねる。
//    並べる順番は、2本の線が一緒に通る部分の両端で、どちら側へ分かれるかから決める。ラベルを置いたレーンは、ラベルの分だけ太くする
// 4. 文字の幅・レーン・ラベル・枠の余白から、列・行・通路の幅を決める
// 5. 座標（px）に変換する
//
// 入力は、スキーマ検証と構造のチェックを通った図であること。

import { error } from '../../core/diagnostics.mjs';
import { estimateWidth } from '../../core/text.mjs';

// ---- チェック（checks.mjs）と共通で使うもの ------------------------------------------

// 枠の入れ子を、contains の包含関係から決める。
// ある枠の部品がすべて別の枠にも入っていれば、その枠は内側になる。中身がまったく同じ枠は、配列で先に書いたほうを外側にする。
// 返り値は枠ごとの { id, parent, depth, chain }（chain は外側から順に並べた ID）。
export function nestGroups(groups) {
  const sets = groups.map((group) => new Set(group.contains));
  const encloses = (outer, inner) => outer !== inner
    && isSubset(sets[inner], sets[outer])
    && (sets[inner].size < sets[outer].size || outer < inner);

  // 自分を囲む枠のうち、いちばん小さいもの（同じ大きさなら、配列で後に書いたもの）を親とする。
  const parents = groups.map((_, inner) => {
    let parent = null;
    groups.forEach((_, outer) => {
      if (!encloses(outer, inner)) return;
      if (parent === null || sets[outer].size < sets[parent].size
        || (sets[outer].size === sets[parent].size && outer > parent)) parent = outer;
    });
    return parent;
  });

  const chainOf = (index) => (parents[index] === null ? [index] : [...chainOf(parents[index]), index]);
  return groups.map((group, index) => {
    const chain = chainOf(index).map((i) => groups[i].id);
    const parent = parents[index] === null ? null : groups[parents[index]].id;
    return { id: group.id, parent, depth: chain.length, chain };
  });
}

// 同じ部品から出る線、または同じ部品に入る線で、種類（primary・async・both）が同じものを「兄弟」と呼ぶ。
// 兄弟の線は、同じ接続点から出る（入る）なら、分かれるまで（合流してから）を重ねて1本の幹として描く。
// 種類が違う線を重ねると、実線と破線が混ざって読めなくなるので、兄弟にしない。
export const sameStyle = (a, b) => Boolean(a.primary) === Boolean(b.primary)
  && Boolean(a.async) === Boolean(b.async) && Boolean(a.both) === Boolean(b.both);
export const isSibling = (a, b) => sameStyle(a, b) && (a.from === b.from || a.to === b.to);

// 線についての診断の対象。ID があればその ID、なければ始点と終点の部品の ID。
export function edgeTarget(edge) {
  return edge.id ? [edge.id] : [...new Set([edge.from, edge.to])];
}

export function isSubset(small, large) {
  return [...small].every((item) => large.has(item));
}

// ---- 寸法と重み ----------------------------------------------------------------

export const METRICS = {
  node: {
    minWidth: 112, paddingX: 14, iconSize: 14, iconGap: 6,
    labelSize: 14, sublabelSize: 12, tagSize: 10, tagPaddingX: 6, tagInset: 12, tagHeight: 16,
    height: 44, heightWithSublabel: 60,
  },
  edge: { labelSize: 11, labelPaddingX: 6, labelHeight: 18, labelMargin: 8, laneGap: 10, laneMargin: 8 },
  group: { pad: 14, labelSize: 12, labelBand: 20, labelInset: 10 },
  // base：内側の通路の最小幅。outer：外周の通路の最小幅。emptyTrack：部品のない列・行の幅。
  // oddInset：列・行の中心線に接する部品（半マスずらし）と中心線との間隔。
  gutter: { base: 44, outer: 12, emptyTrack: 16, oddInset: 22 },
};

// 経路の選び方の重み。小さいほど好ましい。
// 辺の重み：相手の方を向いた辺は 0、横を向いた辺は sidePerpendicular、反対を向いた辺は sideAway。
// axis は、相手の方を向いた2つの辺のうち、主な向き（相手が主に左右にあれば左右）でない辺に加える重み。
// 曲がる回数が1回増えるより重くし、左右に並ぶ部品どうしは左右の辺でつなぐ（枝分かれする線が木の形になる）ようにする。
// junction は、ほかの線が通る頂点で曲がる場合の重み。touch は、ほかの線が曲がる頂点をまっすぐ通る場合の重み。
// どちらも、線が込み合って見分けにくくなるのを避けるため（両端の部品の接続点では加えない）。
// mixedPort は、同じ接続点に「出ていく線」と「入ってくる線」が混ざる場合の重み（同じ2つの部品の間の往復は除く）。
const COST = {
  step: 1, bend: 3, cross: 5, junction: 3, touch: 1, share: 0.5, mixedPort: 4,
  sidePerpendicular: 2, sideAway: 5, axis: 3.5,
};

const DIRS = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // 右・下・左・上
const SIDE_DIR = { right: 0, bottom: 1, left: 2, top: 3 };
const SIDES = ['right', 'bottom', 'left', 'top'];

/**
 * 配置を計算する。返り値は { layout, diagnostics }。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutArchitecture(doc) {
  const edges = doc.edges ?? [];
  const groups = doc.groups ?? [];
  const grid = buildGrid(doc.nodes);
  const { routes, diagnostics } = routeEdges(edges, grid);
  const runsByEdge = routes.map((route) => (route ? buildRuns(route, grid) : null));
  const buckets = assignLanes(runsByEdge, sharedVertices(edges, routes), pairOrders(routes));
  const labels = chooseLabels(edges, runsByEdge);
  const labelRuns = labels.map((label) => label?.run ?? null);
  const labelAnchors = labels.map((label) => label?.anchor ?? null);
  const laneWidths = placeLanes(buckets, labels, edges);
  const frames = frameGroups(groups, grid);

  const x = createAxis(grid.cols);
  const y = createAxis(grid.rows);
  sizeAxes({ doc, grid, runsByEdge, labelRuns, labelAnchors, laneWidths, frames, x, y });
  const X = evaluate(x);
  const Y = evaluate(y);

  const nodes = grid.boxes.map((box) => {
    const left = X.at(border(box.a, 1));
    const top = Y.at(border(box.c, 1));
    const result = {
      id: box.node.id,
      kind: box.node.kind,
      label: box.node.label,
      sublabel: box.node.sublabel ?? null,
      tag: box.node.tag ?? null,
      x: round(left),
      y: round(top),
      width: round(X.at(border(box.b, -1))) - round(left),
      height: round(Y.at(border(box.d, -1))) - round(top),
      tagBox: null,
    };
    if (result.tag) result.tagBox = tagBox(result);
    return result;
  });

  const edgeLayouts = [];
  edges.forEach((edge, i) => {
    const runs = runsByEdge[i];
    if (!runs) return;
    const points = edgePoints(runs, X, Y);
    const labelRun = labelRuns[i];
    let labelBox = null;
    if (labelRun) {
      const width = labelWidth(edge.label);
      const height = METRICS.edge.labelHeight;
      const anchor = labelAnchors[i];
      const across = labels[i].across ?? 0;
      const cx = labelRun.axis === 'h' ? anchorAt(X, laneWidths.v, anchor) + across : X.at(line(labelRun.line)) + labelRun.offset;
      const cy = labelRun.axis === 'h' ? Y.at(line(labelRun.line)) + labelRun.offset : anchorAt(Y, laneWidths.h, anchor) + across;
      labelBox = { x: round(cx - width / 2), y: round(cy - height / 2), width, height };
    }
    edgeLayouts.push({
      id: edge.id ?? null,
      from: edge.from,
      to: edge.to,
      label: edge.label ?? null,
      async: Boolean(edge.async),
      primary: Boolean(edge.primary),
      both: Boolean(edge.both),
      points,
      labelBox,
    });
  });

  const groupLayouts = frames.map((frame) => {
    const left = X.at(border(frame.a, 1)) - frame.pads.left;
    const top = Y.at(border(frame.c, 1)) - frame.pads.top;
    const box = {
      id: frame.group.id,
      label: frame.group.label,
      style: frame.group.style ?? 'boundary',
      depth: frame.depth,
      x: round(left),
      y: round(top),
      width: round(X.at(border(frame.b, -1)) + frame.pads.right) - round(left),
      height: round(Y.at(border(frame.d, -1)) + frame.pads.bottom) - round(top),
      labelY: round(top + METRICS.group.pad / 2 + METRICS.group.labelBand / 2),
    };
    box.labelX = round(placeGroupLabel(box, edgeLayouts));
    // 枠の名前が占める範囲。高さは名前を置く帯の高さ（placeGroupLabel が線を避ける範囲と同じ）。
    const { labelSize, labelBand } = METRICS.group;
    box.labelBox = { x: box.labelX, y: box.labelY - labelBand / 2, width: estimateWidth(box.label, labelSize, { bold: true }), height: labelBand };
    return box;
  });

  return {
    layout: { width: round(X.total), height: round(Y.total), nodes, groups: groupLayouts, edges: edgeLayouts },
    diagnostics,
  };
}

// ---- 1. 格子 ----------------------------------------------------------------

// 部品の範囲を半マス単位の番号 [a, b) × [c, d) で表す。使われている列・行だけを残し、左上を 0 にそろえる。
function buildGrid(nodes) {
  const spans = nodes.map((node) => ({
    node,
    a: node.col * 2,
    b: (node.col + (node.colSpan ?? 1)) * 2,
    c: node.row * 2,
    d: (node.row + (node.rowSpan ?? 1)) * 2,
  }));
  const firstCol = Math.floor(Math.min(...spans.map((s) => s.a)) / 2);
  const firstRow = Math.floor(Math.min(...spans.map((s) => s.c)) / 2);
  const cols = Math.ceil(Math.max(...spans.map((s) => s.b)) / 2) - firstCol;
  const rows = Math.ceil(Math.max(...spans.map((s) => s.d)) / 2) - firstRow;
  const boxes = spans.map((s) => ({
    node: s.node,
    a: s.a - 2 * firstCol,
    b: s.b - 2 * firstCol,
    c: s.c - 2 * firstRow,
    d: s.d - 2 * firstRow,
  }));

  // 格子の線の区間のうち、部品の内部を通るものを通れなくする。
  const blocked = new Set();
  for (const box of boxes) {
    for (let k = box.a + 1; k < box.b; k += 1) {
      for (let l = box.c; l < box.d; l += 1) blocked.add(`v${k},${l}`);
    }
    for (let l = box.c + 1; l < box.d; l += 1) {
      for (let k = box.a; k < box.b; k += 1) blocked.add(`h${k},${l}`);
    }
  }
  return { cols, rows, maxK: cols * 2, maxL: rows * 2, boxes, byId: new Map(boxes.map((box) => [box.node.id, box])), blocked };
}

function canMove(grid, k, l, dir) {
  const [dx, dy] = DIRS[dir];
  const k2 = k + dx;
  const l2 = l + dy;
  if (k2 < 0 || l2 < 0 || k2 > grid.maxK || l2 > grid.maxL) return false;
  return !grid.blocked.has(segmentKey(k, l, dir));
}

function segmentKey(k, l, dir) {
  const [dx, dy] = DIRS[dir];
  return dx !== 0 ? `h${Math.min(k, k + dx)},${l}` : `v${k},${Math.min(l, l + dy)}`;
}

// 各辺の接続点（格子の頂点）。上辺なら、部品の範囲の内側にある縦の線と、上端の横の線との交点。
function ports(box, side) {
  const between = (from, to) => Array.from({ length: Math.max(0, to - from - 1) }, (_, i) => from + 1 + i);
  switch (side) {
    case 'top': return between(box.a, box.b).map((k) => [k, box.c]);
    case 'bottom': return between(box.a, box.b).map((k) => [k, box.d]);
    case 'left': return between(box.c, box.d).map((l) => [box.a, l]);
    default: return between(box.c, box.d).map((l) => [box.b, l]);
  }
}

// ---- 2. 経路 ----------------------------------------------------------------

function routeEdges(edges, grid) {
  const decided = [];
  const routes = new Array(edges.length).fill(null);
  const diagnostics = [];
  // 主な経路（primary）から先に決める。同じ扱いの線は書いた順。
  const sequence = edges
    .map((edge, index) => ({ edge, index }))
    .sort((p, q) => Number(Boolean(q.edge.primary)) - Number(Boolean(p.edge.primary)) || p.index - q.index);
  for (const { edge, index } of sequence) {
    // all は交差を数えるため、すべての線を記録する。
    // others は重なりと込み合いを数えるため、兄弟の線を除く（兄弟の線とは、幹を共有して同じ位置で枝分かれできるように）。
    const usage = { all: createUsage(), others: createUsage() };
    for (const done of decided) {
      recordUsage(done.route, usage.all);
      if (!isSibling(done.edge, edge)) recordUsage(done.route, usage.others);
    }
    const route = findRoute(edge, grid, usage);
    if (!route) {
      diagnostics.push(error('edge/no-route', {
        target: edgeTarget(edge),
        detail: { path: `/edges/${index}`, from: edge.from, to: edge.to },
      }));
      continue;
    }
    decided.push({ edge, route });
    routes[index] = route;
  }
  return { routes, diagnostics };
}

function createUsage() {
  return { pass: new Map(), segments: new Map(), ports: new Map() };
}

// 辺を指定していないときに、相手の方を向いた辺を優先するための点数。
function sidePenalty(box, other, side) {
  const dx = (other.a + other.b - box.a - box.b) / 2;
  const dy = (other.c + other.d - box.c - box.d) / 2;
  const [ox, oy] = DIRS[SIDE_DIR[side]];
  const dot = ox * dx + oy * dy;
  if (dot < 0) return COST.sideAway;
  if (dot === 0) return COST.sidePerpendicular;
  const minorAxis = (ox !== 0 && Math.abs(dy) > Math.abs(dx)) || (oy !== 0 && Math.abs(dx) > Math.abs(dy));
  return minorAxis ? COST.axis : 0;
}

// 状態（頂点・進む向き）についてのダイクストラ法。曲がる・交差する・ほかの線と重なる、に重みを付ける。
// usage は routeEdges の { all, others }。
function findRoute(edge, grid, usage) {
  const fromBox = grid.byId.get(edge.from);
  const toBox = grid.byId.get(edge.to);
  const goals = new Map();
  for (const side of edge.toSide ? [edge.toSide] : SIDES) {
    const penalty = edge.toSide ? 0 : sidePenalty(toBox, fromBox, side);
    for (const [k, l] of ports(toBox, side)) {
      const key = `${k},${l}`;
      if (!goals.has(key)) goals.set(key, []);
      const mixed = portUsedAs(usage.all, edge.to, k, l, 'out', edge.from) ? COST.mixedPort : 0;
      goals.get(key).push({ side, inward: (SIDE_DIR[side] + 2) % 4, penalty: penalty + mixed });
    }
  }

  const ownPorts = new Set(SIDES.flatMap((side) => [...ports(fromBox, side), ...ports(toBox, side)].map(([k, l]) => `${k},${l}`)));
  const heap = new MinHeap();
  for (const side of edge.fromSide ? [edge.fromSide] : SIDES) {
    const penalty = edge.fromSide ? 0 : sidePenalty(fromBox, toBox, side);
    for (const [k, l] of ports(fromBox, side)) {
      const mixed = portUsedAs(usage.all, edge.from, k, l, 'in', edge.to) ? COST.mixedPort : 0;
      heap.push(penalty + mixed, { k, l, dir: SIDE_DIR[side], side, prev: null });
    }
  }

  const done = new Set();
  while (heap.size > 0) {
    const { cost, value: state } = heap.pop();
    if (state.goal) return finishRoute(edge, state);
    const key = `${state.k},${state.l},${state.dir}`;
    if (done.has(key)) continue;
    done.add(key);

    for (const goal of goals.get(`${state.k},${state.l}`) ?? []) {
      if (state.dir === (goal.inward + 2) % 4) continue;
      const finish = cost + (state.dir === goal.inward ? 0 : COST.bend) + goal.penalty;
      heap.push(finish, { goal: true, side: goal.side, last: state });
    }
    for (let dir = 0; dir < 4; dir += 1) {
      if (dir === (state.dir + 2) % 4 || !canMove(grid, state.k, state.l, dir)) continue;
      let next = cost + COST.step + COST.share * (usage.others.segments.get(segmentKey(state.k, state.l, dir)) ?? 0);
      const here = usage.others.pass.get(`${state.k},${state.l}`);
      const busy = here && !ownPorts.has(`${state.k},${state.l}`);
      if (dir !== state.dir) {
        next += COST.bend;
        if (busy) next += COST.junction;
      } else if (crossesAt(usage.all, state.k, state.l, dir)) {
        next += COST.cross;
      } else if (busy && here.turn > 0) {
        next += COST.touch;
      }
      const [dx, dy] = DIRS[dir];
      heap.push(next, { k: state.k + dx, l: state.l + dy, dir, side: state.side, prev: state });
    }
  }
  return null;
}

function finishRoute(edge, goal) {
  const states = [];
  for (let state = goal.last; state; state = state.prev) states.push(state);
  states.reverse();
  return {
    from: edge.from,
    to: edge.to,
    fromSide: states[0].side,
    toSide: goal.side,
    vertices: states.map((state) => [state.k, state.l]),
  };
}

// 部品 nodeId の接続点 (k, l) を、別の相手（other 以外）とつながる線が role（'in' か 'out'）として使っているか。
function portUsedAs(usage, nodeId, k, l, role, other) {
  return (usage.ports.get(`${nodeId}:${k},${l}`) ?? []).some((entry) => entry.role === role && entry.other !== other);
}

function crossesAt(usage, k, l, dir) {
  const pass = usage.pass.get(`${k},${l}`);
  if (!pass) return false;
  return dir % 2 === 0 ? pass.v > 0 : pass.h > 0;
}

// 決まった経路を記録し、後の経路が交差や重なりを避けられるようにする。
function recordUsage(route, usage) {
  const { vertices } = route;
  const incoming = [SIDE_DIR[route.fromSide]];
  for (let i = 1; i < vertices.length; i += 1) incoming.push(directionBetween(vertices[i - 1], vertices[i]));
  const outgoing = [...incoming.slice(1), (SIDE_DIR[route.toSide] + 2) % 4];
  vertices.forEach(([k, l], i) => {
    const key = `${k},${l}`;
    const pass = usage.pass.get(key) ?? { h: 0, v: 0, turn: 0 };
    if (incoming[i] !== outgoing[i]) pass.turn += 1;
    else if (incoming[i] % 2 === 0) pass.h += 1;
    else pass.v += 1;
    usage.pass.set(key, pass);
  });
  for (let i = 1; i < vertices.length; i += 1) {
    const key = segmentKey(vertices[i - 1][0], vertices[i - 1][1], incoming[i]);
    usage.segments.set(key, (usage.segments.get(key) ?? 0) + 1);
  }
  const notePort = (nodeId, [k, l], role, other) => {
    const key = `${nodeId}:${k},${l}`;
    if (!usage.ports.has(key)) usage.ports.set(key, []);
    usage.ports.get(key).push({ role, other });
  };
  notePort(route.from, vertices[0], 'out', route.to);
  notePort(route.to, vertices.at(-1), 'in', route.from);
}

function directionBetween([k1, l1], [k2, l2]) {
  if (k2 > k1) return 0;
  if (l2 > l1) return 1;
  if (k2 < k1) return 2;
  return 3;
}

// ---- 3. 区間とレーン ----------------------------------------------------------

// 位置の表し方。格子の線そのものか、部品の縁（boundary の線の手前 dir=-1 か、先 dir=+1）。
const line = (index) => ({ type: 'line', index });
const border = (boundary, dir) => ({ type: 'border', boundary, dir });
// 並び順を比べるための数値。縁は、線と隣の線の間に来る。
const order = (spec) => (spec.type === 'line' ? spec.index : spec.boundary + spec.dir * (spec.boundary % 2 === 0 ? 0.5 : 0.25));

function borderPoint(box, side, [k, l]) {
  switch (side) {
    case 'top': return { x: line(k), y: border(box.c, 1) };
    case 'bottom': return { x: line(k), y: border(box.d, -1) };
    case 'left': return { x: border(box.a, 1), y: line(l) };
    default: return { x: border(box.b, -1), y: line(l) };
  }
}

// 経路を、まっすぐな区間（run）の並びにする。最初と最後は部品の縁から始まり、縁で終わる。
function buildRuns(route, grid) {
  const points = [
    borderPoint(grid.byId.get(route.from), route.fromSide, route.vertices[0]),
    ...route.vertices.map(([k, l]) => ({ x: line(k), y: line(l) })),
    borderPoint(grid.byId.get(route.to), route.toSide, route.vertices.at(-1)),
  ];
  const corners = [points[0]];
  for (let i = 1; i < points.length - 1; i += 1) {
    const prev = corners.at(-1);
    const here = points[i];
    const next = points[i + 1];
    const sameX = order(prev.x) === order(here.x) && order(here.x) === order(next.x);
    const sameY = order(prev.y) === order(here.y) && order(here.y) === order(next.y);
    if (!sameX && !sameY) corners.push(here);
  }
  corners.push(points.at(-1));

  const runs = [];
  for (let i = 0; i + 1 < corners.length; i += 1) {
    const p = corners[i];
    const q = corners[i + 1];
    if (order(p.x) === order(q.x)) runs.push({ axis: 'v', line: p.x.index, start: p.y, end: q.y, lane: 0, offset: 0, shared: false });
    else runs.push({ axis: 'h', line: p.y.index, start: p.x, end: q.x, lane: 0, offset: 0, shared: false });
  }
  return runs;
}

const lowOf = (run) => Math.min(order(run.start), order(run.end));
const highOf = (run) => Math.max(order(run.start), order(run.end));

// 区間の端で、隣の区間がどちらへ曲がるか（横の区間なら上へ -1・下へ +1、縦の区間なら左へ -1・右へ +1）。
// 部品の縁で終わる端は 0。
function turnAt(runs, index, atHigh) {
  const run = runs[index];
  const startIsLow = order(run.start) <= order(run.end);
  const neighbourIndex = atHigh === startIsLow ? index + 1 : index - 1;
  const neighbour = runs[neighbourIndex];
  if (!neighbour) return 0;
  const far = neighbourIndex > index ? neighbour.end : neighbour.start;
  return order(far) < run.line ? -1 : 1;
}

// 兄弟の線の組ごとに、同じ接続点から出る場合の共通の先頭と、同じ接続点に入る場合の共通の末尾の頂点を集める。
// 返り値のキーは "i,j"（i < j は線の番号）。
function sharedVertices(edges, routes) {
  const shared = new Map();
  const key = ([k, l]) => `${k},${l}`;
  for (let i = 0; i < routes.length; i += 1) {
    for (let j = i + 1; j < routes.length; j += 1) {
      const a = routes[i];
      const b = routes[j];
      if (!a || !b || !sameStyle(edges[i], edges[j])) continue;
      const length = Math.min(a.vertices.length, b.vertices.length);
      const vertices = new Set();
      if (a.from === b.from && a.fromSide === b.fromSide) {
        for (let t = 0; t < length && key(a.vertices[t]) === key(b.vertices[t]); t += 1) vertices.add(key(a.vertices[t]));
      }
      if (a.to === b.to && a.toSide === b.toSide) {
        for (let t = 1; t <= length && key(a.vertices.at(-t)) === key(b.vertices.at(-t)); t += 1) vertices.add(key(a.vertices.at(-t)));
      }
      if (vertices.size > 0) shared.set(`${i},${j}`, vertices);
    }
  }
  return shared;
}

// 経路を、部品の縁から縁までの点の並びとして表す。点 0 は始点の部品の縁、点 1〜n は格子の頂点、点 n+1 は終点の部品の縁。
// dirs[t] は点 t から t+1 への向き、keys[t] はその部分の名前（部品の縁から接続点までの部分は、部品・辺・接続点で決まる名前）、
// runOf[t] はその部分が入る区間（buildRuns の run）の番号。
function describePath(route) {
  const { vertices } = route;
  const grid = vertices.slice(1).map((point, t) => directionBetween(vertices[t], point));
  const dirs = [SIDE_DIR[route.fromSide], ...grid, (SIDE_DIR[route.toSide] + 2) % 4];
  const keys = [
    `${route.from}:${route.fromSide}:${vertices[0]}`,
    ...grid.map((dir, t) => segmentKey(vertices[t][0], vertices[t][1], dir)),
    `${route.to}:${route.toSide}:${vertices.at(-1)}`,
  ];
  const runOf = [];
  dirs.forEach((dir, t) => runOf.push(t === 0 ? 0 : runOf[t - 1] + Number(dir !== dirs[t - 1])));
  return {
    dirs,
    keys,
    runOf,
    segments: new Map(keys.map((key, t) => [key, t])),
    // 点 t に入る向きと、点 t から出る向き。部品の縁（両端の点）では null。
    into: (t) => (t === 0 ? null : dirs[t - 1]),
    out: (t) => (t === dirs.length ? null : dirs[t]),
  };
}

// 2本の経路が、格子の区間を続けて共有する部分（共有区間）。a の区間 from〜to が、b の区間 start〜finish に当たる。
// forward は、b が a と同じ向きに通るか。
function sharedChains(a, b) {
  const chains = [];
  let t = 0;
  while (t < a.dirs.length) {
    const u = b.segments.get(a.keys[t]);
    if (u === undefined) {
      t += 1;
      continue;
    }
    const forward = b.dirs[u] === a.dirs[t];
    let to = t;
    let finish = u;
    while (to + 1 < a.dirs.length && b.segments.get(a.keys[to + 1]) === (forward ? finish + 1 : finish - 1)) {
      to += 1;
      finish = b.segments.get(a.keys[to]);
    }
    chains.push({ from: t, to, start: u, finish, forward });
    t = to + 1;
  }
  return chains;
}

// 向き d に進むときの、向き x への曲がり方（左 -1・まっすぐ 0・右 1）。x が null（部品の中）なら null。
const turnOf = (d, x) => (x === null ? null : x === d ? 0 : x === (d + 1) % 4 ? 1 : -1);
const reverseOf = (d) => (d === null ? null : (d + 2) % 4);

// 共有区間で、a が b の左（a の進む向きに対して）にあるべきなら true、右なら false、決まらなければ null。
// 共有区間の終わりで2本が分かれる向き（より左へ曲がるほうが左）と、始まりで分かれる向き（逆向きにたどって同じように決める）から決める。
// 部品に出入りする端では、部品の中へ向かって分かれると考える（同じ接続点に出入りする2本は、そこでは決まらない）。
// 両端の結果が食い違うときは、どう並べても1回は交差するので、終わりの側の結果を使う。
function chainSide(a, b, chain) {
  // 2本の曲がり方から、a が左なら true。どちらかが部品の中へ入る（null）か、曲がり方が同じなら null。
  const compare = (d, x, y) => {
    const p = turnOf(d, x);
    const q = turnOf(d, y);
    return p === null || q === null || p === q ? null : p < q;
  };
  const end = a.dirs[chain.to];
  const bOut = chain.forward ? b.out(chain.finish + 1) : reverseOf(b.into(chain.finish));
  const atEnd = compare(end, a.out(chain.to + 1), bOut);

  const back = reverseOf(a.dirs[chain.from]);
  const bBack = chain.forward ? reverseOf(b.into(chain.start)) : b.out(chain.start + 1);
  // 逆向きにたどって左なら、進む向きに対しては右。
  const atStart = compare(back, reverseOf(a.into(chain.from)), bBack);
  return atEnd ?? (atStart === null ? null : !atStart);
}

// 共有区間から、レーンの順番を決める。返り値は、区間の組 "i:r|j:s"（線 i の r 番目の区間と、線 j の s 番目の区間）→
// 前者を上（縦の線なら左）のレーンに置くなら true。左右の関係は曲がり角を越えても変わらないので、共有区間の中のすべての区間で
// 同じ関係からレーンの順番を決める（角で内側と外側が入れ替わって交差するのを防ぐ）。
// 進む向きに対して左は、右へ進むなら上、下へ進むなら右、左へ進むなら下、上へ進むなら左。
function pairOrders(routes) {
  const paths = routes.map((route) => (route ? describePath(route) : null));
  const orders = new Map();
  for (let i = 0; i < paths.length; i += 1) {
    for (let j = i + 1; j < paths.length; j += 1) {
      const a = paths[i];
      const b = paths[j];
      if (!a || !b) continue;
      for (const chain of sharedChains(a, b)) {
        const left = chainSide(a, b, chain);
        if (left === null) continue;
        for (let t = chain.from; t <= chain.to; t += 1) {
          const u = chain.forward ? chain.start + (t - chain.from) : chain.start - (t - chain.from);
          const aFirst = left !== (a.dirs[t] === 1 || a.dirs[t] === 2);
          orders.set(`${i}:${a.runOf[t]}|${j}:${b.runOf[u]}`, aFirst);
          orders.set(`${j}:${b.runOf[u]}|${i}:${a.runOf[t]}`, !aFirst);
        }
      }
    }
  }
  return orders;
}

// 同じ線の上で重なる区間（端が触れるだけのものも含む）に、別々のレーンを割り当てる。
// ただし兄弟の線の区間は、重なる部分が共通の先頭・末尾に収まるなら、同じレーンに置く（重ねて1本の幹にする）。
// 幹として重ねた区間には shared を付ける（ラベルを置かないため）。
// 重なる区間の組の上下（左右）は、共有区間から決めた順番（pairOrders）に従う。決まっていない組は、端が触れるだけなら
// その点で上（左）へ曲がるほうを上（左）にし、それ以外は、上（左）へ曲がる区間ほど上（左）に置く。
// 返り値は、線（軸と番号）ごとの { axis, line, items, count }。items は区間の一覧、count はレーンの数。
function assignLanes(runsByEdge, shared, orders) {
  const canShare = (p, q) => {
    const vertices = shared.get(`${Math.min(p.edgeIndex, q.edgeIndex)},${Math.max(p.edgeIndex, q.edgeIndex)}`);
    if (!vertices) return false;
    const lo = Math.max(p.lo, q.lo);
    const hi = Math.min(p.hi, q.hi);
    if (Math.ceil(lo) > Math.floor(hi)) return false;
    for (let t = Math.ceil(lo); t <= Math.floor(hi); t += 1) {
      if (!vertices.has(p.run.axis === 'h' ? `${t},${p.run.line}` : `${p.run.line},${t}`)) return false;
    }
    return true;
  };
  const groups = new Map();
  runsByEdge.forEach((runs, edgeIndex) => runs?.forEach((run, index) => {
    const key = `${run.axis}${run.line}`;
    const turns = [turnAt(runs, index, false), turnAt(runs, index, true)];
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push({ run, index, lo: lowOf(run), hi: highOf(run), turns, tendency: turns[0] + turns[1], edgeIndex });
  }));
  const rank = (p, q) => p.tendency - q.tendency || p.lo - q.lo || p.hi - q.hi || p.edgeIndex - q.edgeIndex;
  const overlapping = (p, q) => Math.min(p.hi, q.hi) >= Math.max(p.lo, q.lo);
  // p を q より上（左）に置くか。
  const first = (p, q) => {
    const decided = orders.get(`${p.edgeIndex}:${p.index}|${q.edgeIndex}:${q.index}`);
    if (decided !== undefined) return decided;
    const point = Math.max(p.lo, q.lo);
    if (point === Math.min(p.hi, q.hi)) {
      const turn = (item) => (item.lo === point ? item.turns[0] : item.turns[1]);
      if (turn(p) !== turn(q)) return turn(p) < turn(q);
    }
    return rank(p, q) < 0;
  };

  const buckets = [];
  for (const items of groups.values()) {
    // 順番の決まりに従って並べる（決まりが循環するときは、rank がいちばん小さいものから置く）。
    const before = new Map(items.map((item) => [item, new Set()]));
    items.forEach((p, i) => items.slice(i + 1).forEach((q) => {
      if (!overlapping(p, q) || canShare(p, q)) return;
      if (first(p, q)) before.get(q).add(p);
      else before.get(p).add(q);
    }));
    const sequence = [];
    const rest = new Set(items);
    while (rest.size > 0) {
      const ready = [...rest].filter((item) => [...before.get(item)].every((p) => !rest.has(p)));
      const next = (ready.length > 0 ? ready : [...rest]).sort(rank)[0];
      sequence.push(next);
      rest.delete(next);
    }
    // レーンは、重なる区間のうち先に置いたものより下（右）にする。兄弟の線と重ねられるなら、そのレーンに置く。
    let count = 0;
    sequence.forEach((item, i) => {
      const placed = sequence.slice(0, i);
      let lane = Math.max(0, ...placed.filter((p) => overlapping(p, item) && !canShare(p, item)).map((p) => p.run.lane + 1));
      const partner = placed.filter((p) => canShare(p, item) && overlapping(p, item) && p.run.lane >= lane).sort((p, q) => p.run.lane - q.run.lane)[0];
      if (partner) lane = partner.run.lane;
      for (const p of placed) {
        if (p.run.lane === lane && Math.min(p.hi, item.hi) > Math.max(p.lo, item.lo)) p.run.shared = item.run.shared = true;
      }
      item.run.lane = lane;
      count = Math.max(count, lane + 1);
    });
    buckets.push({ axis: items[0].run.axis, line: items[0].run.line, items, count });
  }
  return buckets;
}

// レーンの位置（線からのずれ）を決める。返り値は、線ごとのレーン全体の幅（{ v: 縦の線, h: 横の線 }。どちらも 番号 → px）。
// ふつうのレーンは laneGap の間隔で並べる。ラベルは、区間の方向には anchor の前後 0.5（格子の番号）の範囲を占め、
// 区間と直角の方向にはラベルの太さ（横の区間なら高さ、縦の区間なら幅）を占める。ラベルの範囲にかかる区間やラベルがあるレーンとの間は、
// ラベルの太さの半分と labelMargin の分だけ離し、並んだ線がラベルに重ならないようにする。レーン全体の両端にも、ラベルの外に labelMargin を空ける。
// ほかの線が横切る位置に置いたラベル（crossed）のために、横切る線の側にもラベルだけのレーンを真ん中に足し、
// 横切る線をラベルの上下（左右）に分ける。そのレーンのずれを label.across に入れる。
function placeLanes(buckets, labels, edges) {
  const { laneGap, laneMargin, labelMargin, labelHeight } = METRICS.edge;
  const newLane = () => ({ runs: [], labels: [], offset: 0 });
  const linesByKey = new Map();
  const laneOfRun = new Map();
  for (const bucket of buckets) {
    const lanes = Array.from({ length: bucket.count }, newLane);
    for (const { run, lo, hi } of bucket.items) {
      lanes[run.lane].runs.push({ lo, hi });
      laneOfRun.set(run, lanes[run.lane]);
    }
    linesByKey.set(`${bucket.axis}${bucket.line}`, lanes);
  }
  const extra = new Map();
  labels.forEach((label, i) => {
    if (!label) return;
    const { run, anchor } = label;
    const width = labelWidth(edges[i].label);
    const [along, across] = run.axis === 'h' ? [width, labelHeight] : [labelHeight, width];
    laneOfRun.get(run).labels.push({ lo: anchor - 0.5, hi: anchor + 0.5, radius: across / 2 });
    if (label.crossed) {
      const lanes = linesByKey.get(`${run.axis === 'h' ? 'v' : 'h'}${anchor}`);
      const lane = newLane();
      lane.labels.push({ lo: run.line - 0.5, hi: run.line + 0.5, radius: along / 2 });
      lanes.splice(Math.floor(lanes.length / 2), 0, lane);
      extra.set(label, lane);
    }
  });

  const hits = (label, span) => span.lo < label.hi && span.hi > label.lo;
  // レーン p と q（p < q）の間に必要な間隔。
  const need = (p, q) => {
    let value = laneGap;
    for (const label of p.labels) {
      if (q.runs.some((span) => hits(label, span))) value = Math.max(value, label.radius + labelMargin);
      for (const other of q.labels) if (hits(label, other)) value = Math.max(value, label.radius + other.radius + labelMargin);
    }
    for (const label of q.labels) {
      if (p.runs.some((span) => hits(label, span))) value = Math.max(value, label.radius + labelMargin);
    }
    return value;
  };
  const reach = (lane) => Math.max(0, ...lane.labels.map((label) => label.radius + labelMargin));
  const end = laneGap / 2 + laneMargin;
  const widths = { v: new Map(), h: new Map() };
  for (const [key, lanes] of linesByKey) {
    const positions = [];
    lanes.forEach((lane, q) => {
      let position = Math.max(q === 0 ? end : positions[q - 1] + laneGap, reach(lane));
      for (let p = 0; p < q; p += 1) position = Math.max(position, positions[p] + need(lanes[p], lane));
      positions.push(position);
    });
    const width = Math.max(positions.at(-1) + end, ...lanes.map((lane, p) => positions[p] + reach(lane)));
    lanes.forEach((lane, p) => { lane.offset = positions[p] - width / 2; });
    widths[key[0]].set(Number(key.slice(1)), width);
  }
  for (const [run, lane] of laneOfRun) run.offset = lane.offset;
  for (const [label, lane] of extra) label.across = lane.offset;
  return widths;
}

// ラベルを置く区間と位置を決める。返り値は線ごとの { run, anchor }（ラベルがなければ null）。
// 位置 anchor は区間の方向に沿った格子の番号で、格子の線（整数）か、隣り合う線の中間（.5）。区間の両端（曲がり角や部品の縁）には置かない。
// 区間は、幹として重ねていないもの → 横向き → 長いもの の順に試す（幹にラベルがあると、どの線のラベルか分からなくなるため）。
// 区間の中では中央に近い位置を優先し（同じ近さなら 通路の中心線 → 線の中間 → 列・行の中心線 の順）、
// ほかの線が横切る位置と、同じレーンの別のラベルに近すぎる位置は避ける。どの区間にも避けられる位置がなければ、
// いちばん好ましい区間の、中央にいちばん近い位置に置き、crossed を付ける（横切る線をラベルの上下（左右）に分ける。placeLanes を参照）。
function chooseLabels(edges, runsByEdge) {
  const pointKey = (run, t) => (run.axis === 'h' ? `${t},${run.line}` : `${run.line},${t}`);
  const through = new Map();
  runsByEdge.forEach((runs, edgeIndex) => runs?.forEach((run) => {
    for (let t = Math.ceil(lowOf(run)); t <= Math.floor(highOf(run)); t += 1) {
      const key = pointKey(run, t);
      if (!through.has(key)) through.set(key, []);
      through.get(key).push({ edgeIndex, axis: run.axis });
    }
  }));
  const kindRank = (t) => (Number.isInteger(t) ? (t % 2 === 0 ? 0 : 2) : 1);
  const candidatesOf = (run) => {
    const lo = lowOf(run);
    const hi = highOf(run);
    const middle = (lo + hi) / 2;
    const list = [];
    for (let t = Math.ceil(lo * 2) / 2; t <= hi; t += 0.5) if (t > lo && t < hi) list.push(t);
    return list.sort((p, q) => Math.abs(p - middle) - Math.abs(q - middle) || kindRank(p) - kindRank(q) || p - q);
  };
  // 同じレーンに置いたラベルの位置。隣り合う位置（差が1未満）には置かない。
  const placed = new Map();
  const laneKey = (run) => `${run.axis}${run.line}:${run.lane}`;
  const crowded = (run, t) => (placed.get(laneKey(run)) ?? []).some((other) => Math.abs(other - t) < 1);
  const crossed = (run, t, edgeIndex) => Number.isInteger(t)
    && (through.get(pointKey(run, t)) ?? []).some((other) => other.edgeIndex !== edgeIndex && other.axis !== run.axis);
  const score = (run) => Math.abs(order(run.end) - order(run.start)) * (run.axis === 'h' ? 1.5 : 1);

  return edges.map((edge, edgeIndex) => {
    const runs = runsByEdge[edgeIndex];
    if (!edge.label || !runs) return null;
    const ranked = [...runs].sort((p, q) => Number(p.shared) - Number(q.shared) || score(q) - score(p));
    let choice = null;
    for (const run of ranked) {
      const candidates = candidatesOf(run);
      if (candidates.length === 0) continue;
      choice ??= { run, anchor: candidates.find((t) => !crowded(run, t)) ?? candidates[0] };
      const free = candidates.find((t) => !crowded(run, t) && !crossed(run, t, edgeIndex));
      if (free !== undefined) {
        choice = { run, anchor: free };
        break;
      }
    }
    // どの区間にも置ける位置がない（区間がすべて部品の縁から通路の中心線までの短いもの）ことは、今の経路の作り方では起きない。
    choice ??= { run: ranked[0], anchor: (lowOf(ranked[0]) + highOf(ranked[0])) / 2 };
    choice.crossed = crossed(choice.run, choice.anchor, edgeIndex);
    const key = laneKey(choice.run);
    if (!placed.has(key)) placed.set(key, []);
    placed.get(key).push(choice.anchor);
    return choice;
  });
}

// 線の中間に置くラベルと、両側の線との間に空ける幅。両側の線に並ぶレーン（ほかのラベルの分を含む）の半分か、labelMargin の大きいほう。
// lanes は、その方向の線の番号ごとのレーン全体の幅（placeLanes の返り値）。
function labelSides(lanes, t) {
  const side = (k) => Math.max(METRICS.edge.labelMargin, (lanes.get(k) ?? 0) / 2);
  return [side(Math.floor(t)), side(Math.ceil(t))];
}

// ラベルの位置（格子の番号）の座標。線の中間なら、両側に空ける幅を除いた範囲の中央。
function anchorAt(A, lanes, t) {
  if (Number.isInteger(t)) return A.at(line(t));
  const [before, after] = labelSides(lanes, t);
  return (A.at(line(Math.floor(t))) + before + A.at(line(Math.ceil(t))) - after) / 2;
}

// ---- 4. 寸法 ----------------------------------------------------------------

// 枠の範囲（半マス単位）と、各辺の余白を決める。
// 余白は、内側の枠と縁が同じ位置に来る辺だけ、内側の枠の余白の分だけ広げる（外側の枠ほど余白が大きくなる）。
// 上辺の余白には、枠の名前を書く帯を含める。
function frameGroups(groups, grid) {
  const nesting = nestGroups(groups);
  const { pad, labelBand } = METRICS.group;
  const frames = groups.map((group, i) => {
    const members = group.contains.map((id) => grid.byId.get(id));
    return {
      group,
      depth: nesting[i].depth,
      parent: nesting[i].parent,
      a: Math.min(...members.map((m) => m.a)),
      b: Math.max(...members.map((m) => m.b)),
      c: Math.min(...members.map((m) => m.c)),
      d: Math.max(...members.map((m) => m.d)),
      pads: null,
    };
  });
  const padsOf = (frame) => {
    if (frame.pads) return frame.pads;
    const kids = frames.filter((other) => other.parent === frame.group.id).map((kid) => ({ kid, pads: padsOf(kid) }));
    const extra = (side, edge) => Math.max(0, ...kids.filter(({ kid }) => kid[edge] === frame[edge]).map(({ pads }) => pads[side]));
    frame.pads = {
      left: pad + extra('left', 'a'),
      right: pad + extra('right', 'b'),
      top: pad + labelBand + extra('top', 'c'),
      bottom: pad + extra('bottom', 'd'),
    };
    return frame.pads;
  };
  frames.forEach(padsOf);
  return frames;
}

// 枠の名前と、それを横切る線との間隔。
const GROUP_LABEL_GAP = 6;

// 枠の名前は左上に置く。縦の線やラベルが名前の帯を横切る場合は、右へずらす。入りきらなければ左上のままにする。
function placeGroupLabel(box, edgeLayouts) {
  const { labelInset, labelSize, labelBand } = METRICS.group;
  const width = estimateWidth(box.label, labelSize, { bold: true });
  const top = box.labelY - labelBand / 2;
  const bottom = box.labelY + labelBand / 2;
  const gap = GROUP_LABEL_GAP;
  const blocked = [];
  for (const edge of edgeLayouts) {
    for (let i = 0; i + 1 < edge.points.length; i += 1) {
      const [x1, y1] = edge.points[i];
      const [x2, y2] = edge.points[i + 1];
      if (x1 === x2 && Math.max(y1, y2) > top && Math.min(y1, y2) < bottom) blocked.push([x1, x1]);
    }
    const label = edge.labelBox;
    if (label && label.y + label.height > top && label.y < bottom) blocked.push([label.x, label.x + label.width]);
  }
  blocked.sort((p, q) => p[0] - q[0]);
  const start = box.x + labelInset;
  let x = start;
  for (const [from, to] of blocked) {
    if (to < x - gap || from > x + width + gap) continue;
    x = to + gap;
  }
  return x + width <= box.x + box.width - labelInset ? x : start;
}

// 1つの軸（横または縦）を、通路 i ごとの3つの幅 L・B・R と、列 j ごとの2つの半マス H で表す。
// 並びは L0 B0 R0 H0 H1 L1 B1 R1 H2 H3 … Lc Bc Rc。通路の中心線は B の中央、列の中心線は2つの H の境目。
// L と R には枠の余白が入り、B にはレーンが入る。
function createAxis(count) {
  const slots = [];
  const index = { L: [], B: [], R: [], H: [] };
  for (let i = 0; i <= count; i += 1) {
    for (const kind of ['L', 'B', 'R']) {
      index[kind][i] = slots.length;
      slots.push({ kind, min: 0 });
    }
    if (i < count) {
      for (const t of [2 * i, 2 * i + 1]) {
        index.H[t] = slots.length;
        slots.push({ kind: 'H', min: 0 });
      }
    }
  }
  return { count, slots, index, inset: new Map(), constraints: [] };
}

const raiseMin = (axis, slot, value) => { axis.slots[slot].min = Math.max(axis.slots[slot].min, value); };

// 位置を「各スロットの幅の係数」と定数で表す。
function positionForm(axis, spec) {
  const coef = new Array(axis.slots.length).fill(0);
  const upTo = (slot) => { for (let s = 0; s < slot; s += 1) coef[s] = 1; };
  let constant = 0;
  const lineAt = (k) => {
    if (k % 2 === 0) {
      const i = k / 2;
      upTo(axis.index.B[i]);
      coef[axis.index.B[i]] = 0.5;
    } else {
      upTo(axis.index.H[k]);
    }
  };
  if (spec.type === 'line') {
    lineAt(spec.index);
  } else if (spec.boundary % 2 === 0) {
    const i = spec.boundary / 2;
    upTo(spec.dir > 0 ? axis.index.H[spec.boundary] : axis.index.L[i]);
  } else {
    lineAt(spec.boundary);
    constant = spec.dir * insetOf(axis, spec.boundary);
  }
  return { coef, constant };
}

function insetOf(axis, k) {
  return axis.inset.get(k) ?? METRICS.gutter.oddInset;
}

function addSpanConstraint(axis, fromSpec, toSpec, need, stretch) {
  const from = positionForm(axis, fromSpec);
  const to = positionForm(axis, toSpec);
  const coef = to.coef.map((value, s) => value - from.coef[s]);
  axis.constraints.push({ coef, need: need - (to.constant - from.constant), stretch });
}

function nodeSize(node) {
  const m = METRICS.node;
  const labelLine = m.iconSize + m.iconGap + estimateWidth(node.label, m.labelSize, { bold: true });
  const sublabel = node.sublabel ? estimateWidth(node.sublabel, m.sublabelSize) : 0;
  const tag = node.tag ? estimateWidth(node.tag, m.tagSize, { bold: true }) + 2 * m.tagPaddingX + 2 * m.tagInset : 0;
  return {
    width: Math.ceil(Math.max(m.minWidth, labelLine + 2 * m.paddingX, sublabel + 2 * m.paddingX, tag)),
    height: node.sublabel ? m.heightWithSublabel : m.height,
  };
}

// 札（tag）の範囲。部品の右上に、枠線に重ねて置く。
function tagBox(node) {
  const m = METRICS.node;
  const width = estimateWidth(node.tag, m.tagSize, { bold: true }) + 2 * m.tagPaddingX;
  return { x: node.x + node.width - m.tagInset - width, y: node.y - m.tagHeight / 2, width, height: m.tagHeight };
}

function labelWidth(text) {
  return estimateWidth(text, METRICS.edge.labelSize) + 2 * METRICS.edge.labelPaddingX;
}

// 寸法の制約を集める。奇数番の線と部品との間隔（inset）は制約の定数に入るので、最初にすべて決める。
function sizeAxes({ doc, grid, runsByEdge, labelRuns, labelAnchors, laneWidths, frames, x, y }) {
  const { labelHeight, labelMargin, laneGap, laneMargin } = METRICS.edge;
  const { base, outer, emptyTrack, oddInset } = METRICS.gutter;
  // lanes は、線の番号ごとのレーン全体の幅（ラベルの分を含む）。
  const axes = { x: { axis: x, lanes: laneWidths.v }, y: { axis: y, lanes: laneWidths.h } };
  const edges = doc.edges ?? [];

  // 列・行の中心線に接する部品（半マスずらし）との間隔。レーンと枠の余白が入るようにする。
  const padAt = { x: new Map(), y: new Map() };
  const notePad = (map, k, value) => { if (k % 2 === 1) map.set(k, Math.max(map.get(k) ?? 0, value)); };
  for (const frame of frames) {
    notePad(padAt.x, frame.a, frame.pads.left);
    notePad(padAt.x, frame.b, frame.pads.right);
    notePad(padAt.y, frame.c, frame.pads.top);
    notePad(padAt.y, frame.d, frame.pads.bottom);
  }
  for (const [name, { axis, lanes }] of Object.entries(axes)) {
    for (let k = 1; k < axis.count * 2; k += 2) {
      axis.inset.set(k, Math.max(oddInset, (lanes.get(k) ?? 0) / 2 + (padAt[name].get(k) ?? 0)));
    }
  }
  // 中心線をはさんで接する2つの部品の間にラベルが入るときは、間隔を広げる。
  edges.forEach((edge, i) => {
    const run = labelRuns[i];
    if (!run || run.start.type !== 'border' || run.end.type !== 'border' || run.start.boundary !== run.end.boundary) return;
    const k = run.start.boundary;
    if (k % 2 === 0) return;
    const axis = run.axis === 'h' ? x : y;
    const size = run.axis === 'h' ? labelWidth(edge.label) : labelHeight;
    axis.inset.set(k, Math.max(insetOf(axis, k), size / 2 + labelMargin));
  });

  // 通路と半マスの最小幅。
  for (const { axis, lanes } of Object.values(axes)) {
    for (let i = 0; i <= axis.count; i += 1) {
      const floor = i === 0 || i === axis.count ? outer : base;
      raiseMin(axis, axis.index.B[i], Math.max(floor, lanes.get(2 * i) ?? 0));
    }
    for (let t = 0; t < axis.count * 2; t += 1) raiseMin(axis, axis.index.H[t], emptyTrack / 2);
    for (let j = 0; j < axis.count; j += 1) {
      const half = (lanes.get(2 * j + 1) ?? 0) / 2;
      raiseMin(axis, axis.index.H[2 * j], half);
      raiseMin(axis, axis.index.H[2 * j + 1], half);
    }
  }

  // 枠の余白。通路側の縁は L・R に入れる（奇数番の線に接する縁は、上で間隔に含めた）。
  for (const frame of frames) {
    if (frame.a % 2 === 0) raiseMin(x, x.index.R[frame.a / 2], frame.pads.left);
    if (frame.b % 2 === 0) raiseMin(x, x.index.L[frame.b / 2], frame.pads.right);
    if (frame.c % 2 === 0) raiseMin(y, y.index.R[frame.c / 2], frame.pads.top);
    if (frame.d % 2 === 0) raiseMin(y, y.index.L[frame.d / 2], frame.pads.bottom);
    const { labelSize, labelInset } = METRICS.group;
    const nameWidth = estimateWidth(frame.group.label, labelSize, { bold: true });
    addSpanConstraint(x, border(frame.a, 1), border(frame.b, -1), nameWidth + 2 * labelInset - frame.pads.left - frame.pads.right, ['H', 'B']);
    // 枠の上辺を縦に横切る線があれば、いちばん右の線より右に、枠の名前が入るだけの幅を空ける（placeGroupLabel と対応）。
    const crossings = runsByEdge.flatMap((runs) => (runs ?? [])
      .filter((run) => run.axis === 'v' && run.line > frame.a && run.line < frame.b && lowOf(run) <= frame.c && highOf(run) > frame.c)
      .map((run) => run.line));
    if (crossings.length > 0) {
      const need = nameWidth + GROUP_LABEL_GAP + labelInset - frame.pads.right;
      addSpanConstraint(x, line(Math.max(...crossings)), border(frame.b, -1), need, ['H', 'B']);
    }
  }

  // 部品の大きさ。
  for (const box of grid.boxes) {
    const size = nodeSize(box.node);
    addSpanConstraint(x, border(box.a, 1), border(box.b, -1), size.width, ['H', 'B']);
    addSpanConstraint(y, border(box.c, 1), border(box.d, -1), size.height, ['H', 'B']);
  }

  // 部品の辺に出入りする線の端が、辺の中に収まるようにする（レーンでずれた分と、端の余白 portMargin を含める）。
  // ふつうの部品では行・列の幅で足りているが、半マスずらしの部品は接続点が通路の中心線に来るので、ここで広げる。
  const portMargin = laneGap / 2 + laneMargin;
  runsByEdge.forEach((runs, i) => {
    if (!runs) return;
    const ends = [[runs[0], grid.byId.get(edges[i].from)], [runs.at(-1), grid.byId.get(edges[i].to)]];
    for (const [run, box] of ends) {
      const [axis, low, high] = run.axis === 'h' ? [y, box.c, box.d] : [x, box.a, box.b];
      addSpanConstraint(axis, border(low, 1), line(run.line), portMargin - run.offset, ['H', 'B']);
      addSpanConstraint(axis, line(run.line), border(high, -1), portMargin + run.offset, ['H', 'B']);
    }
  });

  // 線のラベル。区間の方向には、ラベルを置く位置のまわりにラベルが入るだけの場所を空ける
  // （区間と直角の方向は、ラベルを置いたレーンを太くして空けている。placeLanes を参照）。
  // 線の中間に置く場合は、両側の線の間隔を、ラベルと、両側の線に並ぶレーン（ほかのラベルの分を含む）が入るだけ空ける。
  const reserve = (axis, lanes, k, size) => {
    if (!Number.isInteger(k)) {
      const [before, after] = labelSides(lanes, k);
      addSpanConstraint(axis, line(Math.floor(k)), line(Math.ceil(k)), before + size + after, ['B', 'H']);
    } else if (k % 2 === 0) {
      raiseMin(axis, axis.index.B[k / 2], size + 2 * labelMargin);
    } else {
      raiseMin(axis, axis.index.H[k - 1], size / 2 + labelMargin);
      raiseMin(axis, axis.index.H[k], size / 2 + labelMargin);
    }
  };
  edges.forEach((edge, i) => {
    const run = labelRuns[i];
    if (!run) return;
    if (run.axis === 'h') reserve(x, laneWidths.v, labelAnchors[i], labelWidth(edge.label));
    else reserve(y, laneWidths.h, labelAnchors[i], labelHeight);
  });
}

// 制約を、関わるスロットの少ないものから順に満たしていく。足りない分は、指定した種類のスロットに等しく配る。
function solve(axis) {
  const values = axis.slots.map((slot) => slot.min);
  const constraints = axis.constraints
    .map((constraint, position) => ({ ...constraint, position, span: constraint.coef.filter((c) => c > 0).length }))
    .sort((p, q) => p.span - q.span || p.position - q.position);
  for (const constraint of constraints) {
    const total = constraint.coef.reduce((sum, c, s) => sum + c * values[s], 0);
    if (total >= constraint.need) continue;
    let chosen = [];
    for (const kind of constraint.stretch) {
      chosen = constraint.coef.flatMap((c, s) => (c > 0 && axis.slots[s].kind === kind ? [s] : []));
      if (chosen.length > 0) break;
    }
    if (chosen.length === 0) chosen = constraint.coef.flatMap((c, s) => (c > 0 ? [s] : []));
    if (chosen.length === 0) continue;
    const weight = chosen.reduce((sum, s) => sum + constraint.coef[s], 0);
    const delta = (constraint.need - total) / weight;
    for (const s of chosen) values[s] += delta;
  }
  return values;
}

function evaluate(axis) {
  const values = solve(axis);
  return {
    total: values.reduce((sum, v) => sum + v, 0),
    at(spec) {
      const form = positionForm(axis, spec);
      return form.coef.reduce((sum, c, s) => sum + c * values[s], 0) + form.constant;
    },
  };
}

// ---- 5. 座標 ----------------------------------------------------------------

function edgePoints(runs, X, Y) {
  const across = (run) => (run.axis === 'v' ? X.at(line(run.line)) : Y.at(line(run.line))) + run.offset;
  const first = runs[0];
  const last = runs.at(-1);
  const points = [first.axis === 'v' ? [across(first), Y.at(first.start)] : [X.at(first.start), across(first)]];
  for (let i = 0; i + 1 < runs.length; i += 1) {
    const run = runs[i];
    const next = runs[i + 1];
    points.push(run.axis === 'v' ? [across(run), across(next)] : [across(next), across(run)]);
  }
  points.push(last.axis === 'v' ? [across(last), Y.at(last.end)] : [X.at(last.end), across(last)]);
  return points.map(([px, py]) => [round(px), round(py)]);
}

function round(value) {
  return Math.round(value * 2) / 2;
}

// ---- 優先度付きキュー ----------------------------------------------------------

class MinHeap {
  constructor() {
    this.items = [];
    this.sequence = 0;
  }

  get size() {
    return this.items.length;
  }

  push(cost, value) {
    const item = { cost, order: this.sequence, value };
    this.sequence += 1;
    const { items } = this;
    items.push(item);
    let i = items.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (!before(items[i], items[parent])) break;
      [items[i], items[parent]] = [items[parent], items[i]];
      i = parent;
    }
  }

  pop() {
    const { items } = this;
    const top = items[0];
    const last = items.pop();
    if (items.length > 0) {
      items[0] = last;
      let i = 0;
      for (;;) {
        const left = 2 * i + 1;
        const right = left + 1;
        let smallest = i;
        if (left < items.length && before(items[left], items[smallest])) smallest = left;
        if (right < items.length && before(items[right], items[smallest])) smallest = right;
        if (smallest === i) break;
        [items[i], items[smallest]] = [items[smallest], items[i]];
        i = smallest;
      }
    }
    return top;
  }
}

function before(a, b) {
  return a.cost < b.cost || (a.cost === b.cost && a.order < b.order);
}
