// architecture の文言（日英）：凡例の線と枠の種類の名前と、診断のメッセージ。診断の形は core/messages.mjs と同じ。
// 部品の種類の名前は、sequence と共通なので core/kinds.mjs にある。

import { formatPath, joinList } from '../../core/i18n.mjs';

// 凡例に出す、線の種類（primary・async・both）と枠の種類（boundary・zone）の名前。
export const styleNames = {
  ja: { primary: '主な経路', async: '非同期', both: '双方向', boundary: '境界', zone: '区域' },
  en: { primary: 'Main path', async: 'Async', both: 'Two-way', boundary: 'Boundary', zone: 'Zone' },
};

const paths = (list, lang) => joinList(list.map((path) => formatPath(path, lang)), lang);

// 列・行の範囲。a は { col, row, right, bottom } で、right・bottom は範囲の右端・下端（その列・行は含まない）。
// 整数の範囲は、含む列・行を「列 1〜4」のように書く（終わりの数字も含む）。半マスずらしを含む範囲は「col 0.5 以上 3 未満」と書く。
const range = (from, to, [name, key], lang) => {
  if (Number.isInteger(from) && Number.isInteger(to)) {
    const last = to - 1;
    if (lang === 'ja') return last === from ? `${name} ${from}` : `${name} ${from}〜${last}`;
    return last === from ? `${name} ${from}` : `${name}s ${from}–${last}`;
  }
  return lang === 'ja' ? `${key} ${from} 以上 ${to} 未満` : `${key} from ${from} up to (not including) ${to}`;
};
const area = (a, lang) => {
  const [cols, rows] = lang === 'ja' ? [['列', 'col'], ['行', 'row']] : [['column', 'col'], ['row', 'row']];
  return `${range(a.col, a.right, cols, lang)}${lang === 'ja' ? '・' : ', '}${range(a.row, a.bottom, rows, lang)}`;
};

// 線の呼び方（「a」→「b」の線）。
const edgeName = (e, lang) => (lang === 'ja' ? `「${e.from}」→「${e.to}」の線` : `the edge "${e.from}" → "${e.to}"`);

// ラベルと重なっているもの。
const overlapName = (item, lang) => {
  if (item.kind === 'node') return lang === 'ja' ? `部品「${item.id}」` : `node "${item.id}"`;
  if (item.kind === 'group') return lang === 'ja' ? `枠「${item.id}」の名前` : `the name of group "${item.id}"`;
  if (item.kind === 'label') return lang === 'ja' ? `${edgeName(item, 'ja')}のラベル` : `the label of ${edgeName(item, 'en')}`;
  return edgeName(item, lang);
};

export const architectureMessages = {
  'id/duplicate': {
    ja: {
      message: (d) => `ID「${d.id}」が${d.paths.length}か所で使われています（${paths(d.paths, 'ja')}）`,
      fixes: () => ['部品・枠・線を通して重複しないように、ID を変える'],
    },
    en: {
      message: (d) => `The ID "${d.id}" is used ${d.paths.length} times (${paths(d.paths, 'en')})`,
      fixes: () => ['Change the IDs so that each one is unique across nodes, groups, and edges'],
    },
  },
  'ref/unknown': {
    ja: {
      message: (d) => (d.isGroup
        ? `${formatPath(d.path, 'ja')} の「${d.value}」は枠の ID です。ここには部品の ID を書きます`
        : `${formatPath(d.path, 'ja')} の「${d.value}」という部品はありません`),
      fixes: (d) => {
        const members = d.members?.length ? `（${joinList(d.members, 'ja')}）` : '';
        if (d.isGroup && d.path.includes('/contains/')) {
          return [`枠「${d.value}」に入る部品${members}の ID を書く（枠の入れ子は、中の部品の包含関係から自動で決まる）`];
        }
        if (d.isGroup) return [`枠「${d.value}」の中にある部品${members}のどれかの ID を書く（線は部品同士をつなぐ）`];
        return [...(d.suggestion ? [`「${d.suggestion}」の書き間違いなら直す`] : []), `ID「${d.value}」の部品を nodes に追加する`];
      },
    },
    en: {
      message: (d) => (d.isGroup
        ? `"${d.value}" at ${formatPath(d.path, 'en')} is a group ID; a node ID is required here`
        : `There is no node with the ID "${d.value}" (${formatPath(d.path, 'en')})`),
      fixes: (d) => {
        const members = d.members?.length ? ` (${joinList(d.members, 'en')})` : '';
        if (d.isGroup && d.path.includes('/contains/')) {
          return [`List the IDs of the nodes inside group "${d.value}"${members} instead (nesting is inferred from which nodes each group contains)`];
        }
        if (d.isGroup) return [`Use the ID of one of the nodes inside group "${d.value}"${members} (edges connect nodes)`];
        return [...(d.suggestion ? [`If this is a typo for "${d.suggestion}", fix it`] : []), `Add a node with the ID "${d.value}" to nodes`];
      },
    },
  },
  'layout/out-of-range': {
    ja: {
      message: (d) => `部品「${d.id}」が格子の外にはみ出しています（col + colSpan = ${d.right}、row + rowSpan = ${d.bottom}。どちらも ${d.limit} 以下にする）`,
      fixes: (d) => [
        ...(d.right > d.limit ? [`col を ${d.limit - (d.right - d.col)} 以下にするか、colSpan を ${d.limit - d.col} 以下にする`] : []),
        ...(d.bottom > d.limit ? [`row を ${d.limit - (d.bottom - d.row)} 以下にするか、rowSpan を ${d.limit - d.row} 以下にする`] : []),
      ],
    },
    en: {
      message: (d) => `Node "${d.id}" extends outside the grid (col + colSpan = ${d.right}, row + rowSpan = ${d.bottom}; both must be ${d.limit} or less)`,
      fixes: (d) => [
        ...(d.right > d.limit ? [`Set col to ${d.limit - (d.right - d.col)} or less, or colSpan to ${d.limit - d.col} or less`] : []),
        ...(d.bottom > d.limit ? [`Set row to ${d.limit - (d.bottom - d.row)} or less, or rowSpan to ${d.limit - d.row} or less`] : []),
      ],
    },
  },
  'layout/overlap': {
    ja: {
      message: (d) => `部品「${d.first}」と「${d.second}」の範囲が重なっています（列 ${d.col}・行 ${d.row}）`,
      fixes: (d) => [
        d.suggestion
          ? `どちらかを空いている位置に移す（たとえば「${d.second}」を col ${d.suggestion.col}・row ${d.suggestion.row} に）`
          : 'どちらかの col か row を、空いている位置に変える',
        'colSpan・rowSpan を小さくする',
      ],
    },
    en: {
      message: (d) => `Nodes "${d.first}" and "${d.second}" overlap (at column ${d.col}, row ${d.row})`,
      fixes: (d) => [
        d.suggestion
          ? `Move one of them to a free place (for example, "${d.second}" to col ${d.suggestion.col}, row ${d.suggestion.row})`
          : 'Move one of them to a free col or row',
        'Reduce colSpan or rowSpan',
      ],
    },
  },
  'edge/self-loop': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線は、始点と終点が同じ部品「${d.id}」です`,
      fixes: () => ['from か to を別の部品にする', '不要なら線を消す'],
    },
    en: {
      message: (d) => `The edge at ${formatPath(d.path, 'en')} starts and ends at the same node "${d.id}"`,
      fixes: () => ['Point from or to at a different node', 'Remove the edge if it is not needed'],
    },
  },
  'edge/no-route': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線（「${d.from}」→「${d.to}」）の通り道が見つかりません`,
      fixes: () => ['fromSide・toSide の指定を外すか、別の辺にする', '周りの部品の位置を変えて、通り道を空ける'],
    },
    en: {
      message: (d) => `No route was found for the edge at ${formatPath(d.path, 'en')} ("${d.from}" → "${d.to}")`,
      fixes: () => ['Remove fromSide/toSide or choose another side', 'Move the surrounding nodes to open a path'],
    },
  },
  'edge/duplicate': {
    ja: {
      message: (d) => (d.both
        ? `「${d.from}」と「${d.to}」を結ぶ双方向の線が${d.paths.length}本あります`
        : `「${d.from}」から「${d.to}」への線が${d.paths.length}本あります`),
      fixes: () => ['1本にまとめ、説明は label に書く'],
    },
    en: {
      message: (d) => (d.both
        ? `There are ${d.paths.length} two-way edges between "${d.from}" and "${d.to}"`
        : `There are ${d.paths.length} edges from "${d.from}" to "${d.to}"`),
      fixes: () => ['Merge them into one edge and describe it with label'],
    },
  },
  'node/isolated': {
    ja: {
      message: (d) => `部品「${d.id}」はどの線ともつながっていません`,
      fixes: () => ['関係する部品との線を追加する', '図に不要なら消す'],
    },
    en: {
      message: (d) => `Node "${d.id}" is not connected to any edge`,
      fixes: () => ['Add an edge to a related node', 'Remove the node if the diagram does not need it'],
    },
  },
  'group/partial-membership': {
    ja: {
      message: (d) => `枠「${d.first}」と「${d.second}」の中身が一部だけ重なっています（両方に入っている部品：${joinList(d.shared, 'ja')}）`,
      fixes: (d) => [
        '入れ子にするなら、内側にしたい枠の部品をすべて、外側の枠の contains にも書く',
        `別々の枠にするなら、${joinList(d.shared, 'ja')} をどちらか一方の枠から外す`,
      ],
    },
    en: {
      message: (d) => `Groups "${d.first}" and "${d.second}" partially overlap (nodes in both: ${joinList(d.shared, 'en')})`,
      fixes: (d) => [
        "To nest them, also list every node of the inner group in the outer group's contains",
        `To keep them separate, remove ${joinList(d.shared, 'en')} from one of the groups`,
      ],
    },
  },
  'group/too-deep': {
    ja: {
      message: (d) => `枠の入れ子が ${d.limit} 段を超えています（${d.chain.join(' > ')}）`,
      fixes: () => ['境界として重要でない枠を消すか、外側の枠にまとめて、入れ子を減らす'],
    },
    en: {
      message: (d) => `Groups are nested more than ${d.limit} levels deep (${d.chain.join(' > ')})`,
      fixes: () => ['Reduce the nesting by removing a less important group or merging it into its outer group'],
    },
  },
  'size/too-many-nodes': {
    ja: {
      message: (d) => `部品が${d.count}個あります。${d.limit}個を超えると読みにくくなります`,
      fixes: () => ['主な経路との関係が薄い部品を省く', '図を2つに分ける'],
    },
    en: {
      message: (d) => `The diagram has ${d.count} nodes; more than ${d.limit} makes it hard to read`,
      fixes: () => ['Leave out nodes that are only loosely related to the main path', 'Split the diagram into two'],
    },
  },
  'group/encloses-outsider': {
    ja: {
      message: (d) => `枠「${d.group}」の範囲（${area(d.frame, 'ja')}）に、枠に入れていない部品「${d.node}」が入り込んでいます`,
      fixes: (d) => [
        ...d.groups.map((id) => `枠「${id}」を枠「${d.group}」の内側に入れ子にするなら、「${id}」の部品をすべて「${d.group}」の contains にも書く`),
        `「${d.node}」を枠に入れるなら、枠「${d.group}」の contains に追加する`,
        d.suggestion
          ? `入れないなら、「${d.node}」を枠の範囲の外に移す（近くでは col ${d.suggestion.col}・row ${d.suggestion.row} が空いている）`
          : `入れないなら、「${d.node}」を枠の範囲の外に移す`,
        '枠の中の部品を寄せて、枠の範囲を狭める（枠の範囲は、中の部品を囲む最小の長方形になる）',
      ],
    },
    en: {
      message: (d) => `Node "${d.node}" is not in group "${d.group}" but lies inside its area (${area(d.frame, 'en')})`,
      fixes: (d) => [
        ...d.groups.map((id) => `To nest group "${id}" inside group "${d.group}", also list every node of "${id}" in the contains of "${d.group}"`),
        `If "${d.node}" belongs to the group, add it to the contains of group "${d.group}"`,
        d.suggestion
          ? `Otherwise move "${d.node}" outside the group's area (col ${d.suggestion.col}, row ${d.suggestion.row} is free nearby)`
          : `Otherwise move "${d.node}" outside the group's area`,
        "Move the group's nodes closer together to shrink its area (a group is the smallest rectangle around its nodes)",
      ],
    },
  },
  'group/partial-overlap': {
    ja: {
      message: (d) => `枠「${d.first}」（${area(d.firstFrame, 'ja')}）と「${d.second}」（${area(d.secondFrame, 'ja')}）の範囲が、一部だけ重なっています`,
      fixes: () => [
        '2つの枠の部品を、列か行で分けて置く（枠の範囲は、中の部品を囲む最小の長方形になる）',
        '一方をもう一方の内側にするなら、内側の枠の部品をすべて、外側の枠の contains にも書く',
      ],
    },
    en: {
      message: (d) => `Groups "${d.first}" (${area(d.firstFrame, 'en')}) and "${d.second}" (${area(d.secondFrame, 'en')}) partially overlap`,
      fixes: () => [
        "Place the two groups' nodes in separate columns or rows (a group is the smallest rectangle around its nodes)",
        "To nest one inside the other, also list every node of the inner group in the outer group's contains",
      ],
    },
  },
  'edge/label-overlap': {
    ja: {
      message: (d) => `${edgeName(d, 'ja')}のラベル「${d.label}」が、${joinList(d.overlaps.map((item) => overlapName(item, 'ja')), 'ja')}と重なっています`,
      fixes: () => [
        'ラベルを短くする。両端の部品から分かる情報なら、ラベルを消す',
        '重なっている線の端の部品を別の列・行に移し、2本の線が同じ通路を並んで通らないようにする',
      ],
    },
    en: {
      message: (d) => `The label "${d.label}" of ${edgeName(d, 'en')} overlaps ${joinList(d.overlaps.map((item) => overlapName(item, 'en')), 'en')}`,
      fixes: () => [
        'Shorten the label, or remove it if the two nodes already make it clear',
        'Move an end node of the overlapping edge to another column or row so that the two edges do not run side by side',
      ],
    },
  },
  'edge/crossing': {
    ja: {
      message: (d) => `${edgeName(d.first, 'ja')}と${edgeName(d.second, 'ja')}が交差しています（${d.count}か所）`,
      fixes: (d) => [
        ...(d.suggestion ? [`たとえば${d.suggestion.swap
          ? `「${d.suggestion.swap[0]}」と「${d.suggestion.swap[1]}」の位置（col・row）を入れ替える`
          : `「${d.suggestion.node}」を col ${d.suggestion.col}・row ${d.suggestion.row} に移す`}と、この交差がなくなり、図全体の交差も減る`] : []),
        'どちらかの線の端の部品を、もう一方の線をまたがずにつながる位置に移す',
        '交差する線の端の部品同士の、列（または行）の並び順を入れ替える',
      ],
    },
    en: {
      message: (d) => `${edgeName(d.first, 'en').replace(/^t/, 'T')} crosses ${edgeName(d.second, 'en')} (${d.count} ${d.count === 1 ? 'time' : 'times'})`,
      fixes: (d) => [
        ...(d.suggestion ? [`For example, ${d.suggestion.swap
          ? `swapping the positions (col, row) of "${d.suggestion.swap[0]}" and "${d.suggestion.swap[1]}"`
          : `moving "${d.suggestion.node}" to col ${d.suggestion.col}, row ${d.suggestion.row}`} removes this crossing and reduces crossings overall`] : []),
        'Move an end node of one edge to a place where it can connect without crossing the other edge',
        'Swap the order (column or row) of the end nodes of the crossing edges',
      ],
    },
  },
  'size/too-wide': {
    ja: {
      message: (d) => `図の幅が ${d.width}px あります（${d.columns}列）。指定の ${d.limit}px を超えています`,
      fixes: () => [
        '列を減らす。主な経路から外れる部品を、主な経路の上下の行に移すか、主な経路を途中から下の行に折り返す',
        '部品のない列を詰める',
        '長い名前・補足・線のラベルを短くする',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.width}px wide (${d.columns} columns), which exceeds the requested ${d.limit}px`,
      fixes: () => [
        'Use fewer columns: move nodes that are off the main path to the rows above or below it, or wrap the main path onto the next row',
        'Remove empty columns',
        'Shorten long labels, sublabels, and edge labels',
      ],
    },
  },
  'size/too-tall': {
    ja: {
      message: (d) => `図の高さが ${d.height}px あります（${d.rows}行）。指定の ${d.limit}px を超えています`,
      fixes: () => [
        '行を減らす。補助的な部品を、つながる部品の左右の空いている列に移す',
        '部品のない行を詰める',
        '補足（sublabel）を省くと、その行が低くなる',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.height}px tall (${d.rows} rows), which exceeds the requested ${d.limit}px`,
      fixes: () => [
        'Use fewer rows: move supporting nodes to free columns beside the nodes they connect to',
        'Remove empty rows',
        'Leave out sublabels to make their rows lower',
      ],
    },
  },
};
