// architecture の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは architectureStyles() の CSS で行う（CSS の指定は属性より優先される）。

import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY, estimateWidth } from '../../core/text.mjs';
import { METRICS } from './layout.mjs';

export const DRAW = {
  node: { radius: 6, strokeWidth: 1.25, sublabelOffset: 18, iconStroke: 1.6 },
  edge: {
    width: 1.5, primaryWidth: 2.5, dash: '6 4', corner: 6, hop: 4.5, minHop: 2.5, labelRadius: 4,
    arrow: { length: 9, width: 8 }, primaryArrow: { length: 11, width: 10 },
  },
  group: { radius: 10, strokeWidth: 1.25, dash: '5 4' },
};

// 部品の種類ごとの色：[塗り, 枠線, 記号の色]。作り方は仕様の「部品の色と記号」を参照。
export const KIND_COLORS = {
  person: { light: ['#fef0fc', '#b576af', '#914a8c'], dark: ['#322130', '#a26a9d', '#e6a4e0'] },
  client: { light: ['#f5f4fe', '#8e83ce', '#6959ae'], dark: ['#272538', '#7f75b8', '#bcb2ff'] },
  service: { light: ['#eef6fe', '#5894d0', '#1f6cb0'], dark: ['#1a2938', '#4f84ba', '#89c3fe'] },
  datastore: { light: ['#ebfaed', '#5aa26b', '#1d7d3e'], dark: ['#1b2d1e', '#519160', '#89d298'] },
  queue: { light: ['#fef3e7', '#ba823c', '#915b02'], dark: ['#332514', '#a67537', '#ebb16c'] },
  infra: { light: ['#e5fafb', '#04a3aa', '#02787d'], dark: ['#0f2d2e', '#0d9298', '#56d3da'] },
  security: { light: ['#fff2f0', '#ca736d', '#a74541'], dark: ['#37211f', '#b46762', '#fda19a'] },
  external: { light: ['#f3f5f8', '#8b9095', '#646970'], dark: ['#26282a', '#7c8186', '#b9bec6'] },
};

// 図全体の色。tagText は札の文字、edgeStrong は主な経路の線、group は枠の線と名前以外の部分。
export const BASE_COLORS = {
  light: {
    page: '#ffffff', text: '#1b1f27', muted: '#525a66', tagText: '#ffffff',
    edge: '#5b6472', edgeStrong: '#2b313b', group: '#8a93a0', groupFill: 'rgba(120, 130, 145, 0.05)',
  },
  dark: {
    page: '#14171c', text: '#eceef2', muted: '#a8afba', tagText: '#14171c',
    edge: '#8d96a3', edgeStrong: '#d3d8df', group: '#6b7480', groupFill: 'rgba(160, 170, 185, 0.05)',
  },
};

// ---- 記号 --------------------------------------------------------------------

// 歯が8つの歯車の外形。
function gearPath() {
  const teeth = 8;
  const points = [];
  for (let i = 0; i < teeth; i += 1) {
    for (const [t, r] of [[0.08, 4.9], [0.22, 6.6], [0.5, 6.6], [0.64, 4.9]]) {
      const a = ((i + t) / teeth) * Math.PI * 2;
      points.push(`${n(8 + r * Math.cos(a))} ${n(8 + r * Math.sin(a))}`);
    }
  }
  return `M${points.join('L')}Z`;
}

// 部品の種類ごとの記号。16×16 の座標に、塗りのない線で描く。
const ICONS = {
  person: [
    ['circle', { cx: 8, cy: 5, r: 2.8 }],
    ['path', { d: 'M2.5 14.5c0-3.2 2.5-5.3 5.5-5.3s5.5 2.1 5.5 5.3' }],
  ],
  client: [
    ['rect', { x: 1.5, y: 2.5, width: 13, height: 11, rx: 1.5 }],
    ['path', { d: 'M1.5 6h13M4 4.25h0.01M6 4.25h0.01' }],
  ],
  service: [
    ['path', { d: gearPath() }],
    ['circle', { cx: 8, cy: 8, r: 2 }],
  ],
  datastore: [
    ['ellipse', { cx: 8, cy: 3.5, rx: 5.5, ry: 2 }],
    ['path', { d: 'M2.5 3.5v9c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2v-9M2.5 8c0 1.1 2.5 2 5.5 2s5.5-.9 5.5-2' }],
  ],
  queue: [
    ['rect', { x: 1, y: 3.5, width: 3.5, height: 9, rx: 0.8 }],
    ['rect', { x: 6, y: 3.5, width: 3.5, height: 9, rx: 0.8 }],
    ['path', { d: 'M11 8h4M13.2 6.2L15 8l-1.8 1.8' }],
  ],
  infra: [
    ['rect', { x: 5.5, y: 1.5, width: 5, height: 4, rx: 0.8 }],
    ['rect', { x: 1.5, y: 10.5, width: 5, height: 4, rx: 0.8 }],
    ['rect', { x: 9.5, y: 10.5, width: 5, height: 4, rx: 0.8 }],
    ['path', { d: 'M8 5.5v2.5M4 10.5V8h8v2.5' }],
  ],
  security: [
    ['path', { d: 'M8 1.5l5.5 2v4.2c0 3.3-2.3 5.6-5.5 6.8-3.2-1.2-5.5-3.5-5.5-6.8V3.5z' }],
    ['path', { d: 'M5.5 8l1.8 1.8 3.2-3.3' }],
  ],
  external: [
    ['path', { d: 'M9.5 1.5h5v5M14.5 1.5L7.5 8.5' }],
    ['path', { d: 'M12.5 9.5v4a1 1 0 0 1-1 1h-9a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1h4' }],
  ],
};

export const KINDS = Object.keys(ICONS);

/** 種類の記号。左上を (x, y) にして、size の大きさで描く。凡例などでも使う。 */
export function iconElement(kind, { x = 0, y = 0, size = METRICS.node.iconSize } = {}) {
  return el('g', {
    class: 'lt-icon',
    transform: `translate(${n(x)} ${n(y)}) scale(${n(size / 16)})`,
    fill: 'none',
    stroke: KIND_COLORS[kind].light[2],
    'stroke-width': DRAW.node.iconStroke,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  }, ICONS[kind].map(([tag, attrs]) => el(tag, attrs)));
}

// ---- 図 ----------------------------------------------------------------------

/** 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。 */
export function renderArchitecture(layout, doc) {
  const base = BASE_COLORS.light;
  const hops = findHops(layout.edges);
  // 主な経路の線を後から描き、ほかの線より上に見えるようにする。
  const edgeOrder = layout.edges.map((edge, i) => i).sort((p, q) => Number(layout.edges[p].primary) - Number(layout.edges[q].primary) || p - q);
  return el('svg', {
    class: 'lt-diagram lt-architecture',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    el('g', { class: 'lt-groups' }, [...layout.groups].sort((p, q) => p.depth - q.depth).map((group) => renderGroup(group, base))),
    el('g', { class: 'lt-edges' }, edgeOrder.map((i) => renderEdge(layout.edges[i], hops[i], base))),
    el('g', { class: 'lt-edge-labels' }, edgeOrder.filter((i) => layout.edges[i].labelBox).map((i) => renderEdgeLabel(layout.edges[i], layout.groups, base))),
    el('g', { class: 'lt-nodes' }, layout.nodes.map((node) => renderNode(node, base))),
  ]);
}

function renderGroup(group, base) {
  const { labelSize } = METRICS.group;
  const zone = group.style === 'zone';
  return el('g', { class: `lt-group lt-${group.style}`, 'data-id': group.id }, [
    el('rect', {
      class: 'lt-group-box',
      x: group.x, y: group.y, width: group.width, height: group.height, rx: DRAW.group.radius,
      fill: zone ? 'none' : base.groupFill,
      stroke: base.group,
      'stroke-width': DRAW.group.strokeWidth,
      'stroke-dasharray': zone ? DRAW.group.dash : null,
    }),
    el('text', {
      class: 'lt-group-label',
      x: group.labelX, y: group.labelY, 'font-size': labelSize, 'font-weight': 700, 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': group.labelBox.width,
    }, group.label),
  ]);
}

function renderNode(node, base) {
  const m = METRICS.node;
  const [fill, border, accent] = KIND_COLORS[node.kind].light;
  const cx = node.x + node.width / 2;
  const cy = node.y + node.height / 2;
  const labelWidth = estimateWidth(node.label, m.labelSize, { bold: true });
  // 記号と名前をひとまとまりとして、左右の中央に置く。
  const left = cx - (m.iconSize + m.iconGap + labelWidth) / 2;
  const titleY = node.sublabel ? cy - DRAW.node.sublabelOffset / 2 : cy;
  return el('g', { class: `lt-node lt-kind-${node.kind}`, 'data-id': node.id }, [
    el('rect', {
      class: 'lt-node-box',
      x: node.x, y: node.y, width: node.width, height: node.height, rx: DRAW.node.radius,
      fill, stroke: border, 'stroke-width': DRAW.node.strokeWidth,
    }),
    iconElement(node.kind, { x: left, y: titleY - m.iconSize / 2 }),
    el('text', {
      class: 'lt-node-label',
      x: left + m.iconSize + m.iconGap, y: titleY, 'font-size': m.labelSize, 'font-weight': 700, 'dominant-baseline': 'central',
      fill: base.text,
      'data-width': labelWidth,
    }, node.label),
    node.sublabel ? el('text', {
      class: 'lt-node-sublabel',
      x: cx, y: titleY + DRAW.node.sublabelOffset, 'font-size': m.sublabelSize, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': estimateWidth(node.sublabel, m.sublabelSize),
    }, node.sublabel) : null,
    node.tag ? renderTag(node, accent, base) : null,
  ]);
}

// 札は部品の右上に、枠線に重ねて置く（範囲は配置の計算で決めた tagBox）。
function renderTag(node, accent, base) {
  const m = METRICS.node;
  const box = node.tagBox;
  return el('g', { class: 'lt-tag' }, [
    el('rect', { x: box.x, y: box.y, width: box.width, height: box.height, rx: box.height / 2, fill: accent }),
    el('text', {
      x: box.x + box.width / 2, y: box.y + box.height / 2, 'font-size': m.tagSize, 'font-weight': 700, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.tagText,
      'data-width': estimateWidth(node.tag, m.tagSize, { bold: true }),
    }, node.tag),
  ]);
}

function renderEdge(edge, hops, base) {
  const e = DRAW.edge;
  const width = edge.primary ? e.primaryWidth : e.width;
  const arrow = edge.primary ? e.primaryArrow : e.arrow;
  const color = edge.primary ? base.edgeStrong : base.edge;
  // 線の端を矢じりの内側まで下げ、太い線の角が矢じりの先からはみ出さないようにする。
  const inset = (width * arrow.length) / arrow.width + 0.5;
  const points = edge.points.map(([x, y]) => [x, y]);
  pullBack(points.at(-1), points.at(-2), inset);
  if (edge.both) pullBack(points[0], points[1], inset);
  const classes = ['lt-edge', edge.primary ? 'lt-primary' : null, edge.async ? 'lt-async' : null].filter(Boolean).join(' ');
  return el('g', { class: classes, 'data-from': edge.from, 'data-to': edge.to }, [
    el('path', {
      class: 'lt-edge-line',
      d: edgePath(points, hops),
      fill: 'none',
      stroke: color,
      'stroke-width': width,
      'stroke-dasharray': edge.async ? e.dash : null,
    }),
    arrowHead(edge.points.at(-2), edge.points.at(-1), arrow, color),
    edge.both ? arrowHead(edge.points[1], edge.points[0], arrow, color) : null,
  ]);
}

// 端の点 end を、隣の点 next の方へ distance だけ動かす。
function pullBack(end, next, distance) {
  end[0] += Math.sign(next[0] - end[0]) * distance;
  end[1] += Math.sign(next[1] - end[1]) * distance;
}

// 区間 from→to の先に付ける矢じり。
function arrowHead(from, to, { length, width }, color) {
  const ux = Math.sign(to[0] - from[0]);
  const uy = Math.sign(to[1] - from[1]);
  const bx = to[0] - ux * length;
  const by = to[1] - uy * length;
  const px = (-uy * width) / 2;
  const py = (ux * width) / 2;
  return el('path', {
    class: 'lt-arrow',
    d: `M${n(to[0])} ${n(to[1])}L${n(bx + px)} ${n(by + py)}L${n(bx - px)} ${n(by - py)}Z`,
    fill: color,
  });
}

// ラベルの背景は、まわりと同じ色にする。画面の背景の上に、ラベルを囲む枠（boundary）の数だけ枠の塗りを重ねる。
function renderEdgeLabel(edge, groups, base) {
  const box = edge.labelBox;
  const size = METRICS.edge.labelSize;
  const cx = box.x + box.width / 2;
  const cy = box.y + box.height / 2;
  const tints = groups.filter((g) => g.style !== 'zone' && cx > g.x && cx < g.x + g.width && cy > g.y && cy < g.y + g.height).length;
  const background = (cls, fill) => el('rect', { class: cls, x: box.x, y: box.y, width: box.width, height: box.height, rx: DRAW.edge.labelRadius, fill });
  return el('g', { class: 'lt-edge-label', 'data-from': edge.from, 'data-to': edge.to }, [
    background('lt-edge-label-bg', base.page),
    Array.from({ length: tints }, () => background('lt-edge-label-tint', base.groupFill)),
    el('text', {
      x: box.x + box.width / 2, y: box.y + box.height / 2, 'font-size': size, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': estimateWidth(edge.label, size),
    }, edge.label),
  ]);
}

// ---- 線の形 --------------------------------------------------------------------

/**
 * 線またぎの位置。線ごと・区間ごとに、その横の区間がほかの線の縦の区間を横切る x 座標を返す。
 * 両方の区間の内側で交わるものだけを数える（端が触れるだけの枝分かれ・合流は含めない）。
 */
export function findHops(edges) {
  const segments = edges.map((edge) => edge.points.slice(1).map((point, i) => [edge.points[i], point]));
  return edges.map((edge, i) => segments[i].map(([a, b]) => {
    if (a[1] !== b[1]) return [];
    const [x1, x2] = [Math.min(a[0], b[0]), Math.max(a[0], b[0])];
    const xs = new Set();
    segments.forEach((others, j) => {
      if (j === i) return;
      for (const [c, d] of others) {
        if (c[0] !== d[0]) continue;
        const [y1, y2] = [Math.min(c[1], d[1]), Math.max(c[1], d[1])];
        if (c[0] > x1 && c[0] < x2 && a[1] > y1 && a[1] < y2) xs.add(c[0]);
      }
    });
    return [...xs];
  }));
}

/**
 * 折れ線の path。曲がり角は半径 corner の円弧で丸め、横の区間の hops の位置に上向きのアーチを入れる。
 * 角の半径は、前後の区間の短いほうの半分までにする。アーチを角より優先し、アーチが入らない角は半径を小さくする。
 */
export function edgePath(points, hops = [], { corner = DRAW.edge.corner, hop = DRAW.edge.hop, minHop = DRAW.edge.minHop } = {}) {
  const count = points.length;
  const lengths = points.slice(1).map(([x, y], i) => Math.abs(x - points[i][0]) + Math.abs(y - points[i][1]));
  // 区間ごとのアーチ：区間の始点からの距離 t と半径 r。隣のアーチや区間の端とは重ならない大きさにする。
  const arches = lengths.map((length, i) => {
    const [ax] = points[i];
    const ux = Math.sign(points[i + 1][0] - ax);
    const ts = (hops[i] ?? []).map((x) => (x - ax) * ux).sort((p, q) => p - q);
    return ts
      .map((t, j) => {
        const before = j > 0 ? (t - ts[j - 1]) / 2 : t;
        const after = j + 1 < ts.length ? (ts[j + 1] - t) / 2 : length - t;
        return { t, r: Math.min(hop, before - 0.5, after - 0.5) };
      })
      .filter((arch) => arch.r >= minHop);
  });
  const radii = points.map((point, i) => {
    if (i === 0 || i === count - 1) return 0;
    const last = arches[i - 1].at(-1);
    const first = arches[i][0];
    const roomBefore = last ? lengths[i - 1] - last.t - last.r - 0.5 : Infinity;
    const roomAfter = first ? first.t - first.r - 0.5 : Infinity;
    return Math.max(0, Math.min(corner, lengths[i - 1] / 2, lengths[i] / 2, roomBefore, roomAfter));
  });

  let d = `M${n(points[0][0])} ${n(points[0][1])}`;
  let pen = points[0];
  // 直線で (x, y) まで引く。すでにその位置にいれば何もしない。
  const lineTo = (x, y) => {
    if (n(x) !== n(pen[0]) || n(y) !== n(pen[1])) d += `L${n(x)} ${n(y)}`;
    pen = [x, y];
  };
  const arcTo = (r, sweep, x, y) => {
    d += `A${n(r)} ${n(r)} 0 0 ${sweep} ${n(x)} ${n(y)}`;
    pen = [x, y];
  };
  for (let i = 0; i + 1 < count; i += 1) {
    const [ax, ay] = points[i];
    const [bx, by] = points[i + 1];
    const ux = Math.sign(bx - ax);
    const uy = Math.sign(by - ay);
    for (const { t, r } of arches[i]) {
      lineTo(ax + ux * (t - r), ay);
      arcTo(r, ux > 0 ? 1 : 0, ax + ux * (t + r), ay);
    }
    const r = radii[i + 1];
    if (i + 2 < count && r > 0) {
      const vx = Math.sign(points[i + 2][0] - bx);
      const vy = Math.sign(points[i + 2][1] - by);
      lineTo(bx - ux * r, by - uy * r);
      arcTo(r, ux * vy - uy * vx > 0 ? 1 : 0, bx + vx * r, by + vy * r);
    } else {
      lineTo(bx, by);
    }
  }
  return d;
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS。ライトの値を既定にし、祖先の要素が dark（既定は data-theme="dark"）に
 * 当てはまるときはダークの値を使う。部品の種類の変数（--lt-fill・--lt-border・--lt-accent）は
 * .lt-kind-<種類> を付けた要素ならどこでも使えるので、凡例や説明カードにも使う。
 */
export function architectureStyles({ dark = '[data-theme="dark"]' } = {}) {
  const baseVars = (c) => `--lt-page:${c.page};--lt-text:${c.text};--lt-muted:${c.muted};--lt-tag-text:${c.tagText};`
    + `--lt-edge:${c.edge};--lt-edge-strong:${c.edgeStrong};--lt-group:${c.group};--lt-group-fill:${c.groupFill}`;
  const kindVars = ([fill, border, accent]) => `--lt-fill:${fill};--lt-border:${border};--lt-accent:${accent}`;
  return [
    `.lt-diagram{${baseVars(BASE_COLORS.light)}}`,
    `${dark} .lt-diagram{${baseVars(BASE_COLORS.dark)}}`,
    ...KINDS.map((kind) => `.lt-kind-${kind}{${kindVars(KIND_COLORS[kind].light)}}`),
    ...KINDS.map((kind) => `${dark} .lt-kind-${kind}{${kindVars(KIND_COLORS[kind].dark)}}`),
    '.lt-node-box{fill:var(--lt-fill);stroke:var(--lt-border)}',
    '.lt-icon{stroke:var(--lt-accent)}',
    '.lt-node-label{fill:var(--lt-text)}',
    '.lt-node-sublabel,.lt-group-label,.lt-edge-label text{fill:var(--lt-muted)}',
    '.lt-tag rect{fill:var(--lt-accent)}',
    '.lt-tag text{fill:var(--lt-tag-text)}',
    '.lt-edge-line{stroke:var(--lt-edge)}',
    '.lt-arrow{fill:var(--lt-edge)}',
    '.lt-primary .lt-edge-line{stroke:var(--lt-edge-strong)}',
    '.lt-primary .lt-arrow{fill:var(--lt-edge-strong)}',
    '.lt-edge-label-bg{fill:var(--lt-page)}',
    '.lt-edge-label-tint{fill:var(--lt-group-fill)}',
    '.lt-group-box{fill:var(--lt-group-fill);stroke:var(--lt-group)}',
    '.lt-zone .lt-group-box{fill:none}',
  ].join('\n');
}
