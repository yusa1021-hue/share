// architecture の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/architecture.md の「3. 描画のしかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは core/draw.mjs の diagramStyles() と architectureStyles() の CSS で行う（CSS の指定は属性より優先される）。
// 部品の箱・鏃・線の角の丸めは、sequence と共通なので core/ にある（決定記録 No.72）。

import { BASE_COLORS, EDGE_DRAW, SAMPLE, edgeElement, edgeLabelElement, findHops, lineSample, sampleSvg } from '../../core/draw.mjs';
import { NODE_DRAW, nodeElement } from '../../core/node.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY, estimateWidth } from '../../core/text.mjs';
import { METRICS } from './layout.mjs';

// 描き方。部品の箱とふつうの線は core/ と同じ値を使い、主な経路（太い線）と枠の値だけをここで決める。
export const DRAW = {
  node: NODE_DRAW,
  edge: EDGE_DRAW, // 線の描き方は core/draw.mjs と共通（決定記録 No.87）
  group: { radius: 10, strokeWidth: 1.25, dash: '5 4' },
};

// ---- 凡例の見本 ------------------------------------------------------------------

export const LEGEND_STYLES = ['primary', 'async', 'both', 'boundary', 'zone'];

/**
 * 凡例に出す、線の種類（primary・async・both）か枠の種類（boundary・zone）の見本。
 * 図と同じクラスを付けた小さな SVG で、色はテーマの CSS（diagramStyles・architectureStyles）で決まる。
 */
export function styleSample(style) {
  const base = BASE_COLORS.light;
  if (style === 'boundary' || style === 'zone') {
    const zone = style === 'zone';
    return sampleSvg(el('g', { class: `lt-group lt-${style}` }, [el('rect', {
      class: 'lt-group-box', x: 2, y: 2.5, width: SAMPLE.width - 4, height: SAMPLE.height - 5, rx: 4,
      fill: zone ? 'none' : base.groupFill, stroke: base.group, 'stroke-width': DRAW.group.strokeWidth,
      'stroke-dasharray': zone ? '4 3' : null,
    })]));
  }
  const primary = style === 'primary';
  return sampleSvg(lineSample({
    classes: [primary ? 'lt-primary' : null, style === 'async' ? 'lt-async' : null],
    width: primary ? DRAW.edge.primaryWidth : DRAW.edge.width,
    color: primary ? base.edgeStrong : base.edge,
    dash: style === 'async' ? '4 3' : null,
    arrow: { length: 8.5, width: primary ? 9 : 8 },
    both: style === 'both',
  }));
}

// ---- 図 ----------------------------------------------------------------------

/**
 * 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。
 * つながりの強調（viewer/highlight.mjs）のため、部品には data-node（部品の ID）を、線とそのラベルには
 * data-edge（edges の中の番号）・data-from・data-to を付ける。
 */
export function renderArchitecture(layout, doc) {
  const base = BASE_COLORS.light;
  const hops = findHops(layout.edges);
  // 主な経路の線を後から描き、ほかの線より上に見えるようにする。
  const edgeOrder = layout.edges.map((edge, i) => i).sort((p, q) => Number(layout.edges[p].primary) - Number(layout.edges[q].primary) || p - q);
  return el('svg', {
    class: 'lt-diagram lt-architecture',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    el('g', { class: 'lt-groups' }, [...layout.groups].sort((p, q) => p.depth - q.depth).map((group) => renderGroup(group, base))),
    el('g', { class: 'lt-edges' }, edgeOrder.map((i) => edgeElement(layout.edges[i], i, hops[i], base))),
    el('g', { class: 'lt-edge-labels' }, edgeOrder.filter((i) => layout.edges[i].labelBox).map((i) => renderEdgeLabel(layout.edges[i], i, layout.groups, base))),
    el('g', { class: 'lt-nodes' }, layout.nodes.map(renderNode)),
  ]);
}

function renderGroup(group, base) {
  const { labelSize } = METRICS.group;
  const zone = group.style === 'zone';
  return el('g', { class: `lt-group lt-${group.style}`, 'data-id': group.id }, [
    el('rect', {
      class: 'lt-group-box',
      x: group.x, y: group.y, width: group.width, height: group.height, rx: DRAW.group.radius,
      fill: zone ? 'none' : base.groupFill,
      stroke: base.group,
      'stroke-width': DRAW.group.strokeWidth,
      'stroke-dasharray': zone ? DRAW.group.dash : null,
    }),
    el('text', {
      class: 'lt-group-label',
      x: group.labelX, y: group.labelY, 'font-size': labelSize, 'font-weight': 700, 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': group.labelBox.width,
    }, group.label),
  ]);
}

function renderNode(node) {
  return nodeElement(node, { 'data-id': node.id, 'data-node': node.id });
}

// ラベルを囲む枠（boundary）の数を数えて、ラベルの背景に枠の塗りを重ねる。
function renderEdgeLabel(edge, index, groups, base) {
  const box = edge.labelBox;
  const [cx, cy] = [box.x + box.width / 2, box.y + box.height / 2];
  const tints = groups.filter((g) => g.style !== 'zone' && cx > g.x && cx < g.x + g.width && cy > g.y && cy < g.y + g.height).length;
  return edgeLabelElement(edge, index, base, METRICS.edge.labelSize, tints);
}

// ---- 線の形 --------------------------------------------------------------------

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、architecture だけのもの（主な経路・枠・枠の中のラベルの背景）。
 * 図の色の変数と、部品・線に共通の部分は core/draw.mjs の diagramStyles() で決める。
 */
export function architectureStyles() {
  return [
    '.lt-group-label{fill:var(--lt-muted)}',
    '.lt-primary .lt-edge-line{stroke:var(--lt-edge-strong)}',
    '.lt-primary .lt-arrow{fill:var(--lt-edge-strong)}',
    '.lt-edge-label-tint{fill:var(--lt-group-fill)}',
    '.lt-group-box{fill:var(--lt-group-fill);stroke:var(--lt-group)}',
    '.lt-zone .lt-group-box{fill:none}',
  ].join('\n');
}
