// dataflow のチェック。仕様：docs/latticery/types/dataflow.md の「4. チェック」
// checkDataflow：構造のチェック。スキーマ検証を通った図に対して、配置を計算しなくても分かる問題を調べる。
// inspectDataflow：見た目のチェック。配置の計算の結果（layout.mjs の layoutDataflow が返す layout）を使う。
// ラベルの重なりと線の交差は、architecture・workflow と同じ共通のチェック（core/inspect.mjs）を使う。

import { duplicateIds, longTexts, oversize } from '../../core/checks.mjs';
import { closest, error, synonymIndex, warning } from '../../core/diagnostics.mjs';
import { inspectDiagram } from '../../core/inspect.mjs';
import { KIND_SYNONYMS } from '../../core/kinds.mjs';
import { edgeTarget } from '../../core/route.mjs';
import { isSibling, stageColumns } from './layout.mjs';

export const ROW_LIMIT = 10; // row の範囲（row から1行分）は、この値以下に収める
export const COL_LIMIT = 4; // 段の中の列（col）の数
export const NODE_COUNT_GUIDELINE = 20;

// 使えない値から、意味の近い使える値への対応（schema/invalid の直し方の候補に使う）。部品の種類は core/kinds.mjs の語を使う。
export const VALUE_SYNONYMS = synonymIndex({ ...KIND_SYNONYMS });

// 表示幅の目安（半角1・全角2で数える）。
const TEXT_GUIDELINES = {
  stageLabel: 16,
  label: 24,
  sublabel: 32,
  tag: 16,
  edgeLabel: 20,
};

export function checkDataflow(doc) {
  const parts = { stages: doc.stages, nodes: doc.nodes, edges: doc.edges };
  return [
    ...checkIds(parts),
    ...checkReferences(parts),
    ...checkStages(parts),
    ...checkPlacement(parts),
    ...checkEdges(parts),
    ...checkTextLength(parts),
    ...checkNodeCount(parts.nodes),
  ];
}

function checkIds({ stages, nodes, edges }) {
  return duplicateIds([
    ...stages.map((stage, i) => ({ id: stage.id, path: `/stages/${i}/id` })),
    ...nodes.map((node, i) => ({ id: node.id, path: `/nodes/${i}/id` })),
    ...edges.map((edge, i) => ({ id: edge.id, path: `/edges/${i}/id` })),
  ]);
}

function checkReferences({ stages, nodes, edges }) {
  const stageIds = stages.map((stage) => stage.id);
  const stageSet = new Set(stageIds);
  const nodeIds = nodes.map((node) => node.id);
  const nodeSet = new Set(nodeIds);
  const problems = [];
  const verify = (value, path, target, ids, set, kind) => {
    if (set.has(value)) return;
    const detail = { path, value, kind };
    const suggestion = closest(value, ids);
    if (suggestion) detail.suggestion = suggestion;
    // 部品の stage に部品の ID を書いた、線の端に段の ID を書いた、という取り違えも知らせる。
    if (kind === 'stage' && nodeSet.has(value)) detail.isNode = true;
    if (kind === 'node' && stageSet.has(value)) detail.isStage = true;
    problems.push(error('ref/unknown', { target, detail }));
  };
  nodes.forEach((node, i) => verify(node.stage, `/nodes/${i}/stage`, [node.id], stageIds, stageSet, 'stage'));
  edges.forEach((edge, i) => {
    verify(edge.from, `/edges/${i}/from`, edgeTarget(edge), nodeIds, nodeSet, 'node');
    verify(edge.to, `/edges/${i}/to`, edgeTarget(edge), nodeIds, nodeSet, 'node');
  });
  return problems;
}

// 段の中身：部品のない段（stage/empty。エラー）と、段の中の部品のない列（stage/empty-col。警告）。
function checkStages({ stages, nodes }) {
  const problems = [];
  stages.forEach((stage, i) => {
    const members = nodes.filter((node) => node.stage === stage.id);
    if (members.length === 0) {
      // 部品を移す候補として、隣の段を示す。
      const neighbors = [stages[i - 1], stages[i + 1]].filter(Boolean).map((other) => other.id);
      problems.push(error('stage/empty', { target: [stage.id], detail: { path: `/stages/${i}`, id: stage.id, label: stage.label, neighbors } }));
      return;
    }
    const used = new Set(members.map((node) => node.col ?? 0));
    const last = Math.max(...used);
    const empty = [];
    for (let col = 0; col < last; col += 1) if (!used.has(col)) empty.push(col);
    if (empty.length > 0) {
      problems.push(warning('stage/empty-col', {
        target: [stage.id],
        detail: { id: stage.id, label: stage.label, empty, used: [...used].sort((p, q) => p - q) },
      }));
    }
  });
  return problems;
}

// 同じ段の同じ列で、2つの部品の行の範囲（row から1行分）が重なってはいけない（layout/overlap）。
// row は 0.5 の倍数なので、そのまま比べても誤差は出ない。
function checkPlacement({ stages, nodes }) {
  const stageSet = new Set(stages.map((stage) => stage.id));
  const problems = [];
  for (let i = 0; i < nodes.length; i += 1) {
    for (let j = i + 1; j < nodes.length; j += 1) {
      const [a, b] = [nodes[i], nodes[j]];
      if (a.stage !== b.stage || !stageSet.has(a.stage) || (a.col ?? 0) !== (b.col ?? 0)) continue;
      if (Math.abs(a.row - b.row) >= 1) continue;
      const detail = { first: a.id, second: b.id, stage: a.stage, col: a.col ?? 0, row: Math.max(a.row, b.row) };
      const place = freePlace(b, nodes.filter((node) => node !== b));
      if (place) detail.suggestion = place;
      problems.push(error('layout/overlap', { target: [a.id, b.id], detail }));
    }
  }
  return problems;
}

// 部品の移し先の候補。同じ段の中で、ほかの部品と行の範囲が重ならない位置のうち、今の位置にいちばん近いもの。
// 同じ列の整数の行を先に探し（近い順、同じ近さなら上）、なければ段の中の別の列を探す。見つからなければ null。
function freePlace(node, others) {
  const col = node.col ?? 0;
  const blocked = (c, row) => others.some((other) => other.stage === node.stage && (other.col ?? 0) === c && Math.abs(other.row - row) < 1);
  const rows = Array.from({ length: ROW_LIMIT }, (_, row) => row)
    .sort((p, q) => Math.abs(p - node.row) - Math.abs(q - node.row) || p - q);
  for (const row of rows) if (!blocked(col, row)) return { col, row };
  for (let c = 0; c < COL_LIMIT; c += 1) {
    if (c !== col && !blocked(c, node.row)) return { col: c, row: node.row };
  }
  return null;
}

function checkEdges({ nodes, edges }) {
  const problems = [];
  const routes = new Map();
  edges.forEach((edge, i) => {
    if (edge.from === edge.to) {
      problems.push(error('edge/self-loop', { target: edgeTarget(edge), detail: { path: `/edges/${i}`, id: edge.from } }));
    }
    // 始点・終点が同じ線は、ラベルが違っても重なって1本に見えるので、重複とみなす。
    const key = `${edge.from} ${edge.to}`;
    if (!routes.has(key)) routes.set(key, { edge, paths: [], labels: [] });
    routes.get(key).paths.push(`/edges/${i}`);
    routes.get(key).labels.push(edge.label);
  });
  for (const { edge, paths, labels } of routes.values()) {
    if (paths.length > 1) {
      problems.push(warning('edge/duplicate', { target: [edge.from, edge.to], detail: { from: edge.from, to: edge.to, paths, labels } }));
    }
  }
  const linked = new Set(edges.flatMap((edge) => [edge.from, edge.to]));
  for (const node of nodes) {
    if (!linked.has(node.id)) problems.push(warning('node/isolated', { target: [node.id], detail: { id: node.id } }));
  }
  return problems;
}

function checkTextLength({ stages, nodes, edges }) {
  return longTexts([
    ...stages.map((stage, i) => ({ text: stage.label, path: `/stages/${i}/label`, limit: TEXT_GUIDELINES.stageLabel, target: [stage.id] })),
    ...nodes.flatMap((node, i) => [
      { text: node.label, path: `/nodes/${i}/label`, limit: TEXT_GUIDELINES.label, target: [node.id] },
      { text: node.sublabel, path: `/nodes/${i}/sublabel`, limit: TEXT_GUIDELINES.sublabel, target: [node.id] },
      { text: node.tag, path: `/nodes/${i}/tag`, limit: TEXT_GUIDELINES.tag, target: [node.id] },
    ]),
    ...edges.map((edge, i) => ({ text: edge.label, path: `/edges/${i}/label`, limit: TEXT_GUIDELINES.edgeLabel, target: edgeTarget(edge) })),
  ]);
}

function checkNodeCount(nodes) {
  if (nodes.length <= NODE_COUNT_GUIDELINE) return [];
  return [warning('size/too-many-nodes', { detail: { count: nodes.length, limit: NODE_COUNT_GUIDELINE } })];
}

/** 見た目のチェック。ラベルの重なり（段の見出しを含む）・線の交差・図の大きさ。 */
export function inspectDataflow(doc, layout, limits = {}) {
  const { widths } = stageColumns(doc);
  const rows = Math.ceil(Math.max(...doc.nodes.map((node) => node.row + 1))) - Math.floor(Math.min(...doc.nodes.map((node) => node.row)));
  return [
    ...inspectDiagram(doc.edges, layout, {
      sibling: isSibling,
      boxes: layout.stages.map((stage) => ({ kind: 'stage', id: stage.id, box: stage.labelBox })),
    }),
    ...oversize(layout, limits, {
      width: { stages: doc.stages.length, columns: widths.reduce((sum, width) => sum + width, 0) },
      height: { rows },
    }),
  ];
}
