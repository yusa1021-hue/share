// 図の種類「dataflow」の定義。core/check.mjs に渡して使う。

import { KINDS, iconElement, kindLegend } from '../../core/kinds.mjs';
import { createValidator } from '../../core/schema.mjs';
import { VALUE_SYNONYMS, checkDataflow, inspectDataflow } from './checks.mjs';
import { layoutDataflow } from './layout.mjs';
import { dataflowMessages, styleNames } from './messages.mjs';
import { LEGEND_STYLES, dataflowStyles, renderDataflow, styleSample } from './render.mjs';

// schema には types/dataflow/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createDataflowType(schema) {
  return {
    name: 'dataflow',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkDataflow,
    layout: layoutDataflow,
    inspect: inspectDataflow,
    render: renderDataflow,
    styles: dataflowStyles,
    legend: legendItems,
    icon: (kind, options) => (KINDS.includes(kind) ? iconElement(kind, options) : null),
    messages: dataflowMessages,
  };
}

// 凡例の項目。図で使われている部品の種類と線の種類だけを、決まった順に並べる（architecture と同じ作り）。
// 部品の種類は icon（記号）、線の種類は sample（見本の SVG）を返す。ふつうの線（どの種類も付けない線）は出さない。
function legendItems(doc, lang) {
  const kinds = new Set(doc.nodes.map((node) => node.kind));
  const styles = new Set(LEGEND_STYLES.filter((style) => doc.edges.some((edge) => edge[style])));
  return [
    ...kindLegend(kinds, lang),
    ...LEGEND_STYLES.filter((style) => styles.has(style)).map((style) => ({ key: style, label: styleNames[lang][style], sample: styleSample(style) })),
  ];
}
