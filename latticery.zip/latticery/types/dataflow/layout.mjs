// dataflow の配置の計算。仕様：docs/latticery/types/dataflow.md の「3. 描きかた」
//
// 1. 部品を、段（stage）・段の中の列（col）・行（row）から格子の升目に割り当てる。
//    格子の列は、前の段までの列の数に、段の中の列を足したもの。段の幅は、その段で使う列の数
// 2. 以降は architecture と同じ共通の仕組みを使う：経路（core/route.mjs）・レーンとラベル（core/lanes.mjs）・
//    列と行の幅（core/axis.mjs）。行の半マスずらしも architecture と同じ
// 3. 段の帯（列の帯。core/bands.mjs）の範囲と見出しの場所を決める。見出しは格子の外（上端）に置き、その分だけ図を下にずらす
//
// 入力は、スキーマ検証と構造のチェックを通った図であること。

import { addSpanConstraint, createAxis, evaluate, sizeGrid } from '../../core/axis.mjs';
import { bandLabelWidth, fillBands, headerThickness } from '../../core/bands.mjs';
import { border, buildGrid, line, round } from '../../core/grid.mjs';
import { EDGE, anchorAt, assignLanes, buildRuns, chooseLabels, edgePoints, labelWidth, pairOrders, placeLanes, sharedVertices } from '../../core/lanes.mjs';
import { NODE, nodeSize, tagBoxAvoiding } from '../../core/node.mjs';
import { routeEdges } from '../../core/route.mjs';

export const METRICS = {
  node: NODE, // 部品の箱の寸法（core/node.mjs）
  edge: EDGE, // 線とラベルの寸法（core/lanes.mjs）
  // base：内側の通路の最小幅。outer：外周の通路の最小幅。emptyTrack：部品のない列・行の幅。
  // oddInset：列・行の中心線に接する部品（半マスずらし）と中心線との間隔。どれも architecture と同じ。
  gutter: { base: 44, outer: 12, emptyTrack: 16, oddInset: 22 },
  // 線のラベルの前後（区間の方向）の余白。横の区間は、鏃とラベルの両側の線が見えるよう広げる（決定記録 No.94）。
  // dataflow はすべての線にラベルがあり、隣り合う部品をつなぐ短い線が多いため。縦の区間は architecture と同じ。
  labelMargin: { h: 22, v: EDGE.labelMargin },
};

// 同じ部品から出る線、または同じ部品に入る線で、種類（primary・async・sensitive）が同じものを「兄弟」と呼ぶ。
// 兄弟の線は、同じ接続点から出る（入る）なら、分かれるまで（合流してから）を重ねて1本の幹として描く（architecture と同じ）。
// 色や破線の違う線を重ねると読めなくなるので、種類が違えば兄弟にしない。
export const sameStyle = (a, b) => Boolean(a.primary) === Boolean(b.primary)
  && Boolean(a.async) === Boolean(b.async) && Boolean(a.sensitive) === Boolean(b.sensitive);
export const isSibling = (a, b) => sameStyle(a, b) && (a.from === b.from || a.to === b.to);

/**
 * 段ごとの列の数と、図全体での最初の列。段の列の数は、その段の部品の col（省略すると 0）の最大に 1 を足したもの。
 * 部品のない段は 1 列として数える（構造のチェックでエラーになるので、配置の計算には来ない）。
 */
export function stageColumns(doc) {
  const widths = doc.stages.map((stage) => 1 + Math.max(0, ...doc.nodes.filter((node) => node.stage === stage.id).map((node) => node.col ?? 0)));
  const starts = [];
  widths.reduce((sum, width, i) => { starts[i] = sum; return sum + width; }, 0);
  return { widths, starts };
}

/**
 * 配置を計算する。返り値は { layout, diagnostics }。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutDataflow(doc) {
  const edges = doc.edges;
  const stageIndex = new Map(doc.stages.map((stage, i) => [stage.id, i]));
  const { widths, starts } = stageColumns(doc);
  const placed = doc.nodes.map((node) => ({ ...node, col: starts[stageIndex.get(node.stage)] + (node.col ?? 0), row: node.row }));
  const grid = buildGrid(placed);
  const { routes, diagnostics } = routeEdges(edges, grid, { sibling: isSibling });
  const runsByEdge = routes.map((route) => (route ? buildRuns(route, grid) : null));
  const buckets = assignLanes(runsByEdge, sharedVertices(edges, routes, sameStyle), pairOrders(routes));
  const labels = chooseLabels(edges, runsByEdge);
  const labelRuns = labels.map((label) => label?.run ?? null);
  const labelAnchors = labels.map((label) => label?.anchor ?? null);
  const laneWidths = placeLanes(buckets, labels, edges);

  const x = createAxis(grid.cols, METRICS.gutter.oddInset);
  const y = createAxis(grid.rows, METRICS.gutter.oddInset);
  sizeGrid({
    grid, edges, runsByEdge, labelRuns, labelAnchors, laneWidths, x, y, gutter: METRICS.gutter, sizeOf: nodeSize, labelMargin: METRICS.labelMargin,
  });

  // 段が占める格子の線の範囲。段の列の範囲（部品のない列も含む）で決める。格子は使われている最初の列を 0 にそろえるので、
  // その分をずらし、格子の外に出る分（先頭の段の、部品のない列）は切る。
  const firstCol = Math.min(...placed.map((node) => Math.floor(node.col)));
  const clamp = (k) => Math.min(Math.max(k, 0), grid.maxK);
  const spans = doc.stages.map((stage, i) => [clamp(2 * (starts[i] - firstCol)), clamp(2 * (starts[i] + widths[i] - firstCol))]);
  // 段の名前は、その段の範囲に入るだけの幅を取る。
  doc.stages.forEach((stage, i) => addSpanConstraint(x, line(spans[i][0]), line(spans[i][1]), bandLabelWidth(stage.label), ['B', 'H']));
  const X = evaluate(x);
  const Y = evaluate(y);

  // 段の見出しの分だけ、図を下にずらす。
  const thickness = headerThickness(doc.stages.map((stage) => stage.label), 'x');
  const shift = { x: 0, y: round(thickness) };
  const at = { x: (spec) => round(X.at(spec)) + shift.x, y: (spec) => round(Y.at(spec)) + shift.y };
  const width = round(X.total) + shift.x;
  const height = round(Y.total) + shift.y;

  const nodes = grid.boxes.map((box) => {
    const left = at.x(border(box.a, 1));
    const top = at.y(border(box.c, 1));
    return {
      id: box.node.id,
      kind: box.node.kind,
      label: box.node.label,
      sublabel: box.node.sublabel ?? null,
      tag: box.node.tag ?? null,
      stage: box.node.stage,
      x: left,
      y: top,
      width: at.x(border(box.b, -1)) - left,
      height: at.y(border(box.d, -1)) - top,
      tagBox: null,
    };
  });

  const edgeLayouts = [];
  edges.forEach((edge, i) => {
    const runs = runsByEdge[i];
    if (!runs) return;
    const points = edgePoints(runs, X, Y).map(([px, py]) => [px + shift.x, py + shift.y]);
    const labelRun = labelRuns[i];
    let labelBox = null;
    if (labelRun) {
      const boxWidth = labelWidth(edge.label);
      const boxHeight = METRICS.edge.labelHeight;
      const anchor = labelAnchors[i];
      const across = labels[i].across ?? 0;
      const cx = labelRun.axis === 'h' ? anchorAt(X, laneWidths.v, anchor) + across : X.at(line(labelRun.line)) + labelRun.offset;
      const cy = labelRun.axis === 'h' ? Y.at(line(labelRun.line)) + labelRun.offset : anchorAt(Y, laneWidths.h, anchor) + across;
      labelBox = {
        x: round(cx - boxWidth / 2) + shift.x, y: round(cy - boxHeight / 2) + shift.y, width: boxWidth, height: boxHeight,
      };
    }
    edgeLayouts.push({
      id: edge.id ?? null,
      from: edge.from,
      to: edge.to,
      label: edge.label,
      primary: Boolean(edge.primary),
      async: Boolean(edge.async),
      sensitive: Boolean(edge.sensitive),
      points,
      labelBox,
    });
  });

  // 札は右上に置き、上から入る（出る）線の端に重なるときは左上に置く。
  const ends = edgeLayouts.flatMap((edge) => [edge.points[0], edge.points.at(-1)]);
  for (const node of nodes) if (node.tag) node.tagBox = tagBoxAvoiding(node, ends);

  // 段の帯：図の高さいっぱいに伸び、横は段の列の範囲を占める。左端と右端の段は、図の端まで伸ばす。
  const stages = fillBands(doc.stages, spans, 'x', { at, offset: shift, thickness, width, height });

  return {
    layout: { width, height, header: shift, nodes, edges: edgeLayouts, stages },
    diagnostics,
  };
}
