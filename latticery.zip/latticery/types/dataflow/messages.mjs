// dataflow の文言（日英）：凡例の線の種類の名前と、診断のメッセージ。診断の形は core/messages.mjs と同じ。
// 部品の種類の名前は、architecture と共通なので core/kinds.mjs にある。
// id/duplicate・text/too-long のメッセージは core/messages.mjs にある。

import { formatPath, joinList } from '../../core/i18n.mjs';

// 凡例に出す、線の種類（主な経路・非同期・定期実行・機密データ）の名前。
export const styleNames = {
  ja: { primary: '主な経路', async: '非同期・定期実行', sensitive: '機密データ（個人情報など）' },
  en: { primary: 'Main path', async: 'Async or scheduled', sensitive: 'Sensitive data (e.g. personal data)' },
};

// 線の呼び方（「a」→「b」の線）。
const edgeName = (e, lang) => (lang === 'ja' ? `「${e.from}」→「${e.to}」の線` : `the edge "${e.from}" → "${e.to}"`);

// ラベルと重なっているもの。
const overlapName = (item, lang) => {
  if (item.kind === 'node') return lang === 'ja' ? `部品「${item.id}」` : `node "${item.id}"`;
  if (item.kind === 'stage') return lang === 'ja' ? `段「${item.id}」の見出し` : `the header of stage "${item.id}"`;
  if (item.kind === 'label') return lang === 'ja' ? `${edgeName(item, 'ja')}のラベル` : `the label of ${edgeName(item, 'en')}`;
  return edgeName(item, lang);
};

const quoted = (list, lang) => joinList(list.map((item) => (lang === 'ja' ? `「${item}」` : `"${item}"`)), lang);

export const dataflowMessages = {
  'ref/unknown': {
    ja: {
      message: (d) => {
        if (d.isNode) return `${formatPath(d.path, 'ja')} の「${d.value}」は部品の ID です。ここには段の ID を書きます`;
        if (d.isStage) return `${formatPath(d.path, 'ja')} の「${d.value}」は段の ID です。ここには部品の ID を書きます`;
        return `${formatPath(d.path, 'ja')} の「${d.value}」という${d.kind === 'stage' ? '段' : '部品'}はありません`;
      },
      fixes: (d) => {
        if (d.isStage) return ['線は部品同士をつなぐ。その段の中の部品の ID を書く'];
        return [
          ...(d.suggestion ? [`「${d.suggestion}」の書き間違いなら直す`] : []),
          d.kind === 'stage' ? `ID「${d.value}」の段を stages に追加する` : `ID「${d.value}」の部品を nodes に追加する`,
        ];
      },
    },
    en: {
      message: (d) => {
        if (d.isNode) return `"${d.value}" at ${formatPath(d.path, 'en')} is a node ID; a stage ID is required here`;
        if (d.isStage) return `"${d.value}" at ${formatPath(d.path, 'en')} is a stage ID; a node ID is required here`;
        return `${formatPath(d.path, 'en')}: there is no ${d.kind === 'stage' ? 'stage' : 'node'} "${d.value}"`;
      },
      fixes: (d) => {
        if (d.isStage) return ['Edges connect nodes: use the ID of a node in that stage'];
        return [
          ...(d.suggestion ? [`If this is a typo for "${d.suggestion}", fix it`] : []),
          d.kind === 'stage' ? `Add a stage with the ID "${d.value}" to stages` : `Add a node with the ID "${d.value}" to nodes`,
        ];
      },
    },
  },
  'stage/empty': {
    ja: {
      message: (d) => `段「${d.label}」（${d.id}）に、部品が1つもありません`,
      fixes: (d) => [
        `この段に置く部品があれば、その部品の stage を "${d.id}" にする`,
        d.neighbors.length > 0 ? `不要なら段を消す（部品は隣の段 ${quoted(d.neighbors, 'ja')} に置く）` : '不要なら段を消す',
      ],
    },
    en: {
      message: (d) => `Stage "${d.label}" (${d.id}) has no nodes`,
      fixes: (d) => [
        `If a node belongs to this stage, set its stage to "${d.id}"`,
        d.neighbors.length > 0 ? `Otherwise remove the stage (put its nodes in the neighboring stage ${quoted(d.neighbors, 'en')})` : 'Otherwise remove the stage',
      ],
    },
  },
  'stage/empty-col': {
    ja: {
      message: (d) => `段「${d.label}」の中の列 ${joinList(d.empty.map(String), 'ja')} に、部品がありません（使っている列：${joinList(d.used.map(String), 'ja')}）`,
      fixes: () => [
        'col は段ごとに 0 から数える（図全体の列ではない）。段の中で左から 0・1・2 と詰めて書く',
        '1つの段の中で処理が続くときだけ col を使う。ふつうは省略する（0 になる）',
      ],
    },
    en: {
      message: (d) => `Stage "${d.label}" has no nodes in column${d.empty.length > 1 ? 's' : ''} ${joinList(d.empty.map(String), 'en')} (columns in use: ${joinList(d.used.map(String), 'en')})`,
      fixes: () => [
        'col counts from 0 within each stage (it is not a column of the whole diagram). Number the columns 0, 1, 2 from the left of the stage',
        'Use col only when processing continues within one stage; usually leave it out (it defaults to 0)',
      ],
    },
  },
  'layout/overlap': {
    ja: {
      message: (d) => `段「${d.stage}」の列 ${d.col} で、部品「${d.first}」と「${d.second}」の行が重なっています（row ${d.row} のあたり）`,
      fixes: (d) => [
        d.suggestion
          ? `どちらかを空いている位置に移す（たとえば「${d.second}」を ${d.suggestion.col === d.col ? '' : `col ${d.suggestion.col}・`}row ${d.suggestion.row} に）`
          : 'どちらかの row を、1 以上離す',
        '別の段の部品なら、stage を直す',
      ],
    },
    en: {
      message: (d) => `Nodes "${d.first}" and "${d.second}" overlap in column ${d.col} of stage "${d.stage}" (around row ${d.row})`,
      fixes: (d) => [
        d.suggestion
          ? `Move one of them to a free place (for example, "${d.second}" to ${d.suggestion.col === d.col ? '' : `col ${d.suggestion.col}, `}row ${d.suggestion.row})`
          : 'Keep their rows at least 1 apart',
        'If one of them belongs to another stage, fix its stage',
      ],
    },
  },
  'edge/self-loop': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線は、始点と終点が同じ部品「${d.id}」です`,
      fixes: () => ['from か to を別の部品にする', '部品の中での加工なら、線を消して、部品の補足（sublabel）に書く'],
    },
    en: {
      message: (d) => `The edge at ${formatPath(d.path, 'en')} starts and ends at the same node "${d.id}"`,
      fixes: () => ['Point from or to at a different node', 'If the data is processed inside the node, remove the edge and describe it in the sublabel'],
    },
  },
  'edge/no-route': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線（「${d.from}」→「${d.to}」）の通り道が見つかりません`,
      fixes: () => ['fromSide・toSide の指定を外すか、別の辺にする', '周りの部品の行（row）を変えて、通り道を空ける'],
    },
    en: {
      message: (d) => `No route was found for the edge at ${formatPath(d.path, 'en')} ("${d.from}" → "${d.to}")`,
      fixes: () => ['Remove fromSide/toSide or choose another side', 'Change the rows of the surrounding nodes to open a path'],
    },
  },
  'edge/duplicate': {
    ja: {
      message: (d) => `「${d.from}」から「${d.to}」への線が${d.paths.length}本あります（${quoted(d.labels, 'ja')}）`,
      fixes: (d) => [`線は重なって1本に見えるので、1本にまとめ、label に両方のデータの名前を書く（「${d.labels.join('・')}」など）`],
    },
    en: {
      message: (d) => `There are ${d.paths.length} edges from "${d.from}" to "${d.to}" (${quoted(d.labels, 'en')})`,
      fixes: (d) => [`They would be drawn on top of each other: merge them into one edge and name both data in its label (such as "${d.labels.join(', ')}")`],
    },
  },
  'node/isolated': {
    ja: {
      message: (d) => `部品「${d.id}」はどの線ともつながっていません`,
      fixes: () => ['この部品とやりとりするデータの線を追加する', '図に不要なら消す'],
    },
    en: {
      message: (d) => `Node "${d.id}" is not connected to any edge`,
      fixes: () => ['Add an edge for the data this node sends or receives', 'Remove the node if the diagram does not need it'],
    },
  },
  'size/too-many-nodes': {
    ja: {
      message: (d) => `部品が${d.count}個あります。${d.limit}個を超えると読みにくくなります`,
      fixes: () => ['主な経路との関係が薄い部品を省く', '図を2つに分ける（取り込みまでと、加工から後など）'],
    },
    en: {
      message: (d) => `The diagram has ${d.count} nodes; more than ${d.limit} makes it hard to read`,
      fixes: () => ['Leave out nodes that are only loosely related to the main path', 'Split the diagram into two (for example, up to ingestion, and from processing on)'],
    },
  },
  'edge/label-overlap': {
    ja: {
      message: (d) => `${edgeName(d, 'ja')}のラベル「${d.label}」が、${joinList(d.overlaps.map((item) => overlapName(item, 'ja')), 'ja')}と重なっています`,
      fixes: () => [
        'ラベル（データの名前）を短くする',
        '重なっている線の端の部品を別の行（row）に移し、2本の線が同じ通路を並んで通らないようにする',
      ],
    },
    en: {
      message: (d) => `The label "${d.label}" of ${edgeName(d, 'en')} overlaps ${joinList(d.overlaps.map((item) => overlapName(item, 'en')), 'en')}`,
      fixes: () => [
        'Shorten the label (the name of the data)',
        'Move an end node of the overlapping edge to another row so that the two edges do not run side by side',
      ],
    },
  },
  'edge/crossing': {
    ja: {
      message: (d) => `${edgeName(d.first, 'ja')}と${edgeName(d.second, 'ja')}が交差しています（${d.count}か所）`,
      fixes: () => [
        '同じ段の中の部品の上下（row）を入れ替えて、つながる相手と同じ高さに近づける',
        'どちらかの線の端の部品を、もう一方の線をまたがずにつながる行に移す',
      ],
    },
    en: {
      message: (d) => `${edgeName(d.first, 'en').replace(/^t/, 'T')} crosses ${edgeName(d.second, 'en')} (${d.count} ${d.count === 1 ? 'time' : 'times'})`,
      fixes: () => [
        'Swap the rows of nodes within a stage so that each node sits closer to the height of the nodes it connects to',
        'Move an end node of one edge to a row where it can connect without crossing the other edge',
      ],
    },
  },
  'size/too-wide': {
    ja: {
      message: (d) => `図の幅が ${d.width}px あります（段 ${d.stages} つ・列 ${d.columns}）。指定の ${d.limit}px を超えています`,
      fixes: () => [
        '段を減らす（続けて行う加工を1つの段にまとめる）',
        '段の中の列（col）を使わず、同じ段の部品を縦に並べる',
        '長い名前・補足・線のラベルを短くする',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.width}px wide (${d.stages} stages, ${d.columns} columns), which exceeds the requested ${d.limit}px`,
      fixes: () => [
        'Use fewer stages (merge processing steps that follow each other into one stage)',
        'Stack the nodes of a stage vertically instead of using col',
        'Shorten long labels, sublabels, and edge labels',
      ],
    },
  },
  'size/too-tall': {
    ja: {
      message: (d) => `図の高さが ${d.height}px あります（${d.rows}行）。指定の ${d.limit}px を超えています`,
      fixes: () => [
        '行を減らす。並行する流れのうち、主な経路と関係の薄いものを省く',
        '部品のない行を詰める',
        '補足（sublabel）を省くと、その行が低くなる',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.height}px tall (${d.rows} rows), which exceeds the requested ${d.limit}px`,
      fixes: () => [
        'Use fewer rows: leave out parallel flows that are only loosely related to the main path',
        'Remove empty rows',
        'Leave out sublabels to make their rows lower',
      ],
    },
  },
};
