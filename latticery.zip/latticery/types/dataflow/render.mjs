// dataflow の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/dataflow.md の「3. 描きかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは core/draw.mjs の diagramStyles() と、下の dataflowStyles() で行う。
// 部品の箱・線・鏃・角の丸め・段の帯は、ほかの図の種類と共通のもの（core/）を使う。

import { bandHeaderStrips, bandRule, fillBandElement } from '../../core/bands.mjs';
import { BASE_COLORS, EDGE_DRAW, edgeElement, edgeLabelElement, findHops, lineSample, sampleSvg } from '../../core/draw.mjs';
import { nodeElement } from '../../core/node.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY } from '../../core/text.mjs';
import { METRICS } from './layout.mjs';

// ---- 凡例の見本 ------------------------------------------------------------------

export const LEGEND_STYLES = ['primary', 'async', 'sensitive'];

/** 凡例に出す、線の種類（主な経路・非同期・定期実行・機密データ）の見本。図と同じクラスを付け、色はテーマの CSS で決まる。 */
export function styleSample(style) {
  const base = BASE_COLORS.light;
  const primary = style === 'primary';
  const sensitive = style === 'sensitive';
  return sampleSvg(lineSample({
    classes: [primary ? 'lt-primary' : null, style === 'async' ? 'lt-async' : null, sensitive ? 'lt-sensitive' : null],
    width: primary ? EDGE_DRAW.primaryWidth : EDGE_DRAW.width,
    color: sensitive ? base.edgeSensitive : (primary ? base.edgeStrong : base.edge),
    dash: style === 'async' ? '4 3' : null,
    arrow: { length: 8.5, width: primary ? 9 : 8 },
  }));
}

// ---- 図 ----------------------------------------------------------------------

/**
 * 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。
 * つながりの強調（viewer/highlight.mjs）のため、部品には data-node（ID）を、線とそのラベルには
 * data-edge（edges の中の番号）・data-from・data-to を付ける。
 */
export function renderDataflow(layout, doc) {
  const base = BASE_COLORS.light;
  const hops = findHops(layout.edges);
  // 段は列の帯（core/bands.mjs）。見出しは上端に置く。
  const frame = { width: layout.width, height: layout.height, offset: layout.header };
  // 主な経路の線を後から描き、ほかの線より上に見えるようにする。
  const order = layout.edges.map((edge, i) => i).sort((p, q) => Number(layout.edges[p].primary) - Number(layout.edges[q].primary) || p - q);
  return el('svg', {
    class: 'lt-diagram lt-dataflow',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    bandHeaderStrips(['x'], frame, base),
    el('g', { class: 'lt-stages' }, layout.stages.map((stage, i) => fillBandElement(stage, i, 'x', { name: 'lt-stage', base }))),
    // 見出しと本体の境目の線は、帯の色の上に描く（色を敷いた帯に隠れないように）。
    bandRule(['x'], frame, base),
    el('g', { class: 'lt-edges' }, order.map((i) => edgeElement(layout.edges[i], i, hops[i], base))),
    el('g', { class: 'lt-edge-labels' }, order.filter((i) => layout.edges[i].labelBox)
      .map((i) => edgeLabelElement(layout.edges[i], i, base, METRICS.edge.labelSize))),
    el('g', { class: 'lt-nodes' }, layout.nodes.map((node) => nodeElement(node, { 'data-id': node.id, 'data-node': node.id }))),
  ]);
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、dataflow だけのもの（主な経路）。
 * 図の色の変数と、部品・線・帯・機密データの線に共通の部分は core/draw.mjs の diagramStyles() で決める。
 */
export function dataflowStyles() {
  return [
    '.lt-primary .lt-edge-line{stroke:var(--lt-edge-strong)}',
    '.lt-primary .lt-arrow{fill:var(--lt-edge-strong)}',
  ].join('\n');
}
