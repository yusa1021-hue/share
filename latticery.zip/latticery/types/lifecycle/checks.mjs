// lifecycle のチェック。仕様：docs/latticery/types/lifecycle.md の「4. チェック」
// checkLifecycle：構造のチェック。スキーマ検証を通った図に対して、配置を計算しなくても分かる問題を調べる。
// inspectLifecycle：見た目のチェック。配置の計算の結果（layout.mjs の layoutLifecycle が返す layout）を使う。
// ラベルの重なりと線の交差は、ほかの種類と同じ共通のチェック（core/inspect.mjs）を使う。

import { duplicateIds, longTexts, oversize } from '../../core/checks.mjs';
import { closest, error, synonymIndex, warning } from '../../core/diagnostics.mjs';
import { inspectDiagram } from '../../core/inspect.mjs';
import { edgeTarget } from '../../core/route.mjs';
import { flowEdges, isMainFlow, isSibling } from './layout.mjs';
import { ENDINGS, LANES, STATE_SYNONYMS } from './states.mjs';

export const COL_LIMIT = 10; // 列（col）の数
export const NODE_COUNT_GUIDELINE = 20;

// 使えない値から、意味の近い使える値への対応（schema/invalid の直し方の候補に使う）。状態の種類と帯の ID。
export const VALUE_SYNONYMS = synonymIndex(STATE_SYNONYMS);

// 表示幅の目安（半角1・全角2で数える）。workflow と同じ。
const TEXT_GUIDELINES = {
  laneLabel: 12,
  label: 18,
  sublabel: 20,
  tag: 8,
  edgeLabel: 12,
};

export function checkLifecycle(doc) {
  const parts = { lanes: doc.lanes ?? [], nodes: doc.nodes, edges: doc.edges };
  return [
    ...checkIds(parts),
    ...checkReferences(parts),
    ...checkLanes(parts),
    ...checkPlacement(parts),
    ...checkEdges(parts),
    ...checkFlow(parts),
    ...checkTextLength(parts),
    ...checkNodeCount(parts.nodes),
  ];
}

// 帯の ID（main・detour・end）は決まった名前なので、状態・線の ID とは別に数える（状態の ID に end を使ってもよい）。
function checkIds({ lanes, nodes, edges }) {
  return [
    ...duplicateIds(lanes.map((lane, i) => ({ id: lane.id, path: `/lanes/${i}/id` }))),
    ...duplicateIds([
      ...nodes.map((node, i) => ({ id: node.id, path: `/nodes/${i}/id` })),
      ...edges.map((edge, i) => ({ id: edge.id, path: `/edges/${i}/id` })),
    ]),
  ];
}

function checkReferences({ nodes, edges }) {
  const nodeIds = nodes.map((node) => node.id);
  const nodeSet = new Set(nodeIds);
  const problems = [];
  const verify = (value, path, target) => {
    if (nodeSet.has(value)) return;
    const detail = { path, value };
    const suggestion = closest(value, nodeIds);
    if (suggestion) detail.suggestion = suggestion;
    problems.push(error('ref/unknown', { target, detail }));
  };
  edges.forEach((edge, i) => {
    verify(edge.from, `/edges/${i}/from`, edgeTarget(edge));
    verify(edge.to, `/edges/${i}/to`, edgeTarget(edge));
  });
  return problems;
}

// 上段（main）に状態が1つもない（lane/main-empty。エラー）。直し方の候補に、上段に移せそうな状態（中段・下段のいちばん左）を示す。
function checkLanes({ nodes }) {
  if (nodes.some((node) => node.lane === 'main')) return [];
  const [first] = [...nodes].sort((p, q) => LANES.indexOf(p.lane) - LANES.indexOf(q.lane) || p.col - q.col);
  return [error('lane/main-empty', { detail: { first: first?.id ?? null } })];
}

// 同じ帯の同じ列に、2つの状態は置けない（layout/overlap）。直し方の候補に、同じ帯の空いている列のうち、いちばん近いものを示す。
function checkPlacement({ nodes }) {
  const places = new Map();
  for (const node of nodes) {
    const key = `${node.lane}:${node.col}`;
    if (!places.has(key)) places.set(key, []);
    places.get(key).push(node);
  }
  const used = new Set(places.keys());
  return [...places.values()].filter((group) => group.length > 1).map((group) => {
    const { lane, col } = group[0];
    const detail = { lane, col, ids: group.map((node) => node.id) };
    const free = freeCol(lane, col, used);
    if (free !== null) detail.free = free;
    return error('layout/overlap', { target: detail.ids, detail });
  });
}

// 帯 lane の空いている列のうち、col にいちばん近いもの（同じ近さなら右）。used は「帯:列」の集まり。なければ null。
function freeCol(lane, col, used) {
  for (let distance = 1; distance < COL_LIMIT; distance += 1) {
    for (const candidate of [col + distance, col - distance]) {
      if (candidate >= 0 && candidate < COL_LIMIT && !used.has(`${lane}:${candidate}`)) return candidate;
    }
  }
  return null;
}

// 線：自分へ戻る線（エラー）、始点・終点が同じ線（警告）、ラベルのない外れる線（警告）。
function checkEdges({ nodes, edges }) {
  const problems = [];
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const routes = new Map();
  edges.forEach((edge, i) => {
    if (edge.from === edge.to) {
      const node = byId.get(edge.from);
      problems.push(error('edge/self-loop', { target: edgeTarget(edge), detail: { path: `/edges/${i}`, id: edge.from, label: node?.label ?? edge.from } }));
      return;
    }
    // 始点・終点が同じ線は、ラベルが違っても重なって1本に見えるので、重複とみなす。
    const key = `${edge.from} ${edge.to}`;
    if (!routes.has(key)) routes.set(key, { edge, paths: [], labels: [] });
    routes.get(key).paths.push(`/edges/${i}`);
    routes.get(key).labels.push(edge.label ?? null);
    if (!edge.label && !isMainFlow(edge, byId) && byId.has(edge.from) && byId.has(edge.to)) {
      problems.push(warning('edge/unlabeled', { target: edgeTarget(edge), detail: { path: `/edges/${i}`, from: edge.from, to: edge.to } }));
    }
  });
  for (const { edge, paths, labels } of routes.values()) {
    if (paths.length > 1) {
      problems.push(warning('edge/duplicate', { target: [edge.from, edge.to], detail: { from: edge.from, to: edge.to, paths, labels: labels.filter(Boolean) } }));
    }
  }
  return problems;
}

// 流れの形：始まりと終わり、入ってこない状態・出ていかない状態、下段から出る線。
function checkFlow({ nodes, edges }) {
  const problems = [];
  const incoming = new Map(nodes.map((node) => [node.id, 0]));
  const outgoing = new Map(nodes.map((node) => [node.id, 0]));
  for (const edge of edges) {
    if (edge.from === edge.to) continue;
    if (incoming.has(edge.to)) incoming.set(edge.to, incoming.get(edge.to) + 1);
    if (outgoing.has(edge.from)) outgoing.set(edge.from, outgoing.get(edge.from) + 1);
  }
  const kinds = new Set(nodes.map((node) => node.kind));
  const main = nodes.filter((node) => node.lane === 'main').sort((p, q) => p.col - q.col);
  if (!kinds.has('start')) problems.push(warning('flow/no-start', { detail: { first: main[0]?.id ?? null } }));
  if (![...ENDINGS].some((kind) => kinds.has(kind))) problems.push(warning('flow/no-end', { detail: { last: main.at(-1)?.id ?? null } }));
  const used = new Set(nodes.map((node) => `${node.lane}:${node.col}`));
  for (const node of nodes) {
    const detail = { id: node.id, label: node.label, kind: node.kind, lane: node.lane };
    if (node.kind !== 'start' && incoming.get(node.id) === 0) {
      problems.push(warning('flow/unreachable', { target: [node.id], detail }));
    }
    // 下段の状態と、上段の終わりの種類（完了など）は、そこで終わってよい。中段の状態は、必ずどこかへ出ていく。
    const mayEnd = node.lane === 'end' || (node.lane === 'main' && ENDINGS.has(node.kind));
    if (!mayEnd && outgoing.get(node.id) === 0) {
      problems.push(warning('flow/dead-end', { target: [node.id], detail }));
    }
    if (node.lane === 'end' && outgoing.get(node.id) > 0) {
      const free = used.has(`detour:${node.col}`) ? freeCol('detour', node.col, used) : node.col;
      problems.push(warning('flow/exit-from-end', { target: [node.id], detail: { ...detail, free } }));
    }
  }
  return problems;
}

function checkTextLength({ lanes, nodes, edges }) {
  return longTexts([
    ...lanes.map((lane, i) => ({ text: lane.label, path: `/lanes/${i}/label`, limit: TEXT_GUIDELINES.laneLabel, target: [lane.id] })),
    ...nodes.flatMap((node, i) => [
      { text: node.label, path: `/nodes/${i}/label`, limit: TEXT_GUIDELINES.label, target: [node.id] },
      { text: node.sublabel, path: `/nodes/${i}/sublabel`, limit: TEXT_GUIDELINES.sublabel, target: [node.id] },
      { text: node.tag, path: `/nodes/${i}/tag`, limit: TEXT_GUIDELINES.tag, target: [node.id] },
    ]),
    ...edges.map((edge, i) => ({ text: edge.label, path: `/edges/${i}/label`, limit: TEXT_GUIDELINES.edgeLabel, target: edgeTarget(edge) })),
  ]);
}

function checkNodeCount(nodes) {
  if (nodes.length <= NODE_COUNT_GUIDELINE) return [];
  return [warning('size/too-many-nodes', { detail: { count: nodes.length, limit: NODE_COUNT_GUIDELINE } })];
}

/** 見た目のチェック。ラベルの重なり（帯の見出しを含む）・線の交差・図の大きさ。 */
export function inspectLifecycle(doc, layout, limits = {}) {
  const cols = new Set(doc.nodes.map((node) => node.col));
  return [
    ...inspectDiagram(flowEdges(doc), layout, {
      sibling: isSibling,
      boxes: layout.lanes.map((lane) => ({ kind: 'lane', id: lane.id, box: lane.labelBox })),
    }),
    ...oversize(layout, limits, {
      width: { columns: Math.max(...cols) - Math.min(...cols) + 1 },
      height: { lanes: layout.lanes.length },
    }),
  ];
}
