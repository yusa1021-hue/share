// 図の種類「lifecycle」の定義。core/check.mjs に渡して使う。

import { createValidator } from '../../core/schema.mjs';
import { VALUE_SYNONYMS, checkLifecycle, inspectLifecycle } from './checks.mjs';
import { flowEdges, layoutLifecycle } from './layout.mjs';
import { lifecycleMessages, styleNames } from './messages.mjs';
import { lifecycleStyles, mainFlowSample, renderLifecycle } from './render.mjs';
import { STATE_COLORS, STATE_KINDS, STATE_STYLE, stateIcon, stateNames } from './states.mjs';

// schema には types/lifecycle/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createLifecycleType(schema) {
  return {
    name: 'lifecycle',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkLifecycle,
    layout: layoutLifecycle,
    inspect: inspectLifecycle,
    render: renderLifecycle,
    styles: lifecycleStyles,
    legend: legendItems,
    icon: (kind, options) => (STATE_KINDS.includes(kind) ? stateIcon(kind, options) : null),
    kindClass: STATE_STYLE.className,
    messages: lifecycleMessages,
  };
}

// 凡例の項目。図で使われている状態の種類と、主な流れの線（あれば）を、決まった順に並べる。
// 状態の種類は、形がどれも四角なので、部品の種類と同じく色の四角に記号を入れて出す（icon）。色は .lt-state-<種類> の CSS で決まる。
function legendItems(doc, lang) {
  const kinds = new Set(doc.nodes.map((node) => node.kind));
  return [
    ...STATE_KINDS.filter((kind) => kinds.has(kind)).map((kind) => ({
      key: kind, label: stateNames[lang][kind], icon: stateIcon(kind), className: STATE_STYLE.className(kind), colors: STATE_COLORS[kind].light,
    })),
    ...(flowEdges(doc).some((edge) => edge.primary) ? [{ key: 'primary', label: styleNames[lang].primary, sample: mainFlowSample() }] : []),
  ];
}
