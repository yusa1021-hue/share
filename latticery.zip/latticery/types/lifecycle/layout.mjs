// lifecycle の配置の計算。仕様：docs/latticery/types/lifecycle.md の「3. 描きかた」
//
// 1. 状態を、帯（lane）と列（col）から格子の升目に割り当てる。格子の行は、状態のある帯を上から順に並べたもの
// 2. 主な流れ（上段の状態から、上段のより右の状態へ向かう線）を決め、経路探索で先に通す
// 3. 以降はほかの種類と同じ共通の仕組みを使う：経路（core/route.mjs）・レーンとラベル（core/lanes.mjs）・
//    列と行の幅（core/axis.mjs）
// 4. 帯（行の帯。core/bands.mjs）の範囲と見出しの場所を決める。見出しは格子の外（左端）に置き、その分だけ図を右にずらす
//
// 入力は、スキーマ検証と構造のチェックを通った図であること。

import { createAxis, evaluate, sizeGrid } from '../../core/axis.mjs';
import { BAND, fillBands, gridSpan, headerThickness } from '../../core/bands.mjs';
import { border, buildGrid, line, round } from '../../core/grid.mjs';
import { EDGE, anchorAt, assignLanes, buildRuns, chooseLabels, edgePoints, labelWidth, pairOrders, placeLanes, sharedVertices } from '../../core/lanes.mjs';
import { NODE, nodeSize, tagBoxAvoiding } from '../../core/node.mjs';
import { routeEdges } from '../../core/route.mjs';
import { LANES, STATE_STYLE, laneNames } from './states.mjs';

export const METRICS = {
  node: NODE, // 状態の箱の寸法（core/node.mjs）
  edge: EDGE, // 線とラベルの寸法（core/lanes.mjs）
  band: BAND, // 帯の見出しの寸法（core/bands.mjs）
  // base：内側の通路の最小幅。outer：外周の通路の最小幅。emptyTrack：状態のない列の幅。
  // oddInset：使わない（lifecycle は半マスずらしをしない）が、共通の計算が参照する。workflow と同じ値。
  gutter: { base: 44, outer: 16, emptyTrack: 20, oddInset: 22 },
  // 線のラベルの前後（区間の方向）の余白。横の区間は、鏃とラベルの両側の線が見えるよう広げる（dataflow と同じ。決定記録 No.94）。
  // 上段の主な流れの線にラベルを書くと、隣り合う状態の間が狭く見えるため。縦の区間はほかの種類と同じ。
  labelMargin: { h: 22, v: EDGE.labelMargin },
};

// 同じ状態から出る線、または同じ状態に入る線で、主な流れかどうかが同じものを「兄弟」と呼ぶ。
// 兄弟の線は、同じ接続点から出る（入る）なら、分かれるまで（合流してから）を重ねて1本の幹として描く（architecture と同じ）。
export const sameStyle = (a, b) => Boolean(a.primary) === Boolean(b.primary);
export const isSibling = (a, b) => sameStyle(a, b) && (a.from === b.from || a.to === b.to);

/** 主な流れか：上段の状態から、上段のより右の列の状態へ向かう線。byId は状態の ID から状態への対応。 */
export function isMainFlow(edge, byId) {
  const [from, to] = [byId.get(edge.from), byId.get(edge.to)];
  return Boolean(from && to && from.lane === 'main' && to.lane === 'main' && to.col > from.col);
}

/** 線に、主な流れかどうか（primary）を付けたもの。経路探索・兄弟の線・ラベルの重なりのチェックで使う。 */
export function flowEdges(doc) {
  const byId = new Map(doc.nodes.map((node) => [node.id, node]));
  return doc.edges.map((edge) => ({ ...edge, primary: isMainFlow(edge, byId) }));
}

// 図の文字に日本語（ひらがな・カタカナ・漢字）があるか。lang がないときの、帯の既定の名前の言語に使う。
const JAPANESE = /[ぁ-ヿ一-鿿]/;

/** 帯の名前。lanes に書いた名前、なければ図の言語（lang。なければ図の文字から決める）の既定の名前。 */
export function laneLabels(doc) {
  const lang = doc.lang ?? (JAPANESE.test([doc.title, ...doc.nodes.map((node) => node.label)].join('')) ? 'ja' : 'en');
  const custom = new Map((doc.lanes ?? []).map((lane) => [lane.id, lane.label]));
  return Object.fromEntries(LANES.map((id) => [id, custom.get(id) ?? laneNames[lang][id]]));
}

/** 状態のある帯（上から順）。上段は構造のチェックで必須にしているので、ふつうは先頭にある。 */
export const usedLanes = (doc) => LANES.filter((id) => doc.nodes.some((node) => node.lane === id));

/**
 * 配置を計算する。返り値は { layout, diagnostics }。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutLifecycle(doc) {
  const edges = flowEdges(doc);
  const lanes = usedLanes(doc);
  const labels = laneLabels(doc);
  const rowOf = new Map(lanes.map((id, i) => [id, i]));
  const placed = doc.nodes.map((node) => ({ ...node, row: rowOf.get(node.lane) }));
  const grid = buildGrid(placed);
  const { routes, diagnostics } = routeEdges(edges, grid, { sibling: isSibling });
  const runsByEdge = routes.map((route) => (route ? buildRuns(route, grid) : null));
  const buckets = assignLanes(runsByEdge, sharedVertices(edges, routes, sameStyle), pairOrders(routes));
  // 幹を重ねた兄弟の線のラベルは、幹から分かれた後の部分に置く（幹の上だと、どの線のラベルか分からないため。決定記録 No.98）。
  const edgeLabels = chooseLabels(edges, runsByEdge, { avoidSharedPart: true });
  const labelRuns = edgeLabels.map((label) => label?.run ?? null);
  const labelAnchors = edgeLabels.map((label) => label?.anchor ?? null);
  const laneWidths = placeLanes(buckets, edgeLabels, edges);

  const x = createAxis(grid.cols, METRICS.gutter.oddInset);
  const y = createAxis(grid.rows, METRICS.gutter.oddInset);
  sizeGrid({
    grid, edges, runsByEdge, labelRuns, labelAnchors, laneWidths, x, y,
    gutter: METRICS.gutter, sizeOf: (node) => nodeSize(node, STATE_STYLE), labelMargin: METRICS.labelMargin,
  });
  const X = evaluate(x);
  const Y = evaluate(y);

  // 帯の見出しの分だけ、図を右にずらす。
  const thickness = headerThickness(lanes.map((id) => labels[id]), 'y');
  const shift = { x: round(thickness), y: 0 };
  const at = { x: (spec) => round(X.at(spec)) + shift.x, y: (spec) => round(Y.at(spec)) + shift.y };
  const width = round(X.total) + shift.x;
  const height = round(Y.total) + shift.y;

  const nodes = placed.map((node) => {
    const box = grid.byId.get(node.id);
    const left = at.x(border(box.a, 1));
    const top = at.y(border(box.c, 1));
    return {
      id: node.id,
      kind: node.kind,
      label: node.label,
      sublabel: node.sublabel ?? null,
      tag: node.tag ?? null,
      lane: node.lane,
      col: node.col,
      x: left,
      y: top,
      width: at.x(border(box.b, -1)) - left,
      height: at.y(border(box.d, -1)) - top,
      tagBox: null,
    };
  });

  const edgeLayouts = [];
  edges.forEach((edge, i) => {
    const runs = runsByEdge[i];
    if (!runs) return;
    const points = edgePoints(runs, X, Y).map(([px, py]) => [px + shift.x, py + shift.y]);
    const labelRun = labelRuns[i];
    let labelBox = null;
    if (labelRun) {
      const boxWidth = labelWidth(edge.label);
      const boxHeight = METRICS.edge.labelHeight;
      const anchor = labelAnchors[i];
      const across = edgeLabels[i].across ?? 0;
      const cx = labelRun.axis === 'h' ? anchorAt(X, laneWidths.v, anchor) + across : X.at(line(labelRun.line)) + labelRun.offset;
      const cy = labelRun.axis === 'h' ? Y.at(line(labelRun.line)) + labelRun.offset : anchorAt(Y, laneWidths.h, anchor) + across;
      labelBox = {
        x: round(cx - boxWidth / 2) + shift.x, y: round(cy - boxHeight / 2) + shift.y, width: boxWidth, height: boxHeight,
      };
    }
    edgeLayouts.push({
      id: edge.id ?? null,
      from: edge.from,
      to: edge.to,
      label: edge.label ?? null,
      primary: edge.primary,
      points,
      labelBox,
    });
  });

  // 札は右上に置き、上から入る（出る）線の端に重なるときは、上の辺に沿って動かす（dataflow と同じ。決定記録 No.94）。
  // 上の辺の箱の幅の中に置けないとき（上段との往復の線が2本着く中段の状態など）は、下の辺に置く（決定記録 No.98）。
  const ends = edgeLayouts.flatMap((edge) => [edge.points[0], edge.points.at(-1)]);
  for (const node of nodes) if (node.tag) node.tagBox = tagBoxAvoiding(node, ends, { bottom: true });

  // 帯：図の幅いっぱいに伸び、縦は、その帯の升目の縁（格子の線）の間を占める。いちばん上と下の帯は、図の端まで伸ばす。
  const items = lanes.map((id) => ({ id, label: labels[id] }));
  const spans = lanes.map((id) => gridSpan(grid.boxes.filter((box) => box.node.lane === id), 'y'));
  const laneBands = fillBands(items, spans, 'y', { at, offset: shift, thickness, width, height });

  return {
    layout: { width, height, header: shift, nodes, edges: edgeLayouts, lanes: laneBands },
    diagnostics,
  };
}
