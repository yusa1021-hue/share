// lifecycle の文言（日英）：凡例の線の種類の名前と、診断のメッセージ。診断の形は core/messages.mjs と同じ。
// 状態の種類と帯の名前は states.mjs にある。id/duplicate・text/too-long のメッセージは core/messages.mjs にある。
// schema/invalid は core/messages.mjs のものを使い、lifecycle で書けない項目（primary・async など）にだけ説明を足す。

import { formatPath, joinList } from '../../core/i18n.mjs';
import { coreMessages } from '../../core/messages.mjs';
import { laneNames, stateNames } from './states.mjs';

// 凡例に出す、線の種類の名前。
export const styleNames = {
  ja: { primary: '主な流れ' },
  en: { primary: 'Main flow' },
};

// 線の呼び方（「a」→「b」の線）。
const edgeName = (e, lang) => (lang === 'ja' ? `「${e.from}」→「${e.to}」の線` : `the edge "${e.from}" → "${e.to}"`);
const capitalize = (text) => text.replace(/^t/, 'T');

// ラベルと重なっているもの。
const overlapName = (item, lang) => {
  if (item.kind === 'node') return lang === 'ja' ? `状態「${item.id}」` : `state "${item.id}"`;
  if (item.kind === 'lane') return lang === 'ja' ? `帯「${laneNames.ja[item.id]}」の見出し` : `the header of the lane "${item.id}"`;
  if (item.kind === 'label') return lang === 'ja' ? `${edgeName(item, 'ja')}のラベル` : `the label of ${edgeName(item, 'en')}`;
  return edgeName(item, lang);
};

const stateName = (d, lang) => (lang === 'ja' ? `状態「${d.label}」（${stateNames.ja[d.kind]}）` : `the state "${d.label}" (${stateNames.en[d.kind]})`);
const laneName = (id, lang) => (lang === 'ja' ? `${laneNames.ja[id]}（${id}）` : `${id} (${laneNames.en[id]})`);

// lifecycle では書けない項目と、その理由。schema/invalid（定義されていない項目）に足す。
const UNSUPPORTED = {
  primary: {
    ja: '主な流れはプログラムが決める（上段の状態から、上段のより右の状態へ向かう線を太く描く）。この項目を消す',
    en: 'The main flow is decided automatically (edges from a main-lane state to a state further right in the main lane are drawn bold). Remove this field',
  },
  async: {
    ja: '状態の移り変わりに、線の種類はない。この項目を消し、「時間切れで移る」などはラベル（label）に書く',
    en: 'Transitions have no line styles. Remove this field and describe how it happens (e.g. "timeout") in the label',
  },
  direction: {
    ja: '流れは左から右だけ。この項目を消す',
    en: 'The flow always runs left to right. Remove this field',
  },
  step: {
    ja: '状態の位置は、帯（lane）と列（col）で書く。step を col に直す',
    en: 'A state is placed by its lane and column (col). Rename step to col',
  },
};
const unsupported = (d) => (d.keyword === 'additionalProperties' ? UNSUPPORTED[d.property] : undefined);

export const lifecycleMessages = {
  'schema/invalid': {
    ja: {
      message: (d) => coreMessages['schema/invalid'].ja.message(d),
      fixes: (d) => (unsupported(d) ? [unsupported(d).ja] : coreMessages['schema/invalid'].ja.fixes(d)),
    },
    en: {
      message: (d) => coreMessages['schema/invalid'].en.message(d),
      fixes: (d) => (unsupported(d) ? [unsupported(d).en] : coreMessages['schema/invalid'].en.fixes(d)),
    },
  },
  'ref/unknown': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の「${d.value}」という状態はありません`,
      fixes: (d) => [
        ...(d.suggestion ? [`「${d.suggestion}」の書き間違いなら直す`] : []),
        `ID「${d.value}」の状態を nodes に追加する`,
      ],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')}: there is no state "${d.value}"`,
      fixes: (d) => [
        ...(d.suggestion ? [`If this is a typo for "${d.suggestion}", fix it`] : []),
        `Add a state with the ID "${d.value}" to nodes`,
      ],
    },
  },
  'lane/main-empty': {
    ja: {
      message: () => '上段（main：主な局面）に、状態が1つもありません',
      fixes: (d) => [
        `うまくいったときに通る状態を、lane を "main" にして、col 0 から順に並べる${d.first ? `（たとえば「${d.first}」）` : ''}`,
        '中段（detour）は途中の待ち・やり直し、下段（end）は主な流れ以外の終わり方に使う',
      ],
    },
    en: {
      message: () => 'The main lane (main phases) has no states',
      fixes: (d) => [
        `Put the states of the successful path in lane "main", from col 0 to the right${d.first ? ` (for example, "${d.first}")` : ''}`,
        'Use detour for waits and retries along the way, and end for endings other than the main one',
      ],
    },
  },
  'layout/overlap': {
    ja: {
      message: (d) => `${laneName(d.lane, 'ja')}の列 ${d.col} に、${joinList(d.ids.map((id) => `「${id}」`), 'ja')}が重なっています`,
      fixes: (d) => [
        ...(d.free !== undefined ? [`どちらかの col を ${d.free} に変える`] : []),
        '1つの帯は1行なので、同じ帯の状態は列をずらして横に並べる',
        '別の帯に置く状態なら、lane を直す',
      ],
    },
    en: {
      message: (d) => `Column ${d.col} of lane ${laneName(d.lane, 'en')} has more than one state: ${joinList(d.ids.map((id) => `"${id}"`), 'en')}`,
      fixes: (d) => [
        ...(d.free !== undefined ? [`Change the col of one of them to ${d.free}`] : []),
        'Each lane is a single row: place states of the same lane side by side in different columns',
        'If one of them belongs to another lane, fix its lane',
      ],
    },
  },
  'edge/self-loop': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線は、状態「${d.label}」から自分へ戻っています（自分へ戻る線は描けません）`,
      fixes: () => [
        'やり直しの間の状態（「再試行待ち」など）を中段（detour）に置き、そこへ行く線と、そこから戻る線にする',
        '同じ状態のまま繰り返すだけなら、線を消し、状態の補足（sublabel）か札（tag）に書く（「3回まで再試行」など）',
      ],
    },
    en: {
      message: (d) => `The edge at ${formatPath(d.path, 'en')} leaves and returns to the same state "${d.label}" (self-loops cannot be drawn)`,
      fixes: () => [
        'Add an in-between state (such as "Waiting to retry") in the detour lane, with an edge to it and an edge back',
        'If the state simply repeats, remove the edge and mention it in the sublabel or tag (such as "up to 3 retries")',
      ],
    },
  },
  'edge/duplicate': {
    ja: {
      message: (d) => `「${d.from}」から「${d.to}」への線が${d.paths.length}本あります`,
      fixes: (d) => [`線は重なって1本に見えるので、1本にまとめ、label に両方のきっかけを書く${d.labels.length > 1 ? `（「${d.labels.join('・')}」など）` : ''}`],
    },
    en: {
      message: (d) => `There are ${d.paths.length} edges from "${d.from}" to "${d.to}"`,
      fixes: (d) => [`They would be drawn on top of each other: merge them into one edge and put both triggers in its label${d.labels.length > 1 ? ` (such as "${d.labels.join(', ')}")` : ''}`],
    },
  },
  'edge/unlabeled': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')}（${edgeName(d, 'ja')}）は主な流れから外れる線ですが、ラベルがありません`,
      fixes: () => ['移り変わるきっかけ（「在庫なし」「入金」「期限切れ」など）を label に書く'],
    },
    en: {
      message: (d) => `${capitalize(edgeName(d, 'en'))} at ${formatPath(d.path, 'en')} leaves the main flow but has no label`,
      fixes: () => ['Put what triggers the transition in its label (such as "Out of stock", "Paid", "Timed out")'],
    },
  },
  'flow/no-start': {
    ja: {
      message: () => '始まりの状態（kind が start のもの）がありません',
      fixes: (d) => [...(d.first ? [`上段のいちばん左の状態「${d.first}」の kind を start にする`] : []), '始まりの状態を足す（「受付」「下書き」など）'],
    },
    en: {
      message: () => 'The diagram has no start state (kind "start")',
      fixes: (d) => [...(d.first ? [`Set the kind of the leftmost main state "${d.first}" to start`] : []), 'Add a state where it begins (such as "Received" or "Draft")'],
    },
  },
  'flow/no-end': {
    ja: {
      message: () => '終わりの状態（kind が success・failure・neutral のもの）がありません',
      fixes: (d) => [
        ...(d.last ? [`上段のいちばん右の状態「${d.last}」がうまくいった終わりなら、kind を success にする`] : []),
        '終わり方（完了・失敗・取り消しなど）の状態を足す',
      ],
    },
    en: {
      message: () => 'The diagram has no ending state (kind "success", "failure" or "neutral")',
      fixes: (d) => [
        ...(d.last ? [`If the rightmost main state "${d.last}" is the successful end, set its kind to success`] : []),
        'Add states for how it ends (completed, failed, cancelled, ...)',
      ],
    },
  },
  'flow/unreachable': {
    ja: {
      message: (d) => `${stateName(d, 'ja')}に、入ってくる線がありません`,
      fixes: () => ['どの状態からここへ移るかの線を足す', 'この状態が始まりなら、kind を start にする', '使わない状態なら消す'],
    },
    en: {
      message: (d) => `${capitalize(stateName(d, 'en'))} has no incoming edge`,
      fixes: () => ['Add an edge from the state it comes from', 'If it is where everything begins, set its kind to start', 'Remove it if it is not used'],
    },
  },
  'flow/dead-end': {
    ja: {
      message: (d) => (d.lane === 'detour'
        ? `${stateName(d, 'ja')}は中段（待ち・やり直し）にありますが、出ていく線がありません`
        : `${stateName(d, 'ja')}から、出ていく線がありません`),
      fixes: (d) => (d.lane === 'detour'
        ? ['戻る先（上段の状態）への線か、終わり方（下段の状態）への線を足す', 'ここで終わるなら、下段（lane を "end"）に移す']
        : ['次の状態への線を足す', 'ここで終わるなら、kind を success・failure・neutral のどれかにするか、下段（lane を "end"）に移す']),
    },
    en: {
      message: (d) => (d.lane === 'detour'
        ? `${capitalize(stateName(d, 'en'))} is in the detour lane but has no outgoing edge`
        : `${capitalize(stateName(d, 'en'))} has no outgoing edge`),
      fixes: (d) => (d.lane === 'detour'
        ? ['Add an edge back to a main state, or to an ending in the end lane', 'If it ends here, move it to the end lane (lane "end")']
        : ['Add an edge to the next state', 'If it ends here, set its kind to success, failure or neutral, or move it to the end lane (lane "end")']),
    },
  },
  'flow/exit-from-end': {
    ja: {
      message: (d) => `${stateName(d, 'ja')}は下段（終わり方）にありますが、出ていく線があります`,
      fixes: (d) => [
        `この後も続くなら、中段に移す（lane を "detour"${d.free !== null && d.free !== undefined ? `、col を ${d.free}` : ''} にする）`,
        '終わりなら、この状態から出る線を消す',
      ],
    },
    en: {
      message: (d) => `${capitalize(stateName(d, 'en'))} is in the end lane but has an outgoing edge`,
      fixes: (d) => [
        `If it continues, move it to the detour lane (lane "detour"${d.free !== null && d.free !== undefined ? `, col ${d.free}` : ''})`,
        'If it is an ending, remove its outgoing edges',
      ],
    },
  },
  'size/too-many-nodes': {
    ja: {
      message: (d) => `状態が${d.count}個あります。${d.limit}個を超えると読みにくくなります`,
      fixes: () => ['読む人が知りたい主な局面・待ち・終わり方に絞る（細かい状態はまとめる）', '図を2つに分ける（前半と後半など）'],
    },
    en: {
      message: (d) => `The diagram has ${d.count} states; more than ${d.limit} makes it hard to read`,
      fixes: () => ['Keep the main phases, waits and endings that readers need, and merge minor states', 'Split the diagram into two (for example, the first and second half)'],
    },
  },
  'edge/no-route': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の線（「${d.from}」→「${d.to}」）の通り道が見つかりません`,
      fixes: () => ['fromSide・toSide の指定を外すか、別の辺にする', '周りの状態の列（col）を変えて、通り道を空ける'],
    },
    en: {
      message: (d) => `No route was found for the edge at ${formatPath(d.path, 'en')} ("${d.from}" → "${d.to}")`,
      fixes: () => ['Remove fromSide/toSide or choose another side', 'Change the columns of the surrounding states to open a path'],
    },
  },
  'edge/label-overlap': {
    ja: {
      message: (d) => `${edgeName(d, 'ja')}のラベル「${d.label}」が、${joinList(d.overlaps.map((item) => overlapName(item, 'ja')), 'ja')}と重なっています`,
      fixes: () => [
        'ラベルを短くする。主な流れの線なら、ラベルを消してもよい',
        '重なっている線の端の状態を、別の列（col）に移す',
      ],
    },
    en: {
      message: (d) => `The label "${d.label}" of ${edgeName(d, 'en')} overlaps ${joinList(d.overlaps.map((item) => overlapName(item, 'en')), 'en')}`,
      fixes: () => [
        'Shorten the label; on a main-flow edge you may remove it',
        'Move an end state of the overlapping edge to another column (col)',
      ],
    },
  },
  'edge/crossing': {
    ja: {
      message: (d) => `${edgeName(d.first, 'ja')}と${edgeName(d.second, 'ja')}が交差しています（${d.count}か所）`,
      fixes: () => [
        '中段・下段の状態を、そこへ分かれる元の状態と同じ列（col）に置く',
        'どちらかの線の端の状態を、もう一方の線をまたがずにつながる列に移す',
      ],
    },
    en: {
      message: (d) => `${capitalize(edgeName(d.first, 'en'))} crosses ${edgeName(d.second, 'en')} (${d.count} ${d.count === 1 ? 'time' : 'times'})`,
      fixes: () => [
        'Place detour and end states in the same column (col) as the state they branch from',
        'Move an end state of one edge to a column where it can connect without crossing the other edge',
      ],
    },
  },
  'size/too-wide': {
    ja: {
      message: (d) => `図の幅が ${d.width}px あります（列 ${d.columns}）。指定の ${d.limit}px を超えています`,
      fixes: () => [
        '主な局面を減らす（続けて起きる状態を1つにまとめる）',
        '中段・下段の状態を、上段の状態の下の列にそろえ、上段より右に出さない',
        '長い名前・補足・線のラベルを短くする',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.width}px wide (${d.columns} columns), which exceeds the requested ${d.limit}px`,
      fixes: () => [
        'Use fewer main phases (merge states that always follow each other)',
        'Keep detour and end states under the main states instead of further right',
        'Shorten long labels, sublabels, and edge labels',
      ],
    },
  },
  'size/too-tall': {
    ja: {
      message: (d) => `図の高さが ${d.height}px あります（帯 ${d.lanes} つ）。指定の ${d.limit}px を超えています`,
      fixes: () => ['補足（sublabel）を省くと、その帯が低くなる', '中段の待ち・やり直しのうち、読む人に要らないものを省く'],
    },
    en: {
      message: (d) => `The diagram is ${d.height}px tall (${d.lanes} lanes), which exceeds the requested ${d.limit}px`,
      fixes: () => ['Leave out sublabels to make their lanes lower', 'Leave out waits and retries that readers do not need'],
    },
  },
};
