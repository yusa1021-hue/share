// lifecycle の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/lifecycle.md の「3. 描きかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは core/draw.mjs の diagramStyles() と、下の lifecycleStyles()（状態の種類の色は states.mjs）で行う。
// 状態の箱・線・鏃・角の丸め・帯は、ほかの図の種類と共通のもの（core/）を使う。

import { bandHeaderStrips, bandRule, fillBandElement } from '../../core/bands.mjs';
import { BASE_COLORS, EDGE_DRAW, edgeElement, edgeLabelElement, findHops, lineSample, sampleSvg } from '../../core/draw.mjs';
import { nodeElement } from '../../core/node.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY } from '../../core/text.mjs';
import { METRICS } from './layout.mjs';
import { STATE_STYLE, stateStyles } from './states.mjs';

// ---- 凡例の見本 ------------------------------------------------------------------

/** 凡例に出す、主な流れの線の見本。図と同じクラスを付け、色はテーマの CSS で決まる。 */
export function mainFlowSample() {
  return sampleSvg(lineSample({
    classes: ['lt-primary'],
    width: EDGE_DRAW.primaryWidth,
    color: BASE_COLORS.light.edgeStrong,
    arrow: { length: 8.5, width: 9 },
  }));
}

// ---- 図 ----------------------------------------------------------------------

/**
 * 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。
 * つながりの強調（viewer/highlight.mjs）のため、状態には data-node（ID）を、線とそのラベルには
 * data-edge（edges の中の番号）・data-from・data-to を付ける。
 */
export function renderLifecycle(layout, doc) {
  const base = BASE_COLORS.light;
  const hops = findHops(layout.edges);
  // 帯は行の帯（core/bands.mjs）。見出しは左端に置く。
  const frame = { width: layout.width, height: layout.height, offset: layout.header };
  // 主な流れの線を後から描き、ほかの線より上に見えるようにする。
  const order = layout.edges.map((edge, i) => i).sort((p, q) => Number(layout.edges[p].primary) - Number(layout.edges[q].primary) || p - q);
  return el('svg', {
    class: 'lt-diagram lt-lifecycle',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    bandHeaderStrips(['y'], frame, base),
    el('g', { class: 'lt-lanes' }, layout.lanes.map((lane, i) => fillBandElement(lane, i, 'y', { name: 'lt-lane', base }))),
    // 見出しと本体の境目の線は、帯の色の上に描く（色を敷いた帯に隠れないように）。
    bandRule(['y'], frame, base),
    el('g', { class: 'lt-edges' }, order.map((i) => edgeElement(layout.edges[i], i, hops[i], base))),
    el('g', { class: 'lt-edge-labels' }, order.filter((i) => layout.edges[i].labelBox)
      .map((i) => edgeLabelElement(layout.edges[i], i, base, METRICS.edge.labelSize))),
    el('g', { class: 'lt-nodes' }, layout.nodes.map((node) => nodeElement(node, { 'data-id': node.id, 'data-node': node.id }, STATE_STYLE))),
  ]);
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、lifecycle だけのもの（状態の種類の色・主な流れ）。
 * 図の色の変数と、箱・線・帯に共通の部分は core/draw.mjs の diagramStyles() で決める。
 */
export function lifecycleStyles(options = {}) {
  return [
    stateStyles(options),
    '.lt-primary .lt-edge-line{stroke:var(--lt-edge-strong)}',
    '.lt-primary .lt-arrow{fill:var(--lt-edge-strong)}',
  ].join('\n');
}
