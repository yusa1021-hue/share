// 状態の種類（lifecycle だけで使う）：7種類の一覧・色・記号・名前・意味の近い語。
// 仕様：docs/latticery/types/lifecycle.md の「kind（状態の種類）」（決定記録 No.96・No.97）
//
// 色は、部品の種類（core/kinds.mjs）と同じ作り方の8つの色の組から、状態の意味に合わせて選ぶ
// （始まり＝青緑、進行中＝青、待ち＝橙、判定＝紫、成功＝緑、失敗＝赤、そのほかの終わり＝灰）。
// 形はすべて四角（core/node.mjs）。終わりかどうかは、形ではなく帯（下段）と色で表す。

import { KIND_COLORS } from '../../core/kinds.mjs';
import { STEP_ICON_SHAPES } from '../../core/steps.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';

// 記号の大きさ（px）と線の太さ（16×16 の座標での値）。部品の種類と同じ。
export const STATE_ICON = { size: 14, stroke: 1.6 };

// 状態の種類ごとの色：[塗り, 枠線, 記号の色]。部品の種類の色の組をそのまま使う。
export const STATE_COLORS = {
  start: KIND_COLORS.infra,
  active: KIND_COLORS.service,
  waiting: KIND_COLORS.queue,
  decision: KIND_COLORS.client,
  success: KIND_COLORS.datastore,
  failure: KIND_COLORS.security,
  neutral: KIND_COLORS.external,
};

// 状態の種類ごとの記号。16×16 の座標に、塗りのない線で描く。始まり・待ち・成功は、workflow の手順の記号と同じ形。
const ICONS = {
  start: STEP_ICON_SHAPES.start,
  active: [
    ['path', { d: 'M13.5 8a5.5 5.5 0 1 1-1.6-3.9' }],
    ['path', { d: 'M12.2 1.6v2.8H9.4' }],
  ],
  waiting: STEP_ICON_SHAPES.wait,
  decision: [
    ['path', { d: 'M8 1.5L14.5 8 8 14.5 1.5 8z' }],
  ],
  success: STEP_ICON_SHAPES.end,
  failure: [
    ['circle', { cx: 8, cy: 8, r: 6.5 }],
    ['path', { d: 'M5.6 5.6l4.8 4.8M10.4 5.6l-4.8 4.8' }],
  ],
  neutral: [
    ['circle', { cx: 8, cy: 8, r: 6.5 }],
    ['path', { d: 'M5 8h6' }],
  ],
};

export const STATE_KINDS = Object.keys(ICONS);

// 帯の ID（上から並べる順）と、終わりの種類。
export const LANES = ['main', 'detour', 'end'];
export const ENDINGS = new Set(['success', 'failure', 'neutral']);

/** 状態の種類の記号。左上を (x, y) にして、size の大きさで描く。凡例や説明カードでも使う。 */
export function stateIcon(kind, { x = 0, y = 0, size = STATE_ICON.size } = {}) {
  return el('g', {
    class: 'lt-icon',
    transform: `translate(${n(x)} ${n(y)}) scale(${n(size / 16)})`,
    fill: 'none',
    stroke: STATE_COLORS[kind].light[2],
    'stroke-width': STATE_ICON.stroke,
    'stroke-linecap': 'round',
    'stroke-linejoin': 'round',
  }, ICONS[kind].map(([tag, attrs]) => el(tag, attrs)));
}

// 凡例と説明カードに出す、状態の種類の名前。
export const stateNames = {
  ja: {
    start: '始まり', active: '進行中', waiting: '待ち', decision: '判定',
    success: '成功', failure: '失敗', neutral: 'そのほかの終わり',
  },
  en: {
    start: 'Start', active: 'In progress', waiting: 'Waiting', decision: 'Decision',
    success: 'Success', failure: 'Failure', neutral: 'Other ending',
  },
};

// 帯の既定の名前。lanes に書けば変えられる。
export const laneNames = {
  ja: { main: '主な局面', detour: '待ち・やり直し', end: '終わり方' },
  en: { main: 'Main phases', detour: 'Waits & retries', end: 'Outcomes' },
};

// 箱の描き方（core/node.mjs に渡すもの）。色・クラス・記号を状態の種類のものにする。形はすべて四角。
export const STATE_STYLE = {
  colors: STATE_COLORS,
  className: (kind) => `lt-state-${kind}`,
  icon: stateIcon,
  hasIcon: () => true,
  shape: () => 'box',
};

/**
 * 状態の種類の色を決める CSS。core/draw.mjs の diagramStyles() と同じ作りで、.lt-state-<種類> に変数を入れる。
 * 変数の名前は部品の種類と同じなので、箱・記号・文字の CSS はそのまま使える。凡例と説明カードの印にも使う。
 */
export function stateStyles({ dark = '[data-theme="dark"]' } = {}) {
  const vars = ([fill, border, accent]) => `--lt-fill:${fill};--lt-border:${border};--lt-accent:${accent}`;
  return [
    ...STATE_KINDS.map((kind) => `.lt-state-${kind}{${vars(STATE_COLORS[kind].light)}}`),
    ...STATE_KINDS.map((kind) => `${dark} .lt-state-${kind}{${vars(STATE_COLORS[kind].dark)}}`),
  ].join('\n');
}

// 使えない値から、意味の近い値への対応（schema/invalid の直し方の候補に使う）。
// キーは値、値はその値に当たる語。語は小文字にして、英数字以外を除いた形で書く。帯の ID の語も入れる。
export const STATE_SYNONYMS = {
  start: ['begin', 'initial', 'init', 'new', 'created', 'draft', 'entry', 'queued', 'submitted', 'received', 'open'],
  active: ['running', 'processing', 'inprogress', 'progress', 'working', 'executing', 'ongoing', 'task', 'system', 'process', 'busy'],
  waiting: ['wait', 'pending', 'hold', 'onhold', 'paused', 'pause', 'blocked', 'suspended', 'idle', 'queue'],
  decision: ['review', 'reviewing', 'check', 'checking', 'verify', 'verifying', 'gate', 'judge', 'approval', 'inspection', 'validating'],
  success: ['done', 'complete', 'completed', 'finished', 'succeeded', 'ok', 'approved', 'end', 'final', 'resolved', 'delivered', 'live'],
  failure: ['fail', 'failed', 'error', 'rejected', 'denied', 'aborted', 'exception', 'crashed'],
  neutral: ['cancel', 'cancelled', 'canceled', 'expired', 'archived', 'closed', 'terminated', 'other', 'withdrawn', 'skipped', 'external'],
  main: ['phase', 'phases', 'primary', 'happy', 'rail', 'top', 'mainline', 'normal'],
  detour: ['side', 'wait', 'waiting', 'exception', 'exceptions', 'recovery', 'retry', 'middle', 'interrupt', 'interruptions', 'event', 'events', 'branch'],
  end: ['terminal', 'outcome', 'outcomes', 'exit', 'exits', 'bottom', 'final', 'ending', 'endings', 'result'],
};
