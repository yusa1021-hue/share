// sequence のチェック。仕様：docs/latticery/types/sequence.md の「4. チェック」
// checkSequence：構造のチェック。スキーマ検証を通った図に対して、配置を計算しなくても分かる問題を調べる。
// inspectSequence：見た目のチェック。配置の計算の結果（layout.mjs の layoutSequence が返す layout）を使う。
// 位置と大きさは順番から計算するので、重なりや交差のチェックはない（決定記録 No.71）。

import { duplicateIds, longTexts, oversize } from '../../core/checks.mjs';
import { closest, error, synonymIndex, warning } from '../../core/diagnostics.mjs';
import { KIND_SYNONYMS } from '../../core/kinds.mjs';
import { SHAPES, messagesOf, shapesOf, walkSteps } from './layout.mjs';

export const MAX_BLOCK_DEPTH = 3;
export const PARTICIPANT_COUNT_GUIDELINE = 10;
export const MESSAGE_COUNT_GUIDELINE = 30;

// 使えない値から、意味の近い使える値への対応（schema/invalid の直し方の候補に使う）。
// 参加者の種類（kind）は core/kinds.mjs の語を使い、ブロックの種類（block）の語だけをここで決める。
export const VALUE_SYNONYMS = synonymIndex({
  ...KIND_SYNONYMS,
  alt: ['if', 'else', 'switch', 'branch'],
  loop: ['for', 'while', 'repeat', 'retry'],
  opt: ['optional', 'option', 'ifexists'],
});

// 表示幅の目安（半角1・全角2で数える）。
const TEXT_GUIDELINES = {
  participantLabel: 24,
  participantSublabel: 32,
  messageLabel: 32,
  note: 40,
  blockLabel: 32,
};

// メッセージの対象（始点と終点の参加者）。
const messageTarget = (step) => [step.from, step.to].filter((id) => typeof id === 'string');

export function checkSequence(doc) {
  const steps = [];
  walkSteps(doc.steps, (step, place) => steps.push({ step, ...place }));
  const messages = messagesOf(doc);
  return [
    ...duplicateIds(doc.participants.map((p, i) => ({ id: p.id, path: `/participants/${i}/id` }))),
    ...checkReferences(doc.participants, steps),
    ...checkShapes(steps),
    ...checkDepth(steps),
    ...checkUnused(doc.participants, messages),
    ...checkReplies(messages),
    ...checkTextLength(doc.participants, steps),
    ...checkCounts(doc.participants, messages),
  ];
}

function checkReferences(participants, steps) {
  const ids = participants.map((p) => p.id);
  const known = new Set(ids);
  const problems = [];
  const verify = (value, path, target) => {
    if (typeof value !== 'string' || known.has(value)) return;
    const detail = { path, value };
    const suggestion = closest(value, ids);
    if (suggestion) detail.suggestion = suggestion;
    problems.push(error('ref/unknown', { target, detail }));
  };
  for (const { step, path } of steps) {
    verify(step.from, `${path}/from`, messageTarget(step));
    verify(step.to, `${path}/to`, messageTarget(step));
    (Array.isArray(step.over) ? step.over : []).forEach((id, k) => verify(id, `${path}/over/${k}`, step.over));
  }
  return problems;
}

// 形の決まり（仕様「形の決まり」）。1つのステップに1件だけ出し、形・足りない項目・使えない項目を detail に入れる。
function checkShapes(steps) {
  const problems = [];
  for (const { step, path } of steps) {
    const fields = Object.keys(step);
    const shapes = shapesOf(step);
    if (shapes.length !== 1) {
      problems.push(error('step/shape', { target: messageTarget(step), detail: { path, shapes, fields } }));
      continue;
    }
    const [shape] = shapes;
    const { required, allowed } = SHAPES[shape];
    const missing = required.filter((field) => !Object.hasOwn(step, field));
    const extra = fields.filter((field) => !allowed.includes(field));
    // else が使えるのは alt だけ。
    if (shape === 'block' && Object.hasOwn(step, 'else') && step.block !== 'alt' && Object.hasOwn(step, 'block')) extra.push('else');
    if (missing.length > 0 || extra.length > 0) {
      const detail = { path, shapes, fields, missing, extra };
      if (extra.includes('else')) detail.block = step.block;
      problems.push(error('step/shape', { target: messageTarget(step), detail }));
    }
  }
  return problems;
}

// 上限を超えた最初の段だけを報告する（さらに深い段まで報告すると、同じ問題が重なって見えるため）。
function checkDepth(steps) {
  return steps
    .filter(({ shape, depth }) => shape === 'block' && depth === MAX_BLOCK_DEPTH)
    .map(({ path }) => error('block/too-deep', { detail: { path, limit: MAX_BLOCK_DEPTH } }));
}

// どのメッセージにも出てこない参加者（注記の over にだけ出てくる参加者も含む）。
function checkUnused(participants, messages) {
  const used = new Set(messages.flatMap(({ step }) => [step.from, step.to]));
  return participants
    .filter((p) => !used.has(p.id))
    .map((p) => warning('participant/unused', { target: [p.id], detail: { id: p.id } }));
}

// 返答の前に、逆向きの（返答でない）メッセージがない。返答の向きの取り違えを見つけるため。
function checkReplies(messages) {
  const problems = [];
  const calls = new Set();
  for (const { step, path } of messages) {
    if (step.reply) {
      if (!calls.has(`${step.to} ${step.from}`)) {
        problems.push(warning('message/reply-without-call', { target: messageTarget(step), detail: { path, from: step.from, to: step.to } }));
      }
    } else {
      calls.add(`${step.from} ${step.to}`);
    }
  }
  return problems;
}

function checkTextLength(participants, steps) {
  const g = TEXT_GUIDELINES;
  return longTexts([
    ...participants.flatMap((p, i) => [
      { text: p.label, path: `/participants/${i}/label`, limit: g.participantLabel, target: [p.id] },
      { text: p.sublabel, path: `/participants/${i}/sublabel`, limit: g.participantSublabel, target: [p.id] },
    ]),
    ...steps.flatMap(({ step, path, shape }) => {
      if (shape === 'message') return [{ text: step.label, path: `${path}/label`, limit: g.messageLabel, target: messageTarget(step) }];
      if (shape === 'note') return [{ text: step.note, path: `${path}/note`, limit: g.note, target: Array.isArray(step.over) ? step.over : [] }];
      if (shape === 'block') {
        return [
          { text: step.label, path: `${path}/label`, limit: g.blockLabel, target: [] },
          ...(step.else ?? []).map((branch, k) => ({ text: branch.label, path: `${path}/else/${k}/label`, limit: g.blockLabel, target: [] })),
        ];
      }
      return [];
    }),
  ]);
}

function checkCounts(participants, messages) {
  const problems = [];
  if (participants.length > PARTICIPANT_COUNT_GUIDELINE) {
    problems.push(warning('size/too-many-participants', { detail: { count: participants.length, limit: PARTICIPANT_COUNT_GUIDELINE } }));
  }
  if (messages.length > MESSAGE_COUNT_GUIDELINE) {
    problems.push(warning('size/too-many-messages', { detail: { count: messages.length, limit: MESSAGE_COUNT_GUIDELINE } }));
  }
  return problems;
}

// ---- 見た目のチェック -----------------------------------------------------------

// limits は、利用者が図の大きさを指定したときの上限（{ maxWidth, maxHeight }。px）。指定がなければ、大きさは判定しない。
// 参加者の数とメッセージの数を、直し方の手がかりとして detail に入れる。
export function inspectSequence(doc, layout, limits = {}) {
  return oversize(layout, limits, {
    width: { participants: doc.participants.length },
    height: { messages: messagesOf(doc).length },
  });
}
