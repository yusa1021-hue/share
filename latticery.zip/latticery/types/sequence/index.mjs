// 図の種類「sequence」の定義。core/check.mjs に渡して使う。

import { KINDS, iconElement, kindLegend } from '../../core/kinds.mjs';
import { createValidator } from '../../core/schema.mjs';
import { VALUE_SYNONYMS, checkSequence, inspectSequence } from './checks.mjs';
import { layoutSequence, messagesOf, walkSteps } from './layout.mjs';
import { sequenceMessages, styleNames } from './messages.mjs';
import { BLOCK_KINDS, LEGEND_STYLES, blockSample, renderSequence, sequenceStyles, styleSample } from './render.mjs';

// schema には types/sequence/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createSequenceType(schema) {
  return {
    name: 'sequence',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkSequence,
    layout: layoutSequence,
    inspect: inspectSequence,
    render: renderSequence,
    styles: sequenceStyles,
    legend: legendItems,
    icon: (kind, options) => (KINDS.includes(kind) ? iconElement(kind, options) : null),
    messages: sequenceMessages,
  };
}

// 凡例の項目。図で使われている参加者の種類・メッセージの種類（呼び出し・返答・非同期）・ブロックの種類だけを、決まった順に並べる。
// 参加者の種類は icon（記号）を、メッセージとブロックの種類は sample（見本の SVG）を返す。
// メッセージの種類は、返答か非同期があるときだけ出す（3通りの線と鏃を見分けるため）。呼び出しだけの図では出さない。
function legendItems(doc, lang) {
  const messages = messagesOf(doc).map(({ step }) => step);
  const blocks = new Set();
  walkSteps(doc.steps, (step, { shape }) => {
    if (shape === 'block') blocks.add(step.block);
  });
  const styles = new Set(messages.map((message) => [message.reply ? 'reply' : null, message.async ? 'async' : null]).flatMap((pair) => {
    const used = pair.filter(Boolean);
    return used.length > 0 ? used : ['call'];
  }));
  if (styles.size === 1 && styles.has('call')) styles.clear();
  return [
    ...kindLegend(new Set(doc.participants.map((p) => p.kind)), lang),
    ...LEGEND_STYLES.filter((style) => styles.has(style)).map((style) => ({ key: style, label: styleNames[lang][style], sample: styleSample(style) })),
    ...BLOCK_KINDS.filter((kind) => blocks.has(kind)).map((kind) => ({ key: kind, label: styleNames[lang][kind], sample: blockSample(kind) })),
  ];
}
