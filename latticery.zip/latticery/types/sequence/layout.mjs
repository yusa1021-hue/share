// sequence の配置の計算。仕様：docs/latticery/types/sequence.md の「3. 描画のしかた」
//
// 1. ステップを上から順にたどり、行ごとの高さを積み上げて、縦の位置を決める（ブロックの見出し・終わり・else の区切りも1行と数える）
// 2. 参加者の箱の幅と、生存線の間に入るもの（メッセージのラベル、自分へのメッセージ、注記）から、生存線の間隔を決める
// 3. 横の位置が決まってから、注記の四角とブロックの四角の範囲を決める
//
// 位置は順番だけで決まるので、配置の計算でエラーは出ない（入力は、スキーマ検証と構造のチェックを通った図であること）。

import { NODE, nodeSize } from '../../core/node.mjs';
import { estimateWidth } from '../../core/text.mjs';

// ---- チェック（checks.mjs）・描画（render.mjs）と共通で使うもの ------------------------

// ステップの3つの形。signals はその形だと分かる項目、required は必須の項目、allowed は使える項目。
// label はメッセージとブロックの両方で使うので、どちらの目印にもしない（仕様「形の決まり」）。
export const SHAPES = {
  message: { signals: ['from', 'to', 'reply', 'async'], required: ['from', 'to'], allowed: ['from', 'to', 'label', 'reply', 'async'] },
  note: { signals: ['note', 'over'], required: ['note', 'over'], allowed: ['note', 'over'] },
  block: { signals: ['block', 'steps', 'else'], required: ['block', 'label', 'steps'], allowed: ['block', 'label', 'steps', 'else'] },
};

/** ステップに書かれた項目から、当てはまる形の名前をすべて返す（ふつうは1つ）。 */
export function shapesOf(step) {
  return Object.keys(SHAPES).filter((shape) => SHAPES[shape].signals.some((field) => Object.hasOwn(step, field)));
}

/**
 * ステップを描く順（上から）にたどり、visit(step, { path, depth, shape }) を呼ぶ。
 * depth は、そのステップを囲むブロックの数。ブロックは、中のステップ、else の場合の中のステップの順にたどる。
 * shape は形がちょうど1つに決まるときの名前（決まらなければ null）。
 */
export function walkSteps(steps, visit, path = '/steps', depth = 0) {
  steps.forEach((step, i) => {
    const here = `${path}/${i}`;
    const shapes = shapesOf(step);
    const shape = shapes.length === 1 ? shapes[0] : null;
    visit(step, { path: here, depth, shape });
    if (shape !== 'block') return;
    if (Array.isArray(step.steps)) walkSteps(step.steps, visit, `${here}/steps`, depth + 1);
    (step.else ?? []).forEach((branch, k) => {
      if (Array.isArray(branch.steps)) walkSteps(branch.steps, visit, `${here}/else/${k}/steps`, depth + 1);
    });
  });
}

/** メッセージを描く順に並べる。返り値は [{ step, path }]。番号（numbered）と、強調の目印の番号はこの順。 */
export function messagesOf(doc) {
  const list = [];
  walkSteps(doc.steps, (step, { path, shape }) => {
    if (shape === 'message') list.push({ step, path });
  });
  return list;
}

// ---- 寸法 --------------------------------------------------------------------

// pad：図の外周の余白。participantGap：隣り合う参加者の箱の間の最小の隙間。lifelineGap：箱とステップの間。
// message：labelSize は文字の大きさ、labelGap はラベルと線の間、labelMargin はラベルと生存線の間の最小の余白、
//   minSpan は線のいちばん短い長さ、above・below は行の上下の余白。
// self：自分へのメッセージの折り返しの幅と高さ。note：注記の文字の大きさ・高さ・余白と、生存線からのはみ出し（overhang）、
//   折った角の大きさ（fold）、隣の生存線との間（clearance）。
// block：pad は中身との余白（入れ子の外側ほど積み重なる）、札（tab）の高さ・余白・切った角、条件の文字の大きさ、
//   headerGap は札と最初の行の間、footer は最後の行と下辺の間、branchGap は else の区切りと条件の間。
export const METRICS = {
  node: NODE, // 参加者の箱の寸法（architecture の部品と共通。core/node.mjs）
  pad: 16,
  participantGap: 24,
  lifelineGap: 14,
  message: { labelSize: 12, labelHeight: 18, labelPaddingX: 6, labelGap: 3, labelMargin: 10, minSpan: 48, above: 4, below: 11 },
  self: { width: 28, height: 20, labelGap: 6 },
  note: { size: 12, height: 26, paddingX: 10, overhang: 16, fold: 8, clearance: 12, margin: 6 },
  block: {
    pad: 10, tabHeight: 20, tabPaddingX: 8, tabCut: 6, kindSize: 11, labelSize: 11, labelHeight: 18, labelPaddingX: 4, labelGap: 4,
    top: 4, headerGap: 6, footer: 6, gap: 6, branchGap: 3,
  },
};

/** ブロックの条件の表示（[ ] で囲む）。 */
export const conditionText = (label) => `[${label}]`;

// ラベルの背景を含めた幅。
const labelWidth = (text, size, paddingX) => estimateWidth(text, size) + 2 * paddingX;
const messageLabelWidth = (text) => labelWidth(text, METRICS.message.labelSize, METRICS.message.labelPaddingX);
const noteTextWidth = (text) => estimateWidth(text, METRICS.note.size);
// ブロックの札（種類の文字）の幅と、条件（[ ] で囲む）の幅。
const tabWidth = (kind) => estimateWidth(kind, METRICS.block.kindSize, { bold: true }) + 2 * METRICS.block.tabPaddingX + METRICS.block.tabCut;
const conditionWidth = (label) => labelWidth(conditionText(label), METRICS.block.labelSize, METRICS.block.labelPaddingX);


// ---- 配置 --------------------------------------------------------------------

/**
 * 配置を計算する。返り値は { layout, diagnostics }（diagnostics は常に空。形は architecture と同じ）。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutSequence(doc) {
  const m = METRICS;
  const index = new Map(doc.participants.map((p, i) => [p.id, i]));
  const sizes = doc.participants.map((p) => nodeSize(p));
  const boxHeight = Math.max(...sizes.map((size) => size.height));

  // 1. 縦の位置。横の位置が要るもの（参加者の番号）は、後で座標にする。
  const rows = { messages: [], notes: [], blocks: [] };
  let y = m.pad + boxHeight + m.lifelineGap;
  let number = 0;
  const place = (steps, depth) => {
    for (const step of steps) {
      const [shape] = shapesOf(step);
      if (shape === 'message') {
        number += 1;
        const text = doc.numbered ? `${number}. ${step.label ?? ''}`.trim() : step.label ?? null;
        const from = index.get(step.from);
        const to = index.get(step.to);
        if (from === to) {
          const top = y + m.message.above + 2;
          rows.messages.push({ step, number, text, from, to, self: true, top });
          y = top + m.self.height + m.message.below;
        } else {
          const lineY = text === null ? y + m.message.above + 6 : y + m.message.above + m.message.labelHeight + m.message.labelGap;
          rows.messages.push({ step, number, text, from, to, self: false, lineY });
          y = lineY + m.message.below;
        }
      } else if (shape === 'note') {
        const over = step.over.map((id) => index.get(id)).sort((p, q) => p - q);
        rows.notes.push({ step, over, y: y + m.note.margin });
        y += m.note.margin + m.note.height + m.note.margin;
      } else {
        const block = { step, depth, top: y + m.block.top, branches: [], items: { messages: [], notes: [], blocks: [] } };
        rows.blocks.push(block);
        const before = snapshot(rows);
        y = block.top + m.block.tabHeight + m.block.headerGap;
        place(step.steps, depth + 1);
        for (const branch of step.else ?? []) {
          const lineY = y + m.block.gap;
          const labelY = branch.label ? lineY + m.block.branchGap : null;
          block.branches.push({ label: branch.label ?? null, lineY, labelY });
          y = (labelY === null ? lineY + 8 : labelY + m.block.labelHeight + 4);
          place(branch.steps, depth + 1);
        }
        block.bottom = y + m.block.footer;
        block.items = since(rows, before);
        y = block.bottom + m.block.gap;
      }
    }
  };
  place(doc.steps, 0);
  const lifelineBottom = y + m.lifelineGap;

  // 2. 生存線の間隔。まず箱の幅から下限を決め、間に入るものが収まるように広げる。
  const count = doc.participants.length;
  const gaps = Array.from({ length: Math.max(count - 1, 0) }, (_, i) => sizes[i].width / 2 + sizes[i + 1].width / 2 + m.participantGap);
  const needs = [];
  let rightNeed = 0; // いちばん右の生存線から右へはみ出す分
  let leftNeed = 0; // いちばん左の生存線から左へはみ出す分
  for (const row of rows.messages) {
    const width = row.text === null ? 0 : messageLabelWidth(row.text);
    if (row.self) {
      const need = m.self.width + m.self.labelGap + width + m.message.labelMargin;
      if (row.from < count - 1) needs.push({ lo: row.from, hi: row.from + 1, need });
      else rightNeed = Math.max(rightNeed, need);
    } else {
      const lo = Math.min(row.from, row.to);
      const hi = Math.max(row.from, row.to);
      needs.push({ lo, hi, need: Math.max(m.message.minSpan, width + 2 * m.message.labelMargin) });
    }
  }
  for (const row of rows.notes) {
    const text = noteTextWidth(row.step.note) + 2 * m.note.paddingX + m.note.fold;
    const [lo, hi] = [row.over[0], row.over.at(-1)];
    if (lo === hi) {
      const half = Math.max(text, 2 * m.note.overhang) / 2;
      row.width = 2 * half;
      if (lo > 0) needs.push({ lo: lo - 1, hi: lo, need: half + m.note.clearance });
      else leftNeed = Math.max(leftNeed, half);
      if (lo < count - 1) needs.push({ lo, hi: lo + 1, need: half + m.note.clearance });
      else rightNeed = Math.max(rightNeed, half);
    } else {
      needs.push({ lo, hi, need: text - 2 * m.note.overhang });
      row.text = text;
    }
  }
  // またぐ間隔の数が少ないものから順に、足りない分を等しく分けて足す。
  needs.sort((p, q) => (p.hi - p.lo) - (q.hi - q.lo));
  for (const { lo, hi, need } of needs) {
    let sum = 0;
    for (let i = lo; i < hi; i += 1) sum += gaps[i];
    if (sum >= need) continue;
    const add = (need - sum) / (hi - lo);
    for (let i = lo; i < hi; i += 1) gaps[i] += add;
  }
  const xs = [sizes[0].width / 2];
  gaps.forEach((gap, i) => xs.push(xs[i] + gap));

  // 3. 座標。まず左端の生存線を 0 として計算し、はみ出す分に合わせて全体を右へずらす。
  const messages = rows.messages.map((row) => messageGeometry(row, xs));
  const notes = rows.notes.map((row) => noteGeometry(row, xs));
  const blocks = rows.blocks.map((block) => ({ block }));
  const extentOf = new Map();
  // 内側のブロックから先に範囲を決める（外側は、内側の四角を囲む）。
  for (const entry of [...blocks].sort((p, q) => q.block.depth - p.block.depth)) {
    entry.geometry = blockGeometry(entry.block, messages, notes, rows, extentOf);
    extentOf.set(entry.block, entry.geometry);
  }
  const participants = doc.participants.map((p, i) => ({ ...p, cx: xs[i], width: sizes[i].width, height: boxHeight }));
  const lefts = [
    ...participants.map((p) => p.cx - p.width / 2),
    ...messages.map((msg) => msg.left), ...notes.map((note) => note.x), ...blocks.map((b) => b.geometry.x),
    xs[0] - leftNeed,
  ];
  const rights = [
    ...participants.map((p) => p.cx + p.width / 2),
    ...messages.map((msg) => msg.right), ...notes.map((note) => note.x + note.width),
    ...blocks.map((b) => b.geometry.x + b.geometry.width),
    xs.at(-1) + rightNeed,
  ];
  const shift = m.pad - Math.min(...lefts);
  const width = Math.max(...rights) + shift + m.pad;
  const bottomTop = lifelineBottom;
  const height = bottomTop + boxHeight + m.pad;

  const move = (value) => value + shift;
  const box = (p, top) => ({ ...p, x: move(p.cx - p.width / 2), y: top, width: p.width, height: p.height });
  return {
    diagnostics: [],
    layout: {
      width,
      height,
      participants: participants.map((p) => ({
        id: p.id,
        x: move(p.cx),
        top: box(p, m.pad),
        bottom: box(p, bottomTop),
        lifeline: { y1: m.pad + boxHeight, y2: bottomTop },
      })),
      messages: messages.map(({ left, right, ...msg }) => ({
        ...msg,
        points: msg.points.map(([px, py]) => [move(px), py]),
        labelBox: msg.labelBox ? { ...msg.labelBox, x: move(msg.labelBox.x) } : null,
      })),
      notes: notes.map((note) => ({ ...note, x: move(note.x) })),
      blocks: blocks.map(({ block, geometry }) => ({
        kind: block.step.block,
        label: block.step.label,
        depth: block.depth,
        ...geometry,
        x: move(geometry.x),
        labelBox: { ...geometry.labelBox, x: move(geometry.labelBox.x) },
        branches: geometry.branches.map((branch) => ({ ...branch, labelBox: branch.labelBox ? { ...branch.labelBox, x: move(branch.labelBox.x) } : null })),
      })),
    },
  };
}

// 今までに置いたものの数（ブロックの中に入ったものを後で取り出すため）。
function snapshot(rows) {
  return { messages: rows.messages.length, notes: rows.notes.length, blocks: rows.blocks.length };
}

function since(rows, before) {
  return {
    messages: rows.messages.slice(before.messages),
    notes: rows.notes.slice(before.notes),
    blocks: rows.blocks.slice(before.blocks),
  };
}

// メッセージの線の点・ラベルの範囲・横の範囲（left・right。ブロックの範囲と図の幅に使う）。
function messageGeometry(row, xs) {
  const m = METRICS;
  const base = {
    number: row.number,
    from: row.step.from,
    to: row.step.to,
    label: row.text,
    reply: Boolean(row.step.reply),
    async: Boolean(row.step.async),
    self: row.self,
  };
  const width = row.text === null ? 0 : messageLabelWidth(row.text);
  if (row.self) {
    const x = xs[row.from];
    const { top } = row;
    const bottom = top + m.self.height;
    const labelBox = row.text === null ? null : {
      x: x + m.self.width + m.self.labelGap, y: (top + bottom) / 2 - m.message.labelHeight / 2, width, height: m.message.labelHeight,
    };
    return {
      ...base,
      points: [[x, top], [x + m.self.width, top], [x + m.self.width, bottom], [x, bottom]],
      labelBox,
      left: x,
      right: labelBox ? labelBox.x + labelBox.width : x + m.self.width,
    };
  }
  const [x1, x2] = [xs[row.from], xs[row.to]];
  const labelBox = row.text === null ? null : {
    x: (x1 + x2) / 2 - width / 2, y: row.lineY - m.message.labelGap - m.message.labelHeight, width, height: m.message.labelHeight,
  };
  return { ...base, points: [[x1, row.lineY], [x2, row.lineY]], labelBox, left: Math.min(x1, x2), right: Math.max(x1, x2) };
}

// 注記の四角。1人なら生存線を中心に、2人なら2つの生存線を overhang だけはみ出して覆う（文字が入らなければ広げる）。
function noteGeometry(row, xs) {
  const m = METRICS.note;
  const [lo, hi] = [row.over[0], row.over.at(-1)];
  const center = (xs[lo] + xs[hi]) / 2;
  const width = lo === hi ? row.width : Math.max(xs[hi] - xs[lo] + 2 * m.overhang, row.text);
  return { text: row.step.note, over: row.step.over, x: center - width / 2, y: row.y, width, height: m.height };
}

// ブロックの四角・札・条件の範囲と、else の区切り。
function blockGeometry(block, messages, notes, rows, extentOf) {
  const m = METRICS.block;
  const lefts = [];
  const rights = [];
  for (const row of block.items.messages) {
    const msg = messages[rows.messages.indexOf(row)];
    lefts.push(msg.left);
    rights.push(msg.right);
  }
  for (const row of block.items.notes) {
    const note = notes[rows.notes.indexOf(row)];
    lefts.push(note.x);
    rights.push(note.x + note.width);
  }
  for (const inner of block.items.blocks) {
    const extent = extentOf.get(inner);
    if (!extent) continue;
    lefts.push(extent.x);
    rights.push(extent.x + extent.width);
  }
  const x = Math.min(...lefts) - m.pad;
  const tab = tabWidth(block.step.block);
  const condition = conditionWidth(block.step.label);
  const headerNeed = tab + m.labelGap + condition + m.pad;
  const branchNeeds = block.branches.map((branch) => (branch.label ? m.pad + conditionWidth(branch.label) + m.pad : 0));
  const width = Math.max(Math.max(...rights) + m.pad - x, headerNeed, ...branchNeeds);
  return {
    x,
    y: block.top,
    width,
    height: block.bottom - block.top,
    tabWidth: tab,
    labelBox: { x: x + tab + m.labelGap, y: block.top + (m.tabHeight - m.labelHeight) / 2, width: condition, height: m.labelHeight },
    branches: block.branches.map((branch) => ({
      label: branch.label,
      y: branch.lineY,
      labelBox: branch.label ? { x: x + m.pad, y: branch.labelY, width: conditionWidth(branch.label), height: m.labelHeight } : null,
    })),
  };
}
