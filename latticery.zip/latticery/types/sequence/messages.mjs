// sequence の文言（日英）：凡例のメッセージとブロックの種類の名前と、診断のメッセージ。診断の形は core/messages.mjs と同じ。
// 参加者の種類の名前は、architecture と共通なので core/kinds.mjs にある。id/duplicate・text/too-long のメッセージは core/messages.mjs にある。

import { formatPath, joinList } from '../../core/i18n.mjs';

// 凡例に出す、メッセージの種類（call：呼び出し・reply・async）とブロックの種類（loop・alt・opt）の名前。
export const styleNames = {
  ja: { call: '呼び出し', reply: '返答', async: '非同期', loop: '繰り返し', alt: '条件分岐', opt: '条件付き' },
  en: { call: 'Call', reply: 'Reply', async: 'Async', loop: 'Loop', alt: 'Alternatives', opt: 'Optional' },
};

const SHAPE_NAMES = {
  ja: { message: 'メッセージ', note: '注記', block: 'ブロック' },
  en: { message: 'message', note: 'note', block: 'block' },
};

// 3つの形の、必須の項目の書き方。
const SHAPE_HINTS = {
  ja: ['メッセージなら from・to', '注記なら note・over', 'ブロックなら block・label・steps'],
  en: ['for a message, from and to', 'for a note, note and over', 'for a block, block, label and steps'],
};

const quoted = (list, lang) => joinList(list.map((field) => (lang === 'ja' ? `「${field}」` : `"${field}"`)), lang);

export const sequenceMessages = {
  'ref/unknown': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の「${d.value}」という参加者はありません`,
      fixes: (d) => [...(d.suggestion ? [`「${d.suggestion}」の書き間違いなら直す`] : []), `ID「${d.value}」の参加者を participants に追加する`],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')}: there is no participant "${d.value}"`,
      fixes: (d) => [...(d.suggestion ? [`If this is a typo for "${d.suggestion}", fix it`] : []), `Add a participant with the ID "${d.value}" to participants`],
    },
  },
  'step/shape': {
    ja: {
      message: (d) => {
        const at = formatPath(d.path, 'ja');
        if (d.shapes.length === 0) return `${at} が、メッセージ・注記・ブロックのどの形にも合いません`;
        if (d.shapes.length > 1) return `${at} に、${joinList(d.shapes.map((s) => SHAPE_NAMES.ja[s]), 'ja')}の項目が混ざっています`;
        const name = SHAPE_NAMES.ja[d.shapes[0]];
        const parts = [
          d.missing.length > 0 ? `必須の項目${quoted(d.missing, 'ja')}がありません` : '',
          d.extra.length > 0 ? `${quoted(d.extra, 'ja')}は使えません` : '',
        ].filter(Boolean);
        return `${at}（${name}）：${parts.join('。')}`;
      },
      fixes: (d) => {
        if (d.shapes.length === 0) return [`どの形にするか決めて、必須の項目を書く（${SHAPE_HINTS.ja.join('、')}）`];
        if (d.shapes.length > 1) return ['1つのステップには1つの形の項目だけを書く。両方が必要なら、ステップを分ける'];
        return [
          ...d.missing.map((field) => `「${field}」を足す`),
          ...(d.block ? [`条件で分かれるなら block を "alt" にする。そうでなければ else を消す（else は alt だけで使える）`] : []),
          ...d.extra.filter((field) => field !== 'else' || !d.block).map((field) => `「${field}」を消す（${SHAPE_NAMES.ja[d.shapes[0]]}では使えない）`),
        ];
      },
    },
    en: {
      message: (d) => {
        const at = formatPath(d.path, 'en');
        if (d.shapes.length === 0) return `${at} does not match any step shape (message, note, or block)`;
        if (d.shapes.length > 1) return `${at} mixes the fields of a ${joinList(d.shapes.map((s) => SHAPE_NAMES.en[s]), 'en')}`;
        const name = SHAPE_NAMES.en[d.shapes[0]];
        const parts = [
          d.missing.length > 0 ? `the required field(s) ${quoted(d.missing, 'en')} are missing` : '',
          d.extra.length > 0 ? `${quoted(d.extra, 'en')} cannot be used` : '',
        ].filter(Boolean);
        return `${at} (${name}): ${parts.join('; ')}`;
      },
      fixes: (d) => {
        if (d.shapes.length === 0) return [`Choose a shape and write its required fields (${SHAPE_HINTS.en.join('; ')})`];
        if (d.shapes.length > 1) return ['Write the fields of only one shape in each step. If you need both, split it into two steps'];
        return [
          ...d.missing.map((field) => `Add "${field}"`),
          ...(d.block ? ['If the flow branches on conditions, set block to "alt"; otherwise remove else (else is only for alt)'] : []),
          ...d.extra.filter((field) => field !== 'else' || !d.block).map((field) => `Remove "${field}" (it cannot be used in a ${SHAPE_NAMES.en[d.shapes[0]]})`),
        ];
      },
    },
  },
  'block/too-deep': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} で、ブロックの入れ子が${d.limit}段を超えています`,
      fixes: () => ['外側のブロックの条件を、内側のブロックの条件にまとめる', '細かい分岐は注記（note）か説明カード（notes）に書く'],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')}: blocks are nested more than ${d.limit} levels deep`,
      fixes: () => ['Merge the condition of an outer block into the inner one', 'Describe minor branches in a note or a note card (notes)'],
    },
  },
  'participant/unused': {
    ja: {
      message: (d) => `参加者「${d.id}」が、どのメッセージにも出てきません`,
      fixes: () => ['その参加者とのメッセージを足す', '不要なら participants から消す（注記の over からも消す）'],
    },
    en: {
      message: (d) => `The participant "${d.id}" is not in any message`,
      fixes: () => ['Add a message to or from this participant', 'If it is not needed, remove it from participants (and from the over of notes)'],
    },
  },
  'message/reply-without-call': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} は「${d.from}」→「${d.to}」の返答ですが、その前に「${d.to}」→「${d.from}」の呼び出しがありません`,
      fixes: (d) => [`向きが逆なら、from を「${d.to}」、to を「${d.from}」にする`, '返答でなければ reply を消す'],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')} is a reply from "${d.from}" to "${d.to}", but no earlier call goes from "${d.to}" to "${d.from}"`,
      fixes: (d) => [`If the direction is reversed, set from to "${d.to}" and to to "${d.from}"`, 'If it is not a reply, remove reply'],
    },
  },
  'size/too-many-participants': {
    ja: {
      message: (d) => `参加者の数が${d.count}です。${d.limit}を超えると横に長く、読みにくくなります`,
      fixes: () => ['流れに関わりの薄い参加者を省く', '同じ役割の参加者（複数のサーバーなど）を1つにまとめる', '図を2つに分ける'],
    },
    en: {
      message: (d) => `The diagram has ${d.count} participants; more than ${d.limit} makes it wide and hard to read`,
      fixes: () => ['Leave out participants that are only loosely related to the flow', 'Merge participants with the same role (such as several servers) into one', 'Split the diagram into two'],
    },
  },
  'size/too-many-messages': {
    ja: {
      message: (d) => `メッセージが${d.count}個あります。${d.limit}個を超えると縦に長く、読みにくくなります`,
      fixes: () => ['細かいやりとりを1つのメッセージか注記にまとめる', '意味のない返答を省く', '流れの区切りで図を分ける'],
    },
    en: {
      message: (d) => `The diagram has ${d.count} messages; more than ${d.limit} makes it long and hard to read`,
      fixes: () => ['Combine minor exchanges into one message or a note', 'Leave out replies that carry no meaning', 'Split the diagram where the flow changes phase'],
    },
  },
  'size/too-wide': {
    ja: {
      message: (d) => `図の幅が ${d.width}px あります（参加者の数 ${d.participants}）。指定の ${d.limit}px を超えています`,
      fixes: () => ['参加者を減らす。流れに関わりの薄い参加者を省くか、同じ役割の参加者をまとめる', '長い名前・補足・メッセージのラベルを短くする'],
    },
    en: {
      message: (d) => `The diagram is ${d.width}px wide (${d.participants} participants), which exceeds the requested ${d.limit}px`,
      fixes: () => ['Use fewer participants: leave out loosely related ones or merge those with the same role', 'Shorten long names, sublabels, and message labels'],
    },
  },
  'size/too-tall': {
    ja: {
      message: (d) => `図の高さが ${d.height}px あります（メッセージ${d.messages}個）。指定の ${d.limit}px を超えています`,
      fixes: () => ['メッセージを減らす。細かいやりとりを1つのメッセージか注記にまとめ、意味のない返答を省く', '図を流れの区切りで分ける'],
    },
    en: {
      message: (d) => `The diagram is ${d.height}px tall (${d.messages} messages), which exceeds the requested ${d.limit}px`,
      fixes: () => ['Use fewer messages: combine minor exchanges into one message or a note, and leave out replies that carry no meaning', 'Split the diagram where the flow changes phase'],
    },
  },
};
