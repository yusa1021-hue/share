// sequence の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/sequence.md の「3. 描画のしかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは core/draw.mjs の diagramStyles() と sequenceStyles() の CSS で行う（CSS の指定は属性より優先される）。
// 参加者の箱・鏃・線の角の丸めは、architecture と共通の core/ のものを使う（決定記録 No.72）。

import {
  BASE_COLORS, LINE, SAMPLE, arrowHead, edgePath, fitArrow, lineSample, openArrowHead, pullBack, sampleSvg,
} from '../../core/draw.mjs';
import { nodeElement } from '../../core/node.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY, estimateWidth } from '../../core/text.mjs';
import { METRICS, conditionText } from './layout.mjs';

// 描き方。lifeline は生存線、block はブロックの四角と札、note は注記。
export const DRAW = {
  lifeline: { width: 1, dash: '4 4' },
  block: { radius: 4, strokeWidth: 1.25, dash: '5 4' },
  note: { strokeWidth: 1 },
};

// 注記の塗り（ライト・ダーク）。文字は名前と同じ色、枠線は枠の色（BASE_COLORS の group）。
export const NOTE_COLORS = { light: '#f4f5f7', dark: '#1f232a' };

// ---- 凡例の見本 ------------------------------------------------------------------

export const LEGEND_STYLES = ['call', 'reply', 'async'];
export const BLOCK_KINDS = ['loop', 'alt', 'opt'];

/** 凡例に出す、メッセージの種類（call：呼び出し・reply・async）の見本。 */
export function styleSample(style) {
  return sampleSvg(lineSample({
    classes: [style === 'reply' ? 'lt-reply' : null, style === 'async' ? 'lt-async' : null],
    dash: style === 'reply' ? '4 3' : null,
    open: style === 'async',
  }));
}

/** 凡例に出す、ブロックの種類（loop・alt・opt）の見本。左上の札に種類を書いたもの。 */
export function blockSample(kind) {
  const base = BASE_COLORS.light;
  const [w, h, cut] = [SAMPLE.width - 2, SAMPLE.height - 1, 4];
  return sampleSvg(el('g', { class: 'lt-block' }, [
    el('path', {
      class: 'lt-block-tab', d: `M1 0.5H${1 + w}V${0.5 + h - cut}L${1 + w - cut} ${0.5 + h}H1Z`,
      fill: base.page, stroke: base.group, 'stroke-width': 1,
    }),
    el('text', {
      class: 'lt-block-kind', x: 4, y: 0.5 + h / 2, 'font-size': 10, 'font-weight': 700, 'dominant-baseline': 'central', 'font-family': FONT_FAMILY,
      fill: base.muted,
    }, kind),
  ]));
}

// ---- 図 ----------------------------------------------------------------------

/**
 * 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。
 * つながりの強調（viewer/highlight.mjs）のため、参加者の箱と生存線には data-node（参加者の ID）を、
 * メッセージの線とラベルには data-edge（メッセージを上から数えた番号）・data-from・data-to を付ける。
 * 生存線はいちばん下に、箱はいちばん上に描くので、同じ参加者の目印を2つの要素に付ける。
 */
export function renderSequence(layout, doc) {
  const base = BASE_COLORS.light;
  return el('svg', {
    class: 'lt-diagram lt-sequence',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    el('g', { class: 'lt-lifelines' }, layout.participants.map((p) => renderLifeline(p, base))),
    el('g', { class: 'lt-blocks' }, [...layout.blocks].sort((p, q) => p.depth - q.depth).map((block) => renderBlock(block, base))),
    el('g', { class: 'lt-notes' }, layout.notes.map((note) => renderNote(note, base))),
    el('g', { class: 'lt-messages' }, layout.messages.map((message, i) => renderMessage(message, i, base))),
    el('g', { class: 'lt-participants' }, layout.participants.map((p) => el('g', { class: 'lt-participant', 'data-id': p.id, 'data-node': p.id }, [
      nodeElement(p.top),
      nodeElement(p.bottom),
    ]))),
  ]);
}

function renderLifeline(p, base) {
  const d = `M${n(p.x)} ${n(p.lifeline.y1)}V${n(p.lifeline.y2)}`;
  return el('g', { class: 'lt-lifeline', 'data-node': p.id }, [
    el('path', {
      class: 'lt-lifeline-line', d, fill: 'none', stroke: base.group, 'stroke-width': DRAW.lifeline.width, 'stroke-dasharray': DRAW.lifeline.dash,
    }),
    // 細い線でもポインターを合わせやすくするための、見えない太い線。書き出すときは取り除く（viewer/export.mjs）。
    el('path', { class: 'lt-edge-hit', d, fill: 'none', stroke: 'none', 'stroke-width': LINE.hitWidth, 'pointer-events': 'stroke', 'data-hit': '' }),
  ]);
}

// ブロック：四角、左上の札（種類）、札の右の条件、else の区切りと条件。
function renderBlock(block, base) {
  const m = METRICS.block;
  const { x, y, tabWidth: w } = block;
  const tab = `M${n(x)} ${n(y)}H${n(x + w)}V${n(y + m.tabHeight - m.tabCut)}L${n(x + w - m.tabCut)} ${n(y + m.tabHeight)}H${n(x)}Z`;
  return el('g', { class: `lt-block lt-block-${block.kind}` }, [
    el('rect', {
      class: 'lt-block-box', x, y, width: block.width, height: block.height, rx: DRAW.block.radius,
      fill: 'none', stroke: base.group, 'stroke-width': DRAW.block.strokeWidth,
    }),
    el('path', { class: 'lt-block-tab', d: tab, fill: base.page, stroke: base.group, 'stroke-width': DRAW.block.strokeWidth }),
    el('text', {
      class: 'lt-block-kind',
      x: x + m.tabPaddingX, y: y + m.tabHeight / 2, 'font-size': m.kindSize, 'font-weight': 700, 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': estimateWidth(block.kind, m.kindSize, { bold: true }),
    }, block.kind),
    conditionLabel(block.labelBox, block.label, base),
    block.branches.map((branch) => [
      el('path', {
        class: 'lt-block-sep', d: `M${n(x)} ${n(branch.y)}H${n(x + block.width)}`,
        fill: 'none', stroke: base.group, 'stroke-width': DRAW.block.strokeWidth, 'stroke-dasharray': DRAW.block.dash,
      }),
      branch.labelBox ? conditionLabel(branch.labelBox, branch.label, base) : null,
    ]),
  ]);
}

// 条件は [ ] で囲み、背景を付けて生存線より上に見せる。札のすぐ右（else は左端）から読めるよう、左寄せにする。
function conditionLabel(box, label, base) {
  const m = METRICS.block;
  const text = conditionText(label);
  const size = m.labelSize;
  return el('g', { class: 'lt-block-label' }, [
    el('rect', { class: 'lt-block-label-bg', x: box.x, y: box.y, width: box.width, height: box.height, rx: LINE.labelRadius, fill: base.page }),
    el('text', {
      x: box.x + m.labelPaddingX, y: box.y + box.height / 2, 'font-size': size, 'dominant-baseline': 'central',
      fill: base.muted,
      'data-width': estimateWidth(text, size),
    }, text),
  ]);
}

// 注記：右上の角を折った四角。
function renderNote(note, base) {
  const m = METRICS.note;
  const { x, y, width: w, height: h } = note;
  const f = m.fold;
  return el('g', { class: 'lt-note' }, [
    el('path', {
      class: 'lt-note-box', d: `M${n(x)} ${n(y)}H${n(x + w - f)}L${n(x + w)} ${n(y + f)}V${n(y + h)}H${n(x)}Z`,
      fill: NOTE_COLORS.light, stroke: base.group, 'stroke-width': DRAW.note.strokeWidth,
    }),
    el('path', {
      class: 'lt-note-fold', d: `M${n(x + w - f)} ${n(y)}V${n(y + f)}H${n(x + w)}`,
      fill: 'none', stroke: base.group, 'stroke-width': DRAW.note.strokeWidth,
    }),
    el('text', {
      class: 'lt-note-text',
      x: x + w / 2, y: y + h / 2, 'font-size': m.size, 'text-anchor': 'middle', 'dominant-baseline': 'central',
      fill: base.text,
      'data-width': estimateWidth(note.text, m.size),
    }, note.text),
  ]);
}

// メッセージ：線・当たり判定の線・鏃・ラベル。返答は破線、非同期は開いた鏃（決定記録 No.69）。
function renderMessage(message, index, base) {
  const color = base.edge;
  const { points } = message;
  const tip = points.at(-1);
  const prev = points.at(-2);
  const arrow = fitArrow(LINE.arrow, tip, prev, message.self);
  // 塗った鏃は、線の端を鏃の内側まで下げる。開いた鏃は、線を先の近くまで引く。
  const line = points.map(([x, y]) => [x, y]);
  pullBack(line.at(-1), line.at(-2), message.async ? LINE.width / 2 : (LINE.width * arrow.length) / arrow.width + 0.5);
  const d = edgePath(line);
  const classes = ['lt-edge', 'lt-message', message.reply ? 'lt-reply' : null, message.async ? 'lt-async' : null].filter(Boolean).join(' ');
  return el('g', { class: classes, 'data-edge': index, 'data-from': message.from, 'data-to': message.to }, [
    el('path', {
      class: 'lt-edge-line', d, fill: 'none', stroke: color, 'stroke-width': LINE.width,
      'stroke-dasharray': message.reply ? LINE.dash : null,
    }),
    el('path', { class: 'lt-edge-hit', d: edgePath(points), fill: 'none', stroke: 'none', 'stroke-width': LINE.hitWidth, 'pointer-events': 'stroke', 'data-hit': '' }),
    message.async ? openArrowHead(prev, tip, arrow, color) : arrowHead(prev, tip, arrow, color),
    message.labelBox ? messageLabel(message.labelBox, message.label, message.self, base) : null,
  ]);
}

// ラベルは線の中央に置く。自分へのメッセージは、折り返しのすぐ右から読めるよう左寄せにする。
function messageLabel(box, label, self, base) {
  const m = METRICS.message;
  return el('g', { class: 'lt-message-label' }, [
    el('rect', { class: 'lt-edge-label-bg', x: box.x, y: box.y, width: box.width, height: box.height, rx: LINE.labelRadius, fill: base.page }),
    el('text', {
      x: self ? box.x + m.labelPaddingX : box.x + box.width / 2, y: box.y + box.height / 2, 'font-size': m.labelSize,
      'text-anchor': self ? null : 'middle', 'dominant-baseline': 'central',
      fill: base.text,
      'data-width': estimateWidth(label, m.labelSize),
    }, label),
  ]);
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、sequence だけのもの（生存線・ブロック・注記・メッセージのラベル）。
 * 図の色の変数と、参加者の箱・線に共通の部分は core/draw.mjs の diagramStyles() で決める。
 */
export function sequenceStyles({ dark = '[data-theme="dark"]' } = {}) {
  return [
    `.lt-sequence{--lt-note:${NOTE_COLORS.light}}`,
    `${dark} .lt-sequence{--lt-note:${NOTE_COLORS.dark}}`,
    '.lt-lifeline-line,.lt-block-box,.lt-block-sep,.lt-note-fold{stroke:var(--lt-group)}',
    '.lt-block-tab{fill:var(--lt-page);stroke:var(--lt-group)}',
    '.lt-block-kind,.lt-block-label text{fill:var(--lt-muted)}',
    '.lt-block-label-bg{fill:var(--lt-page)}',
    '.lt-note-box{fill:var(--lt-note);stroke:var(--lt-group)}',
    '.lt-note-text,.lt-message-label text{fill:var(--lt-text)}',
  ].join('\n');
}
