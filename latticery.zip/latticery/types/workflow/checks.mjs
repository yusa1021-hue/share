// workflow のチェック。仕様：docs/latticery/types/workflow.md の「4. チェック」
// checkWorkflow：構造のチェック。スキーマ検証を通った図に対して、配置を計算しなくても分かる問題を調べる。
// inspectWorkflow：見た目のチェック。配置の計算の結果（layout.mjs の layoutWorkflow が返す layout）を使う。
// ラベルの重なりと線の交差は、architecture と同じ共通のチェック（core/inspect.mjs）を使う。

import { duplicateIds, longTexts, oversize } from '../../core/checks.mjs';
import { closest, error, synonymIndex, warning } from '../../core/diagnostics.mjs';
import { STEP_SYNONYMS } from '../../core/steps.mjs';
import { edgeTarget } from '../../core/route.mjs';
import { inspectDiagram } from '../../core/inspect.mjs';
import { isSibling } from './layout.mjs';

// 使えない値から、意味の近い使える値への対応（schema/invalid の直し方の候補に使う）。
export const VALUE_SYNONYMS = synonymIndex({
  ...STEP_SYNONYMS,
  right: ['horizontal', 'landscape', 'lr', 'sideways'],
  down: ['vertical', 'portrait', 'tb', 'topdown'],
});

// 表示幅の目安（半角1・全角2で数える）。
const TEXT_GUIDELINES = {
  laneLabel: 12,
  phaseLabel: 12,
  label: 18,
  decisionLabel: 12,
  sublabel: 20,
  tag: 8,
  edgeLabel: 12,
};

export function checkWorkflow(doc) {
  const parts = { lanes: doc.lanes, phases: doc.phases ?? [], nodes: doc.nodes, edges: doc.edges };
  return [
    ...checkIds(parts),
    ...checkReferences(parts),
    ...checkPlacement(parts),
    ...checkPhases(parts.phases),
    ...checkFlow(parts),
    ...checkTextLength(parts),
  ];
}

function checkIds({ lanes, phases, nodes, edges }) {
  return duplicateIds([
    ...lanes.map((lane, i) => ({ id: lane.id, path: `/lanes/${i}/id` })),
    ...phases.map((phase, i) => ({ id: phase.id, path: `/phases/${i}/id` })),
    ...nodes.map((node, i) => ({ id: node.id, path: `/nodes/${i}/id` })),
    ...edges.map((edge, i) => ({ id: edge.id, path: `/edges/${i}/id` })),
  ]);
}

function checkReferences({ lanes, nodes, edges }) {
  const laneIds = lanes.map((lane) => lane.id);
  const laneSet = new Set(laneIds);
  const nodeIds = nodes.map((node) => node.id);
  const nodeSet = new Set(nodeIds);
  const problems = [];
  const verify = (value, path, target, ids, set, kind) => {
    if (set.has(value)) return;
    const detail = { path, value, kind };
    const suggestion = closest(value, ids);
    if (suggestion) detail.suggestion = suggestion;
    problems.push(error('ref/unknown', { target, detail }));
  };
  nodes.forEach((node, i) => verify(node.lane, `/nodes/${i}/lane`, [node.id], laneIds, laneSet, 'lane'));
  edges.forEach((edge, i) => {
    verify(edge.from, `/edges/${i}/from`, edgeTarget(edge), nodeIds, nodeSet, 'node');
    verify(edge.to, `/edges/${i}/to`, edgeTarget(edge), nodeIds, nodeSet, 'node');
  });
  return problems;
}

// 同じ帯の同じ順番に、2つの手順は置けない（step/occupied）。
function checkPlacement({ lanes, nodes }) {
  const laneSet = new Set(lanes.map((lane) => lane.id));
  const places = new Map();
  for (const node of nodes) {
    if (!laneSet.has(node.lane)) continue;
    const key = `${node.lane}:${node.step}`;
    if (!places.has(key)) places.set(key, []);
    places.get(key).push(node);
  }
  const used = new Set([...places.keys()]);
  return [...places.values()].filter((group) => group.length > 1).map((group) => {
    // 空いている順番のうち、いちばん近いものを直し方の候補にする。
    const { lane, step } = group[0];
    const free = [];
    for (let distance = 1; distance <= 9 && free.length === 0; distance += 1) {
      for (const candidate of [step + distance, step - distance]) {
        if (candidate >= 0 && candidate <= 9 && !used.has(`${lane}:${candidate}`)) free.push(candidate);
      }
    }
    return error('step/occupied', {
      target: group.map((node) => node.id),
      detail: { lane, step, ids: group.map((node) => node.id), free: free.slice(0, 1) },
    });
  });
}

// 局面の帯の範囲は、重なってはいけない（phase/overlap）。from > to も同じエラーで知らせる。
function checkPhases(phases) {
  const problems = [];
  phases.forEach((phase, i) => {
    if (phase.from > phase.to) {
      problems.push(error('phase/overlap', { target: [phase.id ?? phase.label], detail: { path: `/phases/${i}`, label: phase.label, from: phase.from, to: phase.to, reversed: true } }));
    }
  });
  phases.forEach((phase, i) => phases.slice(i + 1).forEach((other) => {
    if (phase.from > phase.to || other.from > other.to) return;
    if (phase.from <= other.to && other.from <= phase.to) {
      problems.push(error('phase/overlap', {
        target: [phase.id ?? phase.label, other.id ?? other.label],
        detail: { path: `/phases/${i}`, label: phase.label, other: other.label, from: Math.max(phase.from, other.from), to: Math.min(phase.to, other.to) },
      }));
    }
  }));
  return problems;
}

// 流れの形：始まりと終わり、つながっていない手順、判断の分岐。
function checkFlow({ nodes, edges }) {
  const problems = [];
  const byId = new Map(nodes.map((node) => [node.id, node]));
  const incoming = new Map(nodes.map((node) => [node.id, 0]));
  const outgoing = new Map(nodes.map((node) => [node.id, 0]));
  for (const edge of edges) {
    if (incoming.has(edge.to)) incoming.set(edge.to, incoming.get(edge.to) + 1);
    if (outgoing.has(edge.from)) outgoing.set(edge.from, outgoing.get(edge.from) + 1);
  }
  const kinds = new Set(nodes.map((node) => node.kind));
  if (!kinds.has('start')) problems.push(warning('flow/no-start', { detail: { first: firstOf(nodes) } }));
  if (!kinds.has('end')) problems.push(warning('flow/no-end', { detail: { last: lastOf(nodes) } }));
  for (const node of nodes) {
    if (node.kind !== 'start' && incoming.get(node.id) === 0) {
      problems.push(warning('flow/unreachable', { target: [node.id], detail: { id: node.id, label: node.label, kind: node.kind } }));
    }
    if (node.kind !== 'end' && outgoing.get(node.id) === 0) {
      problems.push(warning('flow/dead-end', { target: [node.id], detail: { id: node.id, label: node.label, kind: node.kind } }));
    }
  }
  for (const node of nodes) {
    if (node.kind !== 'decision') continue;
    const branches = edges.filter((edge) => edge.from === node.id);
    if (branches.length === 1) {
      problems.push(warning('decision/single-branch', { target: [node.id], detail: { id: node.id, label: node.label, to: byId.get(branches[0].to)?.label ?? branches[0].to } }));
    }
  }
  return problems;
}

// 始まり・終わりがないときに、直し方の候補として示す手順（いちばん early・late な手順）。
const firstOf = (nodes) => [...nodes].sort((p, q) => p.step - q.step)[0]?.id ?? null;
const lastOf = (nodes) => [...nodes].sort((p, q) => q.step - p.step)[0]?.id ?? null;

function checkTextLength({ lanes, phases, nodes, edges }) {
  return longTexts([
    ...lanes.map((lane, i) => ({ text: lane.label, path: `/lanes/${i}/label`, limit: TEXT_GUIDELINES.laneLabel, target: [lane.id] })),
    ...phases.map((phase, i) => ({ text: phase.label, path: `/phases/${i}/label`, limit: TEXT_GUIDELINES.phaseLabel, target: [phase.id ?? phase.label] })),
    ...nodes.flatMap((node, i) => [
      { text: node.label, path: `/nodes/${i}/label`, limit: node.kind === 'decision' ? TEXT_GUIDELINES.decisionLabel : TEXT_GUIDELINES.label, target: [node.id] },
      { text: node.sublabel, path: `/nodes/${i}/sublabel`, limit: TEXT_GUIDELINES.sublabel, target: [node.id] },
      { text: node.tag, path: `/nodes/${i}/tag`, limit: TEXT_GUIDELINES.tag, target: [node.id] },
    ]),
    ...edges.map((edge, i) => ({ text: edge.label, path: `/edges/${i}/label`, limit: TEXT_GUIDELINES.edgeLabel, target: edgeTarget(edge) })),
  ]);
}

/** 見た目のチェック。ラベルの重なり・線の交差・図の大きさ。 */
export function inspectWorkflow(doc, layout, limits = {}) {
  return [
    ...inspectDiagram(doc.edges, layout, {
      sibling: isSibling,
      boxes: [
        ...layout.lanes.map((lane) => ({ kind: 'lane', id: lane.id, box: lane.labelBox })),
        ...layout.phases.map((phase) => ({ kind: 'phase', id: phase.id ?? phase.label, box: { x: phase.x, y: phase.y, width: phase.width, height: phase.height } })),
      ],
    }),
    ...oversize(layout, limits, {
      width: { lanes: doc.lanes.length },
      height: { lanes: doc.lanes.length },
    }),
  ];
}
