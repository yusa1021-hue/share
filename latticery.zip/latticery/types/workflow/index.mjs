// 図の種類「workflow」の定義。core/check.mjs に渡して使う。

import { createValidator } from '../../core/schema.mjs';
import { STEP_KINDS, STEP_STYLE, stepIcon, stepNames } from '../../core/steps.mjs';
import { VALUE_SYNONYMS, checkWorkflow, inspectWorkflow } from './checks.mjs';
import { isBack, layoutWorkflow } from './layout.mjs';
import { styleNames, workflowMessages } from './messages.mjs';
import { LEGEND_STYLES, kindSample, renderWorkflow, styleSample, workflowStyles } from './render.mjs';

// schema には types/workflow/schema.json の中身を渡す。
// 読み込み方が実行環境（コマンド・ブラウザ）ごとに違うため、ここでは読み込まない。
export function createWorkflowType(schema) {
  return {
    name: 'workflow',
    validateSchema: createValidator(schema),
    synonyms: VALUE_SYNONYMS,
    check: checkWorkflow,
    layout: layoutWorkflow,
    inspect: inspectWorkflow,
    render: renderWorkflow,
    styles: workflowStyles,
    legend: legendItems,
    icon: (kind, options) => (STEP_KINDS.includes(kind) ? stepIcon(kind, options) : null),
    kindClass: STEP_STYLE.className,
    messages: workflowMessages,
  };
}

// 凡例の項目。図で使われている手順の種類と線の種類だけを、決まった順に並べる。
// 手順の種類は、形（四角・カプセル・ひし形）も分かるように見本で出す。線は、主な流れ・非同期・戻りを出す。
function legendItems(doc, lang) {
  const kinds = new Set(doc.nodes.map((node) => node.kind));
  const stepOf = new Map(doc.nodes.map((node) => [node.id, node.step]));
  const styles = new Set([
    ...(doc.edges.some((edge) => edge.primary) ? ['primary'] : []),
    ...(doc.edges.some((edge) => edge.async) ? ['async'] : []),
    ...(doc.edges.some((edge) => isBack(edge, stepOf)) ? ['back'] : []),
  ]);
  return [
    ...STEP_KINDS.filter((kind) => kinds.has(kind)).map((kind) => ({ key: kind, label: stepNames[lang][kind], sample: kindSample(kind) })),
    ...LEGEND_STYLES.filter((style) => styles.has(style)).map((style) => ({ key: style, label: styleNames[lang][style], sample: styleSample(style) })),
  ];
}
