// workflow の配置の計算。仕様：docs/latticery/types/workflow.md の「3. 描きかた」
//
// 1. 手順を、担当の帯（lane）と順番（step）から格子の升目に割り当てる（向きで列・行が入れ替わる）
// 2. 以降は architecture と同じ共通の仕組みを使う：経路（core/route.mjs）・レーンとラベル（core/lanes.mjs）・
//    列と行の幅（core/axis.mjs）
// 3. 帯（担当・局面）の範囲と見出しの場所を決める（core/bands.mjs）。見出しは格子の外に置き、その分だけ図を広げる
//
// 入力は、スキーマ検証と構造のチェックを通った図であること。

import { addSpanConstraint, createAxis, evaluate, sizeGrid } from '../../core/axis.mjs';
import { BAND, bandLabelWidth, fillBands, gridSpan, headerBands, headerThickness } from '../../core/bands.mjs';
import { border, buildGrid, line, round } from '../../core/grid.mjs';
import { EDGE, anchorAt, assignLanes, buildRuns, chooseLabels, edgePoints, labelWidth, pairOrders, placeLanes, sharedVertices } from '../../core/lanes.mjs';
import { NODE, nodeSize, tagBox } from '../../core/node.mjs';
import { routeEdges } from '../../core/route.mjs';
import { STEP_STYLE } from '../../core/steps.mjs';

export const METRICS = {
  node: NODE, // 手順の箱の寸法（core/node.mjs）
  edge: EDGE, // 線とラベルの寸法（core/lanes.mjs）
  band: BAND, // 帯の見出しの寸法（core/bands.mjs）
  // base：内側の通路の最小幅。outer：外周の通路の最小幅。emptyTrack：手順のない順番の幅。
  // oddInset：使わない（workflow は半マスずらしをしない）が、共通の計算が参照する。
  gutter: { base: 44, outer: 16, emptyTrack: 20, oddInset: 22 },
};

// 同じ手順から出る線、または同じ手順に入る線で、種類（primary・async）が同じものを「兄弟」と呼ぶ。
// 兄弟の線は、同じ接続点から出る（入る）なら、分かれるまでを重ねて1本の幹として描く（architecture と同じ）。
export const sameStyle = (a, b) => Boolean(a.primary) === Boolean(b.primary) && Boolean(a.async) === Boolean(b.async);
export const isSibling = (a, b) => sameStyle(a, b) && (a.from === b.from || a.to === b.to);

/** 線が戻り（前の順番へ戻る線）か。凡例と描き方に使う。 */
export const isBack = (edge, stepOf) => stepOf.get(edge.to) < stepOf.get(edge.from);

/**
 * 配置を計算する。返り値は { layout, diagnostics }。
 * layout の座標は px で、図の左上が (0, 0)。
 */
export function layoutWorkflow(doc) {
  const down = doc.direction === 'down';
  // 担当の帯は、right なら行の帯、down なら列の帯。局面の帯はその逆。
  const laneAxis = down ? 'x' : 'y';
  const phaseAxis = down ? 'y' : 'x';
  const edges = doc.edges;
  const laneIndex = new Map(doc.lanes.map((lane, i) => [lane.id, i]));
  const stepOf = new Map(doc.nodes.map((node) => [node.id, node.step]));
  // 担当と順番を、格子の列・行にする。向きが down なら、担当が列・順番が行になる。
  const placed = doc.nodes.map((node) => ({
    ...node,
    col: down ? laneIndex.get(node.lane) : node.step,
    row: down ? node.step : laneIndex.get(node.lane),
  }));
  const grid = buildGrid(placed);
  const { routes, diagnostics } = routeEdges(edges, grid, { sibling: isSibling });
  const runsByEdge = routes.map((route) => (route ? buildRuns(route, grid) : null));
  const buckets = assignLanes(runsByEdge, sharedVertices(edges, routes, sameStyle), pairOrders(routes));
  const labels = chooseLabels(edges, runsByEdge);
  const labelRuns = labels.map((label) => label?.run ?? null);
  const labelAnchors = labels.map((label) => label?.anchor ?? null);
  const laneWidths = placeLanes(buckets, labels, edges);

  const x = createAxis(grid.cols, METRICS.gutter.oddInset);
  const y = createAxis(grid.rows, METRICS.gutter.oddInset);
  sizeGrid({
    grid, edges, runsByEdge, labelRuns, labelAnchors, laneWidths, x, y,
    gutter: METRICS.gutter, sizeOf: (node) => nodeSize(node, STEP_STYLE),
  });
  // 局面の見出しは、その範囲に入るだけの幅（高さ）を取る。
  const phases = doc.phases ?? [];
  const laneSpans = doc.lanes.map((lane) => gridSpan(grid.boxes.filter((box) => box.node.lane === lane.id), laneAxis));
  const phaseSpans = phases.map((phase) => gridSpan(grid.boxes.filter((box) => box.node.step >= phase.from && box.node.step <= phase.to), phaseAxis));
  const flowAxis = down ? y : x;
  phases.forEach((phase, i) => {
    const span = phaseSpans[i];
    if (span) addSpanConstraint(flowAxis, line(span[0]), line(span[1]), bandLabelWidth(phase.label), ['B', 'H']);
  });
  const X = evaluate(x);
  const Y = evaluate(y);

  // 帯の見出しの分だけ、図をずらす。担当の見出しは流れの手前側（right なら左、down なら上）、
  // 局面の見出しは流れと直角の手前側（right なら上、down なら左）に置く。
  const header = {
    lane: headerThickness(doc.lanes.map((lane) => lane.label), laneAxis),
    phase: headerThickness(phases.map((phase) => phase.label), phaseAxis),
  };
  const shift = { x: round(down ? header.phase : header.lane), y: round(down ? header.lane : header.phase) };
  const at = { x: (spec) => round(X.at(spec)) + shift.x, y: (spec) => round(Y.at(spec)) + shift.y };
  const width = round(X.total) + shift.x;
  const height = round(Y.total) + shift.y;

  const nodes = placed.map((node) => {
    const box = grid.byId.get(node.id);
    const left = at.x(border(box.a, 1));
    const top = at.y(border(box.c, 1));
    const result = {
      id: node.id,
      kind: node.kind,
      label: node.label,
      sublabel: node.sublabel ?? null,
      tag: node.tag ?? null,
      lane: node.lane,
      step: node.step,
      x: left,
      y: top,
      width: at.x(border(box.b, -1)) - left,
      height: at.y(border(box.d, -1)) - top,
      tagBox: null,
    };
    if (result.tag) result.tagBox = tagBox(result);
    return result;
  });

  const edgeLayouts = [];
  edges.forEach((edge, i) => {
    const runs = runsByEdge[i];
    if (!runs) return;
    const points = edgePoints(runs, X, Y).map(([px, py]) => [px + shift.x, py + shift.y]);
    const labelRun = labelRuns[i];
    let labelBox = null;
    if (labelRun) {
      const boxWidth = labelWidth(edge.label);
      const boxHeight = METRICS.edge.labelHeight;
      const anchor = labelAnchors[i];
      const across = labels[i].across ?? 0;
      const cx = labelRun.axis === 'h' ? anchorAt(X, laneWidths.v, anchor) + across : X.at(line(labelRun.line)) + labelRun.offset;
      const cy = labelRun.axis === 'h' ? Y.at(line(labelRun.line)) + labelRun.offset : anchorAt(Y, laneWidths.h, anchor) + across;
      labelBox = {
        x: round(cx - boxWidth / 2) + shift.x, y: round(cy - boxHeight / 2) + shift.y, width: boxWidth, height: boxHeight,
      };
    }
    edgeLayouts.push({
      id: edge.id ?? null,
      from: edge.from,
      to: edge.to,
      label: edge.label ?? null,
      primary: Boolean(edge.primary),
      async: Boolean(edge.async),
      back: isBack(edge, stepOf),
      points,
      labelBox,
    });
  });

  // 担当の帯：流れの方向いっぱいに伸び、帯と直角の方向は、その帯の升目の縁（格子の線）の間を占める。
  // いちばん外側の帯は、図の端まで伸ばす。手順のない帯は描かない。
  const laneBands = fillBands(doc.lanes, laneSpans, laneAxis, { at, offset: shift, thickness: header.lane, width, height });
  // 局面の帯：流れの方向の from〜to の範囲を占める。見出しは、流れと直角の手前側に出す。
  const phaseBands = headerBands(phases, phaseSpans, phaseAxis, { at, offset: shift, thickness: header.phase });

  return {
    layout: {
      width, height, direction: down ? 'down' : 'right', header: shift, nodes, edges: edgeLayouts, lanes: laneBands, phases: phaseBands,
    },
    diagnostics,
  };
}
