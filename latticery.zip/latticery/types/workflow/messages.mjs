// workflow の文言（日英）：凡例の線の種類の名前と、診断のメッセージ。診断の形は core/messages.mjs と同じ。
// 手順の種類の名前は、後で足す flowchart と共通なので core/steps.mjs にある。
// id/duplicate・text/too-long のメッセージは core/messages.mjs にある。

import { formatPath, joinList } from '../../core/i18n.mjs';
import { stepNames } from '../../core/steps.mjs';

// 凡例に出す、線の種類（主な流れ・非同期・戻り）の名前。
export const styleNames = {
  ja: { primary: '主な流れ', async: '非同期', back: '戻り' },
  en: { primary: 'Main flow', async: 'Async', back: 'Back' },
};

// 線の呼び方（「a」→「b」の線）。
const edgeName = (e, lang) => (lang === 'ja' ? `「${e.from}」→「${e.to}」の線` : `the edge "${e.from}" → "${e.to}"`);

// ラベルと重なっているもの。
const overlapName = (item, lang) => {
  if (item.kind === 'node') return lang === 'ja' ? `手順「${item.id}」` : `step "${item.id}"`;
  if (item.kind === 'lane') return lang === 'ja' ? `担当「${item.id}」の見出し` : `the header of lane "${item.id}"`;
  if (item.kind === 'phase') return lang === 'ja' ? `局面「${item.id}」の見出し` : `the header of phase "${item.id}"`;
  if (item.kind === 'label') return lang === 'ja' ? `${edgeName(item, 'ja')}のラベル` : `the label of ${edgeName(item, 'en')}`;
  return edgeName(item, lang);
};

const stepName = (d, lang) => (lang === 'ja' ? `手順「${d.label}」（${stepNames.ja[d.kind]}）` : `the step "${d.label}" (${stepNames.en[d.kind]})`);

export const workflowMessages = {
  'ref/unknown': {
    ja: {
      message: (d) => `${formatPath(d.path, 'ja')} の「${d.value}」という${d.kind === 'lane' ? '担当の帯' : '手順'}はありません`,
      fixes: (d) => [
        ...(d.suggestion ? [`「${d.suggestion}」の書き間違いなら直す`] : []),
        d.kind === 'lane' ? `ID「${d.value}」の帯を lanes に追加する` : `ID「${d.value}」の手順を nodes に追加する`,
      ],
    },
    en: {
      message: (d) => `${formatPath(d.path, 'en')}: there is no ${d.kind === 'lane' ? 'lane' : 'step'} "${d.value}"`,
      fixes: (d) => [
        ...(d.suggestion ? [`If this is a typo for "${d.suggestion}", fix it`] : []),
        d.kind === 'lane' ? `Add a lane with the ID "${d.value}" to lanes` : `Add a step with the ID "${d.value}" to nodes`,
      ],
    },
  },
  'step/occupied': {
    ja: {
      message: (d) => `担当「${d.lane}」の順番 ${d.step} に、${joinList(d.ids.map((id) => `「${id}」`), 'ja')}が重なっています`,
      fixes: (d) => [
        ...(d.free.length > 0 ? [`どちらかの step を ${d.free[0]} に変える`] : []),
        '同時に進む作業なら、片方を別の担当の帯（lane）に移す',
        '順番が違うなら、後の手順の step を大きくする',
      ],
    },
    en: {
      message: (d) => `Lane "${d.lane}" already has a step at position ${d.step}: ${joinList(d.ids.map((id) => `"${id}"`), 'en')}`,
      fixes: (d) => [
        ...(d.free.length > 0 ? [`Change the step of one of them to ${d.free[0]}`] : []),
        'If they happen at the same time, move one of them to another lane',
        'If one comes after the other, give the later one a larger step',
      ],
    },
  },
  'phase/overlap': {
    ja: {
      message: (d) => (d.reversed
        ? `局面「${d.label}」の from（${d.from}）が to（${d.to}）より大きいです`
        : `局面「${d.label}」と「${d.other}」の範囲が重なっています（順番 ${d.from}〜${d.to}）`),
      fixes: (d) => (d.reversed
        ? ['from に始まりの順番、to に終わりの順番を書く']
        : ['どちらかの from・to を変えて、範囲が重ならないようにする', '同じ局面なら、1つにまとめる']),
    },
    en: {
      message: (d) => (d.reversed
        ? `Phase "${d.label}" has from (${d.from}) greater than to (${d.to})`
        : `Phases "${d.label}" and "${d.other}" overlap (steps ${d.from}–${d.to})`),
      fixes: (d) => (d.reversed
        ? ['Put the first step in from and the last step in to']
        : ['Change from or to so that the ranges do not overlap', 'Merge them if they are the same phase']),
    },
  },
  'flow/no-start': {
    ja: {
      message: () => '始まりの手順（kind が start のもの）がありません',
      fixes: (d) => [...(d.first ? [`いちばん early な手順「${d.first}」の kind を start にする`] : []), 'きっかけを表す手順を足す（「申請が届く」など）'],
    },
    en: {
      message: () => 'The diagram has no start step (kind "start")',
      fixes: (d) => [...(d.first ? [`Set the kind of the earliest step "${d.first}" to start`] : []), 'Add a step for what triggers the flow'],
    },
  },
  'flow/no-end': {
    ja: {
      message: () => '終わりの手順（kind が end のもの）がありません',
      fixes: (d) => [...(d.last ? [`いちばん後の手順「${d.last}」の kind を end にする`] : []), '結果を表す手順を足す（「支払い完了」など）'],
    },
    en: {
      message: () => 'The diagram has no end step (kind "end")',
      fixes: (d) => [...(d.last ? [`Set the kind of the last step "${d.last}" to end`] : []), 'Add a step for how the flow ends'],
    },
  },
  'flow/unreachable': {
    ja: {
      message: (d) => `${stepName(d, 'ja')}に、入ってくる線がありません`,
      fixes: () => ['前の手順から、この手順への線を足す', 'この手順が始まりなら、kind を start にする', '使わない手順なら消す'],
    },
    en: {
      message: (d) => `${stepName(d, 'en').replace(/^t/, 'T')} has no incoming edge`,
      fixes: () => ['Add an edge from the previous step', 'If it starts the flow, set its kind to start', 'Remove it if it is not used'],
    },
  },
  'flow/dead-end': {
    ja: {
      message: (d) => `${stepName(d, 'ja')}から、出ていく線がありません`,
      fixes: () => ['次の手順への線を足す', 'ここで終わるなら、kind を end にする'],
    },
    en: {
      message: (d) => `${stepName(d, 'en').replace(/^t/, 'T')} has no outgoing edge`,
      fixes: () => ['Add an edge to the next step', 'If the flow ends here, set its kind to end'],
    },
  },
  'decision/single-branch': {
    ja: {
      message: (d) => `判断「${d.label}」から出る線が1本（「${d.to}」へ）しかありません`,
      fixes: () => ['もう一方の道（「いいえ」のときに進む手順）への線を足す', '分かれ道でないなら、kind を task か system に変える'],
    },
    en: {
      message: (d) => `The decision "${d.label}" has only one outgoing edge (to "${d.to}")`,
      fixes: () => ['Add the other branch (where the flow goes otherwise)', 'If it is not a branch, change its kind to task or system'],
    },
  },
  'edge/label-overlap': {
    ja: {
      message: (d) => `${edgeName(d, 'ja')}のラベル「${d.label}」が、${joinList(d.overlaps.map((item) => overlapName(item, 'ja')), 'ja')}と重なっています`,
      fixes: () => [
        'ラベルを短くする。両端の手順から分かる内容なら、ラベルを消す',
        '重なっている線の端の手順を、別の順番（step）か別の担当（lane）に移す',
      ],
    },
    en: {
      message: (d) => `The label "${d.label}" of ${edgeName(d, 'en')} overlaps ${joinList(d.overlaps.map((item) => overlapName(item, 'en')), 'en')}`,
      fixes: () => [
        'Shorten the label, or remove it if the two steps already make it clear',
        'Move an end step of the overlapping edge to another step position or lane',
      ],
    },
  },
  'edge/crossing': {
    ja: {
      message: (d) => `${edgeName(d.first, 'ja')}と${edgeName(d.second, 'ja')}が交差しています（${d.count}か所）`,
      fixes: () => [
        '担当の帯（lanes）の並び順を変えて、行き来の多い担当を隣どうしにする',
        'どちらかの線の端の手順を、別の順番（step）に移す',
        '差し戻しなどの例外の手順は、例外の帯（style: "exception"）にまとめる',
      ],
    },
    en: {
      message: (d) => `${edgeName(d.first, 'en').replace(/^t/, 'T')} crosses ${edgeName(d.second, 'en')} (${d.count} ${d.count === 1 ? 'time' : 'times'})`,
      fixes: () => [
        'Reorder the lanes so that lanes that exchange work are next to each other',
        'Move an end step of one edge to another step position',
        'Collect exception steps (rework, rejection) into an exception lane',
      ],
    },
  },
  'size/too-wide': {
    ja: {
      message: (d) => `図の幅が ${d.width}px あります。指定の ${d.limit}px を超えています`,
      fixes: (d) => [
        `手順の順番（step）を減らす（続けて起きる作業を1つの手順にまとめる。担当は ${d.lanes} つ）`,
        '流れを縦にする（direction を "down" にする）',
        '長い名前・補足・線のラベルを短くする',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.width}px wide, which exceeds the requested ${d.limit}px`,
      fixes: (d) => [
        `Use fewer step positions by merging steps that always happen together (${d.lanes} lanes)`,
        'Let the flow run downwards (set direction to "down")',
        'Shorten long labels, sublabels, and edge labels',
      ],
    },
  },
  'size/too-tall': {
    ja: {
      message: (d) => `図の高さが ${d.height}px あります。指定の ${d.limit}px を超えています`,
      fixes: (d) => [
        `担当の帯を減らす（今は ${d.lanes} つ。同じ人が続けて行う作業は1つの帯にまとめる）`,
        '流れを横にする（direction を "right" にする）',
        '補足（sublabel）を省くと、その帯が低くなる',
      ],
    },
    en: {
      message: (d) => `The diagram is ${d.height}px tall, which exceeds the requested ${d.limit}px`,
      fixes: (d) => [
        `Use fewer lanes (${d.lanes} now): merge work done by the same owner`,
        'Let the flow run to the right (set direction to "right")',
        'Remove sublabels to make the lanes shorter',
      ],
    },
  },
};
