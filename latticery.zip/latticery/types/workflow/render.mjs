// workflow の描画。配置の計算の結果（layout）から、SVG の要素の木を組み立てる。
// 仕様：docs/latticery/types/workflow.md の「3. 描きかた」
//
// 位置・大きさ・文字の大きさ・線の太さなど、形に関わるものは要素の属性に書く。
// 色もライトの値を属性に書き、CSS がなくても図として見えるようにする。
// テーマの切り替えは core/draw.mjs の diagramStyles()・core/steps.mjs の stepStyles() と、下の workflowStyles() で行う。
// 手順の箱・線・鏃・角の丸め・帯は、ほかの図の種類と共通のもの（core/）を使う。

import { BAND_DRAW, bandHeaderStrips, bandRule, fillBandElement, headerBandElement } from '../../core/bands.mjs';
import { BASE_COLORS, EDGE_DRAW, SAMPLE, edgeElement, edgeLabelElement, findHops, lineSample, sampleSvg } from '../../core/draw.mjs';
import { NODE_DRAW, nodeElement } from '../../core/node.mjs';
import { STEP_COLORS, STEP_SHAPES, STEP_STYLE, stepIcon, stepStyles } from '../../core/steps.mjs';
import { el, formatNumber as n } from '../../core/svg.mjs';
import { FONT_FAMILY } from '../../core/text.mjs';
import { METRICS } from './layout.mjs';

// 描き方。箱・線・帯は core/ の値を使う。
export const DRAW = {
  node: NODE_DRAW,
  edge: EDGE_DRAW,
  band: BAND_DRAW,
};

// ---- 凡例の見本 ------------------------------------------------------------------

export const LEGEND_STYLES = ['primary', 'async', 'back'];

/** 凡例に出す、線の種類（主な流れ・非同期・戻り）の見本。戻りは、前の手順へ向かうことが分かるよう右から左へ描く。 */
export function styleSample(style) {
  const base = BASE_COLORS.light;
  const primary = style === 'primary';
  return sampleSvg(lineSample({
    classes: [primary ? 'lt-primary' : null, style === 'async' ? 'lt-async' : null].filter(Boolean),
    width: primary ? DRAW.edge.primaryWidth : DRAW.edge.width,
    color: primary ? base.edgeStrong : base.edge,
    dash: style === 'async' ? '4 3' : null,
    arrow: { length: 8.5, width: primary ? 9 : 8 },
    reverse: style === 'back',
  }));
}

/** 凡例に出す、手順の種類の見本。種類の色で、その種類の形（四角・カプセル・ひし形）と記号を描く。 */
export function kindSample(kind) {
  const [fill, border, accent] = STEP_COLORS[kind].light;
  const shape = STEP_SHAPES[kind];
  const [w, h] = [SAMPLE.width - 2, SAMPLE.height - 2];
  const paint = { fill, stroke: border, 'stroke-width': 1.25 };
  const body = shape === 'diamond'
    ? el('path', { class: 'lt-node-box', d: `M${1 + w / 2} 1L${1 + w} ${1 + h / 2}L${1 + w / 2} ${1 + h}L1 ${1 + h / 2}Z`, ...paint })
    : el('rect', { class: 'lt-node-box', x: 1, y: 1, width: w, height: h, rx: shape === 'capsule' ? h / 2 : 3, ...paint });
  const icon = stepIcon(kind, { x: (SAMPLE.width - 10) / 2, y: (SAMPLE.height - 10) / 2, size: 10 });
  return sampleSvg(el('g', { class: `lt-step-${kind}` }, [body, icon]));
}

// ---- 図 ----------------------------------------------------------------------

/**
 * 配置の計算の結果から、SVG の要素の木を作る。doc はタイトルと説明に使う。
 * つながりの強調（viewer/highlight.mjs）のため、手順には data-node（ID）を、線とそのラベルには
 * data-edge（edges の中の番号）・data-from・data-to を付ける。
 */
export function renderWorkflow(layout, doc) {
  const base = BASE_COLORS.light;
  const hops = findHops(layout.edges);
  // 担当の帯は、right なら行の帯、down なら列の帯。局面の帯はその逆（core/bands.mjs）。
  const down = layout.direction === 'down';
  const laneAxis = down ? 'x' : 'y';
  const phaseAxis = down ? 'y' : 'x';
  const headerAxes = [...(layout.lanes.length > 0 ? [laneAxis] : []), ...(layout.phases.length > 0 ? [phaseAxis] : [])];
  const frame = { width: layout.width, height: layout.height, offset: layout.header };
  // 主な流れの線を後から描き、ほかの線より上に見えるようにする。
  const order = layout.edges.map((edge, i) => i).sort((p, q) => Number(layout.edges[p].primary) - Number(layout.edges[q].primary) || p - q);
  return el('svg', {
    class: 'lt-diagram lt-workflow',
    viewBox: `0 0 ${n(layout.width)} ${n(layout.height)}`,
    width: layout.width,
    height: layout.height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, doc.title),
    doc.description ? el('desc', {}, doc.description) : null,
    bandHeaderStrips(headerAxes, frame, base),
    el('g', { class: 'lt-lanes' }, layout.lanes.map((lane, i) => fillBandElement(lane, i, laneAxis, { name: 'lt-lane', base }))),
    el('g', { class: 'lt-phases' }, layout.phases.map((phase, i) => headerBandElement(phase, i, phaseAxis, { name: 'lt-phase', base }))),
    // 見出しと本体の境目の線は、帯の色の上に描く（色を敷いた帯に隠れないように）。
    bandRule(headerAxes, frame, base),
    el('g', { class: 'lt-edges' }, order.map((i) => edgeElement(layout.edges[i], i, hops[i], base))),
    el('g', { class: 'lt-edge-labels' }, order.filter((i) => layout.edges[i].labelBox)
      .map((i) => edgeLabelElement(layout.edges[i], i, base, METRICS.edge.labelSize))),
    el('g', { class: 'lt-nodes' }, layout.nodes.map((node) => nodeElement(node, { 'data-id': node.id, 'data-node': node.id }, STEP_STYLE))),
  ]);
}

// ---- テーマ --------------------------------------------------------------------

/**
 * テーマの切り替えに使う CSS のうち、workflow だけのもの（手順の種類の色・主な流れ）。
 * 図の色の変数と、箱・線・帯に共通の部分は core/draw.mjs の diagramStyles() で決める。
 */
export function workflowStyles(options = {}) {
  return [
    stepStyles(options),
    '.lt-primary .lt-edge-line{stroke:var(--lt-edge-strong)}',
    '.lt-primary .lt-arrow{fill:var(--lt-edge-strong)}',
  ].join('\n');
}
