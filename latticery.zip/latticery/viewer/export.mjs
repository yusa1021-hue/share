// 図の書き出し（SVG・PNG）。共通仕様「9. 出力 HTML」の「書き出しと印刷」、決定記録 No.45・No.80。
// 図だけの書き出しと、タイトル・凡例付きの書き出し（viewer/figure.mjs の図版）の2通り。
// 色は表示中のテーマに合わせ、背景を塗り、100% の大きさにする。
// PNG は、SVG を blob: の URL の画像として読み込み、canvas に描いて作る（CSP で img-src blob: だけを許している）。

import { SVG_NS, fitText, toDom } from '../core/svg.mjs';

export const PNG_SCALE = 2;
// ブラウザの canvas の大きさの上限。ブラウザによって違うので、小さいほう（Safari）に合わせる。
const MAX_SIDE = 16384;
const MAX_AREA = 4096 * 4096;
// 色を CSS（テーマ）で決めている要素。書き出すときは、表示中の色を属性に書き込む。
const PAINTED = 'rect,path,circle,ellipse,line,polyline,polygon,text,tspan';

// タイトル・凡例付きの書き出しのファイル名に足す文字（ec-site.html なら ec-site-with-legend.svg）。
export const FIGURE_SUFFIX = '-with-legend';

/**
 * 書き出すファイルの名前。HTML のファイル名の拡張子を変えたもの。名前が取れないときは diagram にする。
 * suffix は拡張子の前に足す文字（タイトル・凡例付きの書き出しでは -with-legend）。
 */
export function exportFileName(pathname, extension, suffix = '') {
  let name = String(pathname ?? '').split('/').pop();
  try {
    name = decodeURIComponent(name);
  } catch {
    // % の並びが崩れた名前は、そのまま使う。
  }
  const base = name.replace(/\.html?$/i, '').trim();
  return `${base || 'diagram'}${suffix}.${extension}`;
}

/** PNG の倍率。100% の大きさの2倍にし、canvas の上限を超えるときは下げる。 */
export function pngScale(width, height) {
  return Math.min(PNG_SCALE, MAX_SIDE / width, MAX_SIDE / height, Math.sqrt(MAX_AREA / (width * height)));
}

/**
 * 表示中の図を、ほかのアプリで開いても同じ色に見える SVG の文字列にする。
 * テーマの色は閲覧画面の CSS で決まっているので、要素ごとの実際の色（getComputedStyle）を属性に書き込む。
 * 拡大・縮小のための style は外し、width・height の属性（100% の大きさ）で書き出す。
 */
export function standaloneSvg(window, svg) {
  const document = svg.ownerDocument;
  const clone = svg.cloneNode(true);
  clone.removeAttribute('style');
  const copies = clone.querySelectorAll(PAINTED);
  svg.querySelectorAll(PAINTED).forEach((original, i) => {
    const style = window.getComputedStyle(original);
    copies[i].setAttribute('fill', style.fill);
    copies[i].setAttribute('stroke', style.stroke);
  });
  // 閲覧画面の操作のためだけのもの（見えない当たり判定の線と、つながりの強調の目印）は書き出さない。
  // 強調で薄くした色は CSS の opacity なので、上で書き込む色には入らない。
  for (const hit of clone.querySelectorAll('path[data-hit]')) hit.remove();
  clone.removeAttribute('data-highlight');
  for (const name of ['data-active', 'data-selected']) {
    for (const element of clone.querySelectorAll(`g[${name}]`)) element.removeAttribute(name);
  }
  // 背景は、タイトル・説明の後、ほかの要素より先に置く（いちばん下に描く）。
  const background = document.createElementNS(SVG_NS, 'rect');
  for (const [name, value] of [['x', 0], ['y', 0], ['width', svg.getAttribute('width')], ['height', svg.getAttribute('height')]]) {
    background.setAttribute(name, String(value));
  }
  background.setAttribute('fill', window.getComputedStyle(document.body).backgroundColor);
  const first = [...clone.children].find((child) => child.tagName !== 'title' && child.tagName !== 'desc') ?? null;
  clone.insertBefore(background, first);
  return `<?xml version="1.0" encoding="UTF-8"?>\n${new window.XMLSerializer().serializeToString(clone)}\n`;
}

/**
 * タイトル・凡例付きの SVG の文字列。figure は viewer/figure.mjs の figure() が返す図版の要素の木で、
 * その中の data-figure-diagram の g に、表示中の図の中身を写して入れる。
 * 色を読み取るため、図版を見えない位置にいったんページに置き、文字の幅を合わせてから、standaloneSvg で文字列にする。
 */
export function figureSvg(window, svg, figure) {
  const document = svg.ownerDocument;
  const root = toDom(figure, document);
  const slot = root.querySelectorAll('g[data-figure-diagram]')[0];
  slot.removeAttribute('data-figure-diagram');
  for (const child of svg.children) {
    if (child.tagName !== 'title' && child.tagName !== 'desc') slot.appendChild(child.cloneNode(true));
  }
  root.setAttribute('style', 'position: absolute; left: -100000px; top: 0; visibility: hidden');
  document.body.append(root);
  try {
    fitText(root);
    return standaloneSvg(window, root);
  } finally {
    root.remove();
  }
}

/** SVG の文字列（standaloneSvg・figureSvg で作ったもの）を、SVG のファイルとして保存する。 */
export function saveSvg(document, window, source, suffix = '') {
  const blob = new window.Blob([source], { type: 'image/svg+xml' });
  download(document, window, blob, exportFileName(window.location.pathname, 'svg', suffix));
}

/** SVG の文字列を、PNG のファイルとして保存する。size はその SVG の大きさ。作れなかったときは reject する。 */
export async function savePng(document, window, text, size, suffix = '') {
  const source = window.URL.createObjectURL(new window.Blob([text], { type: 'image/svg+xml' }));
  try {
    const image = new window.Image();
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('SVG を画像として読み込めない'));
      image.src = source;
    });
    const scale = pngScale(size.width, size.height);
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(size.width * scale);
    canvas.height = Math.round(size.height * scale);
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob((result) => (result ? resolve(result) : reject(new Error('PNG を作れない'))), 'image/png');
    });
    download(document, window, blob, exportFileName(window.location.pathname, 'png', suffix));
  } finally {
    window.URL.revokeObjectURL(source);
  }
}

// ファイルとして保存させる（download 属性を付けたリンクを押す）。
function download(document, window, blob, name) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  // すぐに消すと保存が始まらないブラウザがあるので、少し待ってから消す。
  window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
}
