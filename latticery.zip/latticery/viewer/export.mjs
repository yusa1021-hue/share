// 図の書き出し（SVG・PNG）。共通仕様「9. 出力 HTML」の「書き出しと印刷」、決定記録 No.45。
// 書き出すのは図（SVG の部分）だけ。色は表示中のテーマに合わせ、背景を塗り、100% の大きさにする。
// PNG は、SVG を blob: の URL の画像として読み込み、canvas に描いて作る（CSP で img-src blob: だけを許している）。

import { SVG_NS } from '../core/svg.mjs';

export const PNG_SCALE = 2;
// ブラウザの canvas の大きさの上限。ブラウザによって違うので、小さいほう（Safari）に合わせる。
const MAX_SIDE = 16384;
const MAX_AREA = 4096 * 4096;
// 色を CSS（テーマ）で決めている要素。書き出すときは、表示中の色を属性に書き込む。
const PAINTED = 'rect,path,circle,ellipse,line,polyline,polygon,text,tspan';

/** 書き出すファイルの名前。HTML のファイル名の拡張子を変えたもの。名前が取れないときは diagram にする。 */
export function exportFileName(pathname, extension) {
  let name = String(pathname ?? '').split('/').pop();
  try {
    name = decodeURIComponent(name);
  } catch {
    // % の並びが崩れた名前は、そのまま使う。
  }
  const base = name.replace(/\.html?$/i, '').trim();
  return `${base || 'diagram'}.${extension}`;
}

/** PNG の倍率。100% の大きさの2倍にし、canvas の上限を超えるときは下げる。 */
export function pngScale(width, height) {
  return Math.min(PNG_SCALE, MAX_SIDE / width, MAX_SIDE / height, Math.sqrt(MAX_AREA / (width * height)));
}

/**
 * 表示中の図を、ほかのアプリで開いても同じ色に見える SVG の文字列にする。
 * テーマの色は閲覧画面の CSS で決まっているので、要素ごとの実際の色（getComputedStyle）を属性に書き込む。
 * 拡大・縮小のための style は外し、width・height の属性（100% の大きさ）で書き出す。
 */
export function standaloneSvg(window, svg) {
  const document = svg.ownerDocument;
  const clone = svg.cloneNode(true);
  clone.removeAttribute('style');
  const copies = clone.querySelectorAll(PAINTED);
  svg.querySelectorAll(PAINTED).forEach((original, i) => {
    const style = window.getComputedStyle(original);
    copies[i].setAttribute('fill', style.fill);
    copies[i].setAttribute('stroke', style.stroke);
  });
  // 背景は、タイトル・説明の後、ほかの要素より先に置く（いちばん下に描く）。
  const background = document.createElementNS(SVG_NS, 'rect');
  for (const [name, value] of [['x', 0], ['y', 0], ['width', svg.getAttribute('width')], ['height', svg.getAttribute('height')]]) {
    background.setAttribute(name, String(value));
  }
  background.setAttribute('fill', window.getComputedStyle(document.body).backgroundColor);
  const first = [...clone.children].find((child) => child.tagName !== 'title' && child.tagName !== 'desc') ?? null;
  clone.insertBefore(background, first);
  return `<?xml version="1.0" encoding="UTF-8"?>\n${new window.XMLSerializer().serializeToString(clone)}\n`;
}

/** 表示中の図を SVG のファイルとして保存する。 */
export function saveSvg(document, window, svg) {
  const blob = new window.Blob([standaloneSvg(window, svg)], { type: 'image/svg+xml' });
  download(document, window, blob, exportFileName(window.location.pathname, 'svg'));
}

/** 表示中の図を PNG のファイルとして保存する。size は図の 100% の大きさ。作れなかったときは reject する。 */
export async function savePng(document, window, svg, size) {
  const source = window.URL.createObjectURL(new window.Blob([standaloneSvg(window, svg)], { type: 'image/svg+xml' }));
  try {
    const image = new window.Image();
    await new Promise((resolve, reject) => {
      image.onload = resolve;
      image.onerror = () => reject(new Error('SVG を画像として読み込めない'));
      image.src = source;
    });
    const scale = pngScale(size.width, size.height);
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(size.width * scale);
    canvas.height = Math.round(size.height * scale);
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise((resolve, reject) => {
      canvas.toBlob((result) => (result ? resolve(result) : reject(new Error('PNG を作れない'))), 'image/png');
    });
    download(document, window, blob, exportFileName(window.location.pathname, 'png'));
  } finally {
    window.URL.revokeObjectURL(source);
  }
}

// ファイルとして保存させる（download 属性を付けたリンクを押す）。
function download(document, window, blob, name) {
  const url = window.URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.hidden = true;
  document.body.append(link);
  link.click();
  link.remove();
  // すぐに消すと保存が始まらないブラウザがあるので、少し待ってから消す。
  window.setTimeout(() => window.URL.revokeObjectURL(url), 1000);
}
