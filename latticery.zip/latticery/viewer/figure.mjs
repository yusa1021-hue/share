// タイトル・凡例付きの書き出しに使う、1枚の SVG（図版）の配置と要素の木。決定記録 No.80。
// 上からタイトル・説明・図・区切り線・凡例を並べる。図は、書き出すときに表示中の図の中身を入れる（viewer/export.mjs の figureSvg）。
// 凡例は閲覧画面の凡例と同じ項目（図の種類の legend() が返すもの）を、同じ順に、幅に合わせて折り返して並べる。

import { BASE_COLORS, SAMPLE } from '../core/draw.mjs';
import { ICON, KIND_COLORS } from '../core/kinds.mjs';
import { el, formatNumber as n } from '../core/svg.mjs';
import { FONT_FAMILY, estimateWidth } from '../core/text.mjs';

// 寸法（px）。padding は外周の余白。inset は図の種類の配置が図の外周に取っている余白で、
// 図をその分だけ外へずらし、部品の端をタイトル・凡例の左端にそろえる。
// title・description の line は1行の高さ。headerGap は見出しと図の間、ruleGap は図と区切り線・区切り線と凡例の間。
// legend：row は1行の高さ、gapX・gapY は項目の間、labelGap は記号・見本と名前の間、swatch は部品の種類の四角の大きさ、
// divider は部品の種類と線などの種類の間の区切り線の左右の余白（閲覧画面の凡例と同じ）。
export const FIGURE = {
  padding: 24,
  inset: 12,
  title: { size: 18, line: 26 },
  description: { size: 13, line: 20, gap: 2 },
  headerGap: 16,
  ruleGap: 14,
  legend: { size: 13, row: 22, gapX: 16, gapY: 8, labelGap: 6, swatch: 22, swatchRadius: 5, divider: 16 },
};

// 区切り線の色（ライト）。閲覧画面の枠の線（viewer/theme.css の --line）と同じ。
export const FIGURE_RULE = '#d9dde3';

// 凡例の1項目の幅。
function itemWidth(item) {
  const m = FIGURE.legend;
  return (item.sample ? SAMPLE.width : m.swatch) + m.labelGap + estimateWidth(item.label, m.size);
}

/**
 * 凡例の項目を、幅 width に収まるよう行に分けて並べる。返り値は項目ごとの位置（左上）と、区切り線の位置と、全体の高さ。
 * 区切り線は、部品の種類（icon）の後の最初の見本（sample）の前に引く。行の始めに来たときは引かない。
 */
export function legendRows(items, width) {
  const m = FIGURE.legend;
  const placed = [];
  let divider = null;
  let [x, row] = [0, 0];
  items.forEach((item, i) => {
    const w = itemWidth(item);
    const first = item.sample && i > 0 && !items[i - 1].sample;
    const extra = first ? m.divider + 1 : 0;
    if (x > 0 && x + m.gapX + extra + w > width) [x, row] = [0, row + 1];
    const y = row * (m.row + m.gapY);
    if (x > 0) {
      x += m.gapX;
      if (first) {
        divider = { x: x + 0.5, y };
        x += extra;
      }
    }
    placed.push({ item, x, y, width: w });
    x += w;
  });
  const rows = items.length > 0 ? row + 1 : 0;
  return { placed, divider, height: rows > 0 ? rows * m.row + (rows - 1) * m.gapY : 0 };
}

/**
 * 図版の配置と要素の木。size は図の 100% の大きさ、className は図の svg 要素のクラス（図の種類ごとの CSS に使う）。
 * items は凡例の項目（凡例を出さないときは空の配列）。
 * 返り値は、要素の木（tree）・大きさ（width・height）・凡例を入れたか（legend）。
 * tree の中の data-figure-diagram を付けた g に、図の中身を入れて使う。
 */
export function figure(size, { title, description, items = [], className = 'lt-diagram' }) {
  const p = FIGURE.padding;
  const m = FIGURE.legend;
  const base = BASE_COLORS.light;
  const titleWidth = estimateWidth(title, FIGURE.title.size, { bold: true });
  const descriptionWidth = description ? estimateWidth(description, FIGURE.description.size) : 0;
  const diagramWidth = size.width - 2 * FIGURE.inset;
  const content = Math.ceil(Math.max(diagramWidth, titleWidth, descriptionWidth, ...items.map(itemWidth)));
  const width = content + 2 * p;

  const header = FIGURE.title.line + (description ? FIGURE.description.gap + FIGURE.description.line : 0);
  const diagramTop = p + header + FIGURE.headerGap;
  const diagramBottom = diagramTop + size.height - 2 * FIGURE.inset;
  const legend = legendRows(items, content);
  const ruleY = diagramBottom + FIGURE.ruleGap;
  const legendTop = ruleY + FIGURE.ruleGap;
  const height = (items.length > 0 ? legendTop + legend.height : diagramBottom) + p;

  const text = (className, x, y, fontSize, value, attrs = {}) => el('text', {
    class: className, x, y, 'font-size': fontSize, 'dominant-baseline': 'central', fill: attrs.fill,
    'font-weight': attrs.bold ? 700 : null, 'data-width': estimateWidth(value, fontSize, { bold: attrs.bold }),
  }, value);
  const legendItem = ({ item, x, y }) => {
    const [left, top] = [p + x, legendTop + y];
    // 種類の四角の色（ライト）。項目が持っていなければ部品の種類の色。テーマの色は className（なければ .lt-kind-<key>）の CSS で決まる。
    const [fill, stroke] = item.colors ?? KIND_COLORS[item.key]?.light ?? [];
    const mark = item.sample
      ? el('g', { transform: `translate(${n(left)} ${n(top + (m.row - SAMPLE.height) / 2)})` }, item.sample.children)
      : el('g', { class: item.className ?? `lt-kind-${item.key}`, transform: `translate(${n(left)} ${n(top)})` }, [
        el('rect', {
          class: 'lt-node-box', x: 0.625, y: 0.625, width: m.swatch - 1.25, height: m.swatch - 1.25, rx: m.swatchRadius,
          fill, stroke, 'stroke-width': 1.25,
        }),
        el('g', { transform: `translate(${n((m.swatch - ICON.size) / 2)} ${n((m.swatch - ICON.size) / 2)})` }, [item.icon]),
      ]);
    const labelX = left + (item.sample ? SAMPLE.width : m.swatch) + m.labelGap;
    return el('g', { class: 'lt-figure-item' }, [mark, text('lt-figure-label', labelX, top + m.row / 2, m.size, item.label, { fill: base.text })]);
  };

  const tree = el('svg', {
    class: 'lt-diagram lt-figure',
    viewBox: `0 0 ${n(width)} ${n(height)}`,
    width,
    height,
    role: 'img',
    'font-family': FONT_FAMILY,
  }, [
    el('title', {}, title),
    description ? el('desc', {}, description) : null,
    text('lt-figure-title', p, p + FIGURE.title.line / 2, FIGURE.title.size, title, { fill: base.text, bold: true }),
    description
      ? text('lt-figure-description', p, p + FIGURE.title.line + FIGURE.description.gap + FIGURE.description.line / 2, FIGURE.description.size, description, { fill: base.muted })
      : null,
    el('g', {
      class: className,
      transform: `translate(${n(p - FIGURE.inset + (content - diagramWidth) / 2)} ${n(diagramTop - FIGURE.inset)})`,
      'data-figure-diagram': '',
    }),
    items.length > 0 ? el('g', { class: 'lt-figure-legend' }, [
      el('path', { class: 'lt-figure-rule', d: `M${p} ${n(ruleY + 0.5)}H${n(width - p)}`, stroke: FIGURE_RULE, 'stroke-width': 1 }),
      legend.divider
        ? el('path', { class: 'lt-figure-rule', d: `M${n(p + legend.divider.x)} ${n(legendTop + legend.divider.y + 3)}v${m.row - 6}`, stroke: FIGURE_RULE, 'stroke-width': 1 })
        : null,
      ...legend.placed.map(legendItem),
    ]) : null,
  ]);
  return { tree, width, height, legend: items.length > 0 };
}
