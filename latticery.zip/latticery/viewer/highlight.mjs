// つながりの強調（決定記録 No.54）。部品か線にポインターを合わせている間、それと直接つながるものを強調し、ほかを薄くする。
// クリック（タップ）すると強調したままにし、同じものをもう一度クリックする・何もない所をクリックする・Esc で戻す。
// ドラッグで図を動かしたときは、クリックとみなさない。
//
// 図の種類によらず、描画の要素の目印だけを使う：部品は data-node（部品の ID）、線とそのラベルは data-edge（線の番号）・data-from・data-to。
// 強調している間は、SVG に data-highlight を付け、強調する要素に data-active を付ける。薄くするのは CSS（theme.css）で行う。

const CLICK_DISTANCE = 5; // これより動いたら、クリックでなくドラッグとみなす（px）

/** SVG の目印から、部品と線のつながりを読み取る。 */
export function readConnections(svg) {
  const nodes = new Map();
  const edges = new Map();
  for (const element of svg.querySelectorAll('g[data-node]')) {
    const id = element.getAttribute('data-node');
    nodes.set(id, [...(nodes.get(id) ?? []), element]);
  }
  for (const element of svg.querySelectorAll('g[data-edge]')) {
    const index = element.getAttribute('data-edge');
    const edge = edges.get(index) ?? { from: element.getAttribute('data-from'), to: element.getAttribute('data-to'), elements: [] };
    edge.elements.push(element);
    edges.set(index, edge);
  }
  return { nodes, edges };
}

/**
 * 強調するもの。target は { node: ID } か { edge: 番号 }。
 * 部品なら、その部品・つながる線・線の先の部品。線なら、その線と両端の部品。
 */
export function highlightSet(connections, target) {
  const nodes = new Set();
  const edges = new Set();
  if (target.node !== undefined) {
    nodes.add(target.node);
    for (const [index, edge] of connections.edges) {
      if (edge.from !== target.node && edge.to !== target.node) continue;
      edges.add(index);
      nodes.add(edge.from);
      nodes.add(edge.to);
    }
  } else {
    const edge = connections.edges.get(target.edge);
    if (edge) {
      edges.add(target.edge);
      nodes.add(edge.from);
      nodes.add(edge.to);
    }
  }
  return { nodes, edges };
}

// element から SVG までの祖先をたどり、部品か線の目印を探す。
function targetOf(element, svg) {
  for (let node = element; node && node !== svg; node = node.parentNode) {
    if (typeof node.getAttribute !== 'function') continue;
    const id = node.getAttribute('data-node');
    if (id !== null) return { node: id };
    const index = node.getAttribute('data-edge');
    if (index !== null) return { edge: index };
  }
  return null;
}

const sameTarget = (a, b) => a !== null && b !== null && a.node === b.node && a.edge === b.edge;

/**
 * 描画領域に、つながりの強調の操作を付ける。返り値の state() は、今の状態（テスト用）。
 * ポインターを合わせる強調は、マウスとペンだけにする（タッチには合わせる操作がなく、タップの前に pointerover が来るため）。
 * 強調したままにしているもの（pinned）には、data-selected も付ける。
 */
export function setupHighlight(window, viewport, svg) {
  const connections = readConnections(svg);
  let hover = null;
  let pinned = null;

  const apply = () => {
    const target = pinned ?? hover;
    const shown = target ? highlightSet(connections, target) : null;
    toggle(svg, 'data-highlight', shown !== null);
    for (const [id, elements] of connections.nodes) {
      for (const element of elements) {
        toggle(element, 'data-active', shown?.nodes.has(id));
        toggle(element, 'data-selected', pinned?.node === id);
      }
    }
    for (const [index, edge] of connections.edges) {
      for (const element of edge.elements) {
        toggle(element, 'data-active', shown?.edges.has(index));
        toggle(element, 'data-selected', pinned?.edge === index);
      }
    }
  };

  svg.addEventListener('pointerover', (event) => {
    if (event.pointerType === 'touch' || viewport.hasAttribute('data-dragging')) return;
    const next = targetOf(event.target, svg);
    if (sameTarget(next, hover) || (next === null && hover === null)) return;
    hover = next;
    apply();
  });
  svg.addEventListener('pointerleave', () => {
    if (hover === null) return;
    hover = null;
    apply();
  });

  // クリックは、押した位置から大きく動かずに離したときだけ。押したときの要素で決める
  // （図を動かすために、描画領域がポインターを捕まえると、離したときの要素は描画領域になるため）。
  let press = null;
  viewport.addEventListener('pointerdown', (event) => {
    if (event.button !== undefined && event.button !== 0) return;
    press = { id: event.pointerId, x: event.clientX, y: event.clientY, target: targetOf(event.target, svg) };
  });
  viewport.addEventListener('pointerup', (event) => {
    if (!press || event.pointerId !== press.id) return;
    const moved = Math.hypot(event.clientX - press.x, event.clientY - press.y);
    const { target } = press;
    press = null;
    if (moved >= CLICK_DISTANCE) return;
    pinned = target === null || sameTarget(target, pinned) ? null : target;
    // タッチでは、合わせる強調を使わないので、固定をやめたら強調も消える。
    if (event.pointerType === 'touch') hover = null;
    apply();
  });
  viewport.addEventListener('pointercancel', () => { press = null; });

  // Esc で固定をやめる。ほかの処理（メニューを閉じるなど）が使った Esc は無視し、使ったときは後の処理（最大化の解除）に回さない。
  window.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || event.defaultPrevented || pinned === null) return;
    event.preventDefault();
    pinned = null;
    apply();
  });

  return { state: () => ({ hover, pinned }) };
}

function toggle(element, name, on) {
  if (on) element.setAttribute(name, '');
  else element.removeAttribute(name);
}
