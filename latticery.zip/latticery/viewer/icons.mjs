// 閲覧画面のボタンの記号。16×16 の座標に、塗りのない線（文字と同じ色）で描く。

import { el } from '../core/svg.mjs';

const ICONS = {
  zoomOut: [['path', { d: 'M3.5 8h9' }]],
  zoomIn: [['path', { d: 'M3.5 8h9M8 3.5v9' }]],
  // 四隅のかぎ：全体を表示
  fit: [['path', { d: 'M2.5 6V2.5H6M10 2.5h3.5V6M13.5 10v3.5H10M6 13.5H2.5V10' }]],
  // 外向きの斜めの矢印：最大化
  maximize: [['path', { d: 'M9.5 2.5h4v4M13.5 2.5 9 7M6.5 13.5h-4v-4M2.5 13.5 7 9' }]],
  // 内向きの斜めの矢印：元の大きさに戻す
  restore: [['path', { d: 'M13.5 2.5 9.5 6.5M9.5 3.5v3h3M2.5 13.5l4-4M6.5 12.5v-3h-3' }]],
  // 下向きの矢印と受け皿：保存
  save: [['path', { d: 'M8 2.5v7.5M4.75 6.75 8 10l3.25-3.25M2.5 13.5h11' }]],
  print: [
    ['path', { d: 'M4.5 5.5v-3h7v3M4.5 11.5h-2v-6h11v6h-2' }],
    ['rect', { x: 4.5, y: 9, width: 7, height: 4.5, rx: 0.5 }],
  ],
  // 月：ダーク表示にする
  dark: [['path', { d: 'M13.5 9.6A5.75 5.75 0 1 1 6.4 2.5a4.6 4.6 0 0 0 7.1 7.1z' }]],
  // 太陽：ライト表示にする
  light: [
    ['circle', { cx: 8, cy: 8, r: 2.75 }],
    ['path', { d: 'M8 1.5v1.5M8 13v1.5M1.5 8H3M13 8h1.5M3.4 3.4l1.06 1.06M11.54 11.54l1.06 1.06M3.4 12.6l1.06-1.06M11.54 4.46l1.06-1.06' }],
  ],
};

/** ボタンの記号の要素の木（core/svg.mjs の形）。読み上げでは読まない（ボタンの名前は aria-label で付ける）。 */
export function uiIcon(name) {
  return el('svg', {
    class: 'lt-ui-icon', width: 16, height: 16, viewBox: '0 0 16 16', 'aria-hidden': 'true',
    fill: 'none', stroke: 'currentColor', 'stroke-width': 1.6, 'stroke-linecap': 'round', 'stroke-linejoin': 'round',
  }, ICONS[name].map(([tag, attrs]) => el(tag, attrs)));
}
