// 閲覧画面の動き（ブラウザ用）。雛形 HTML に埋め込んだ JSON を読み、検証・配置・描画をして表示する。
// 処理はコマンドと同じ core/check.mjs を使う（共通仕様「6. 処理の段階」）。
// 利用者の文字は textContent と属性だけで入れ、innerHTML は使わない（共通仕様「9. 出力 HTML」）。

import { analyzeSource } from '../core/check.mjs';
import { LANGS } from '../core/i18n.mjs';
import { createTypes } from '../core/registry.mjs';
import { el, fitText, toDom } from '../core/svg.mjs';
import { FIGURE_SUFFIX, figureSvg, savePng, saveSvg, standaloneSvg } from './export.mjs';
import { figure } from './figure.mjs';
import { setupHighlight } from './highlight.mjs';
import { uiIcon } from './icons.mjs';
import { setupZoom } from './zoom.mjs';

// 固定の文言。
export const UI = {
  ja: {
    toDark: 'ダーク表示にする',
    toLight: 'ライト表示にする',
    legend: '凡例',
    notes: '説明',
    error: 'エラー',
    warning: '警告',
    summary: (errors, warnings) => [errors > 0 ? `エラー ${errors} 件` : '', warnings > 0 ? `警告 ${warnings} 件` : ''].filter(Boolean).join('・'),
    cannotDraw: 'エラーがあるため、図を表示できません。次の問題を直してください。',
    target: '対象',
    code: 'コード',
    fixes: '直し方の候補',
    noData: '図のデータが入っていません。latticery の build で、JSON を入れた HTML を作ってください。',
    viewport: '図の表示領域。ドラッグか矢印キーで移動、Ctrl（Mac は ⌘）を押しながらのホイールか ＋ − のキーで拡大・縮小、0 のキーで全体を表示。部品や線にポインターを合わせるか、クリックすると、つながりを強調する（Esc で戻す）',
    zoom: '拡大・縮小',
    zoomOut: '縮小',
    zoomIn: '拡大',
    fit: '全体を表示',
    actualSize: '100% で表示',
    exportTools: '書き出し',
    saveMenu: '保存・印刷',
    saveSvg: 'SVG で保存',
    savePng: 'PNG で保存',
    // タイトル・凡例付きの書き出し。凡例を出さない図では、タイトルだけが付く。
    saveFigureSvg: (legend) => `SVG で保存（${legend ? 'タイトル・凡例付き' : 'タイトル付き'}）`,
    saveFigurePng: (legend) => `PNG で保存（${legend ? 'タイトル・凡例付き' : 'タイトル付き'}）`,
    print: '印刷',
    view: '表示',
    maximize: '最大化',
    restore: '元の大きさに戻す',
    exportFailed: '画像を書き出せませんでした。',
  },
  en: {
    toDark: 'Switch to dark',
    toLight: 'Switch to light',
    legend: 'Legend',
    notes: 'Notes',
    error: 'Error',
    warning: 'Warning',
    summary: (errors, warnings) => [
      errors > 0 ? `${errors} error${errors === 1 ? '' : 's'}` : '',
      warnings > 0 ? `${warnings} warning${warnings === 1 ? '' : 's'}` : '',
    ].filter(Boolean).join(', '),
    cannotDraw: 'The diagram cannot be drawn because of errors. Fix the problems below.',
    target: 'Target',
    code: 'Code',
    fixes: 'Possible fixes',
    noData: 'This file has no diagram data. Use latticery build to create an HTML file from a JSON file.',
    viewport: 'Diagram area. Drag or use the arrow keys to move. Use Ctrl (⌘ on Mac) with the mouse wheel, or the + and - keys, to zoom. Press 0 to fit. Point at or click a node or line to highlight its connections (Esc to clear).',
    zoom: 'Zoom',
    zoomOut: 'Zoom out',
    zoomIn: 'Zoom in',
    fit: 'Fit to window',
    actualSize: 'Actual size (100%)',
    exportTools: 'Export',
    saveMenu: 'Save or print',
    saveSvg: 'Save SVG',
    savePng: 'Save PNG',
    saveFigureSvg: (legend) => `Save SVG with title${legend ? ' and legend' : ''}`,
    saveFigurePng: (legend) => `Save PNG with title${legend ? ' and legend' : ''}`,
    print: 'Print',
    view: 'View',
    maximize: 'Maximize',
    restore: 'Restore size',
    exportFailed: 'Could not export the image.',
  },
};

// ブラウザの言語設定（ja-JP など）から、対応している言語を選ぶ。
export function browserLang(languages) {
  return (languages ?? []).map((tag) => String(tag).toLowerCase().split('-')[0]).find((lang) => LANGS.includes(lang));
}

// 雛形にデータがまだ入っていないか（置き換えの目印の行が残っているか）。
// 置き換えの目印をこのファイルにそのまま書くと、まとめたスクリプトの中も置き換えられてしまうので、分けて書く。
export function isEmptyTemplate(source) {
  return source.trim() === ['__LATTICERY', 'DATA__'].join('_');
}

/** 閲覧画面を組み立てる。document・window はブラウザのもの。 */
export function start(document, window) {
  const $ = (id) => document.getElementById(id);
  const source = $('latticery-data').textContent;
  const types = createTypes(JSON.parse($('latticery-schemas').textContent));
  const fallbackLang = browserLang(window.navigator.languages ?? [window.navigator.language]);

  if (isEmptyTemplate(source)) {
    const lang = fallbackLang ?? 'en';
    setupPage(document, window, lang, null);
    $('lt-problems').append(html(document, 'p', { class: 'lt-lead' }, UI[lang].noData));
    return;
  }

  const { report, layout, doc, lang } = analyzeSource(source, types, { fallbackLang });
  setupPage(document, window, lang, doc);
  showProblems(document, $('lt-problems'), report, UI[lang]);
  if (!layout) return;

  const type = types[doc.type];
  const svg = toDom(type.render(layout, doc), document);
  const viewport = html(document, 'div', { class: 'lt-viewport', tabindex: '0', role: 'group', 'aria-label': UI[lang].viewport }, [svg]);
  // 操作の列・描画領域・凡例を、1つの枠にまとめる（最大化するときは、この枠を画面いっぱいにする）。
  const toolbar = html(document, 'div', { class: 'lt-toolbar' });
  const legendItems = doc.legend !== false ? type.legend(doc, lang) : [];
  const legend = legendBar(document, legendItems, UI[lang]);
  const frame = html(document, 'div', { class: 'lt-frame' }, [toolbar, viewport, legend]);
  $('lt-figure').append(frame);
  fitText(svg);
  setupHighlight(window, viewport, svg);
  if (doc.notes) showNotes(document, $('lt-notes'), doc.notes, type, UI[lang]);
  // 描画領域の大きさは、凡例と説明カードまで入れてから測る。
  // タイトル・凡例付きの書き出しに使う図版。凡例の項目は閲覧画面の凡例と同じ。
  const size = { width: layout.width, height: layout.height };
  const sheet = figure(size, { title: doc.title, description: doc.description, items: legendItems, className: svg.getAttribute('class') });
  showToolbar(document, window, { frame, toolbar, viewport, legend, theme: $('lt-theme'), title: doc.title }, svg, size, sheet, UI[lang]);
}

// 言語・タイトル・説明・テーマの切り替えボタン。
function setupPage(document, window, lang, doc) {
  const ui = UI[lang];
  document.documentElement.lang = lang;
  if (doc && typeof doc.title === 'string') {
    document.title = doc.title;
    document.getElementById('lt-title').textContent = doc.title;
  }
  if (doc && typeof doc.description === 'string') {
    const description = document.getElementById('lt-description');
    description.textContent = doc.description;
    description.hidden = false;
  }

  // テーマの初期値は OS の設定に従う。ボタンで切り替えた後は、その選択を保つ。
  // 印刷の間はライトにする（ダークの明るい文字は、白い紙では読めないため）。
  const root = document.documentElement;
  const button = document.getElementById('lt-theme');
  const media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let chosen = null;
  let printing = false;
  const apply = () => {
    const theme = printing ? 'light' : chosen ?? (media && media.matches ? 'dark' : 'light');
    root.setAttribute('data-theme', theme);
    // 記号は、押したときに切り替わる先を表す（ライトのときは月、ダークのときは太陽）。
    const label = theme === 'dark' ? ui.toLight : ui.toDark;
    button.replaceChildren(toDom(uiIcon(theme === 'dark' ? 'light' : 'dark'), document));
    button.setAttribute('aria-label', label);
    button.setAttribute('title', label);
  };
  button.addEventListener('click', () => {
    chosen = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    apply();
  });
  if (media && media.addEventListener) media.addEventListener('change', apply);
  window.addEventListener('beforeprint', () => { printing = true; apply(); });
  window.addEventListener('afterprint', () => { printing = false; apply(); });
  apply();
  button.hidden = false;
}

// 図の上の操作の列。左に拡大・縮小のボタンと拡大率の表示、右に保存・印刷のメニュー、テーマの切り替え、最大化。
// 保存・印刷のメニューは、図だけの保存・タイトルと凡例付きの保存・印刷を、区切り線で分けて並べる（決定記録 No.80）。
// sheet は、タイトル・凡例付きの書き出しに使う図版（viewer/figure.mjs の figure() の返り値）。
// ボタンは記号（と短い文字）で表し、読み上げ用の名前（aria-label）と、ポインターを合わせたときの説明（title）を付ける。
// 押しても何も変わらないボタンは aria-disabled にする（disabled にすると、押した直後にフォーカスが外れるため）。
// テーマの切り替えボタンは、図を出すときだけ、ヘッダーからこの列へ移す（最大化しても押せるように）。
// 真ん中には図のタイトルを置き、最大化の間だけ見せる（ヘッダーが隠れるため。theme.css）。
function showToolbar(document, window, parts, svg, size, sheet, ui) {
  const { frame, toolbar, viewport, legend, theme, title } = parts;
  const button = (content, label, action) => {
    const element = html(document, 'button', { type: 'button', class: 'lt-button lt-tool', 'aria-label': label, title: label }, content);
    element.addEventListener('click', () => {
      if (element.getAttribute('aria-disabled') !== 'true') action();
    });
    return element;
  };
  const icon = (name) => toDom(uiIcon(name), document);
  const text = (value) => html(document, 'span', { class: 'lt-tool-text' }, value);
  let zoom = null;
  const zoomOut = button(icon('zoomOut'), ui.zoomOut, () => zoom.zoomOut());
  const level = html(document, 'span', { class: 'lt-zoom-level', 'aria-live': 'polite' });
  const zoomIn = button(icon('zoomIn'), ui.zoomIn, () => zoom.zoomIn());
  const fit = button(icon('fit'), ui.fit, () => zoom.fit());
  const actualSize = button(text('1:1'), ui.actualSize, () => zoom.actualSize());

  const status = html(document, 'span', { class: 'lt-status', role: 'status' });
  const exporting = (save) => async () => {
    status.textContent = '';
    try {
      await save();
    } catch {
      status.textContent = ui.exportFailed;
    }
  };
  const figureText = () => figureSvg(window, svg, sheet.tree);
  const figureSize = { width: sheet.width, height: sheet.height };
  const saveMenu = menu(document, window, icon('save'), ui.saveMenu, [
    { icon: icon('save'), label: ui.saveSvg, action: exporting(() => saveSvg(document, window, standaloneSvg(window, svg))) },
    { icon: icon('save'), label: ui.savePng, action: exporting(() => savePng(document, window, standaloneSvg(window, svg), size)) },
    null,
    { icon: icon('save'), label: ui.saveFigureSvg(sheet.legend), action: exporting(() => saveSvg(document, window, figureText(), FIGURE_SUFFIX)) },
    { icon: icon('save'), label: ui.saveFigurePng(sheet.legend), action: exporting(() => savePng(document, window, figureText(), figureSize, FIGURE_SUFFIX)) },
    null,
    { icon: icon('print'), label: ui.print, action: () => window.print() },
  ]);

  // 最大化：図の枠（操作の列・描画領域・凡例）を画面いっぱいに広げる。Esc でも戻す。
  let maximized = false;
  const maximize = button(icon('maximize'), ui.maximize, () => setMaximized(!maximized));
  const setMaximized = (on) => {
    maximized = on;
    for (const element of [frame, document.documentElement]) {
      if (on) element.setAttribute('data-maximized', '');
      else element.removeAttribute('data-maximized');
    }
    const label = on ? ui.restore : ui.maximize;
    maximize.replaceChildren(icon(on ? 'restore' : 'maximize'));
    maximize.setAttribute('aria-label', label);
    maximize.setAttribute('title', label);
    zoom.setFill(on);
  };
  // メニューを閉じる・強調の固定をやめるのに使われた Esc（defaultPrevented）では戻さない。
  window.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || event.defaultPrevented || !maximized) return;
    event.preventDefault();
    setMaximized(false);
  });

  toolbar.append(
    html(document, 'div', { class: 'lt-toolbar-group', role: 'group', 'aria-label': ui.zoom }, [zoomOut, level, zoomIn, fit, actualSize]),
    html(document, 'div', { class: 'lt-toolbar-title', 'aria-hidden': 'true' }, title),
    html(document, 'div', { class: 'lt-toolbar-group', role: 'group', 'aria-label': ui.view }, [status, saveMenu, theme, maximize]),
  );

  const disable = (element, disabled) => element.setAttribute('aria-disabled', String(disabled));
  const below = () => (legend ? legend.getBoundingClientRect().height ?? 0 : 0);
  zoom = setupZoom(window, viewport, svg, size, ({ scale, fitted, range }) => {
    level.textContent = `${Math.round(scale * 100)}%`;
    disable(zoomOut, scale <= range.min + 1e-6);
    disable(zoomIn, scale >= range.max - 1e-6);
    disable(fit, fitted);
    disable(actualSize, Math.abs(scale - 1) < 1e-6);
  }, { below });
}

/**
 * ボタンを押すと開く、小さなメニュー。items は { icon, label, action }。null の所には区切り線を入れる。
 * 項目を選ぶ・メニューの外を押す・Esc・Tab で閉じる。開いたときは最初の項目にフォーカスし、上下の矢印キーで移る。
 */
function menu(document, window, content, label, items) {
  const toggle = html(document, 'button', {
    type: 'button', class: 'lt-button lt-tool', 'aria-label': label, title: label, 'aria-haspopup': 'menu', 'aria-expanded': 'false',
  }, content);
  const children = items.map((item) => (item
    ? html(document, 'button', { type: 'button', class: 'lt-menu-item', role: 'menuitem', tabindex: '-1' }, [item.icon, item.label])
    : html(document, 'div', { class: 'lt-menu-separator', role: 'separator' })));
  const entries = children.filter((child, i) => items[i]);
  const actions = items.filter(Boolean);
  const list = html(document, 'div', { class: 'lt-menu', role: 'menu', 'aria-label': label }, children);
  list.hidden = true;
  const wrapper = html(document, 'div', { class: 'lt-menu-wrap' }, [toggle, list]);

  const setOpen = (open, { focus = true } = {}) => {
    list.hidden = !open;
    toggle.setAttribute('aria-expanded', String(open));
    if (open) entries[0].focus?.();
    else if (focus) toggle.focus?.();
  };
  toggle.addEventListener('click', () => setOpen(list.hidden));
  entries.forEach((entry, i) => entry.addEventListener('click', () => {
    setOpen(false);
    actions[i].action();
  }));
  wrapper.addEventListener('keydown', (event) => {
    if (list.hidden) return;
    const index = entries.indexOf(document.activeElement);
    const move = { ArrowDown: 1, ArrowUp: -1 }[event.key];
    if (move) {
      event.preventDefault();
      entries[(index + move + entries.length) % entries.length].focus?.();
    } else if (event.key === 'Escape') {
      event.preventDefault();
      setOpen(false);
    } else if (event.key === 'Tab') {
      setOpen(false, { focus: false });
    }
  });
  window.addEventListener('pointerdown', (event) => {
    if (!list.hidden && !contains(wrapper, event.target)) setOpen(false, { focus: false });
  });
  return wrapper;
}

// node が ancestor の中（ancestor 自身を含む）にあるか。
function contains(ancestor, node) {
  for (let current = node; current; current = current.parentNode) {
    if (current === ancestor) return true;
  }
  return false;
}

// 凡例。図の枠の下段に置く（最大化しても見えるように）。項目がなければ（凡例を出さない図も）出さない。
// 部品の種類（icon）は種類の色の四角に記号を入れ、線や枠の種類（sample）は見本の SVG をそのまま出す。
// 種類の色は、項目の className（なければ .lt-kind-<key>。部品の種類）の CSS で決まる。
function legendBar(document, items, ui) {
  if (items.length === 0) return null;
  const list = html(document, 'ul', { class: 'lt-legend', 'aria-label': ui.legend }, items.map((item) => (item.sample
    ? html(document, 'li', { class: 'lt-legend-style' }, [html(document, 'span', { class: 'lt-sample' }, [toDom(item.sample, document)]), item.label])
    : html(document, 'li', { class: item.className ?? `lt-kind-${item.key}` }, [swatch(document, item.icon), item.label]))));
  return html(document, 'div', { class: 'lt-legend-bar' }, [list]);
}

// 説明カード。kind を指定したカードは、見出しにその種類の色と記号の印を付ける。
// 色のクラスは図の種類の kindClass（workflow の手順・lifecycle の状態）、なければ部品の種類の .lt-kind-<種類>。
function showNotes(document, container, notes, type, ui) {
  const cards = notes.map((note) => {
    const icon = note.kind ? type.icon(note.kind) : null;
    const heading = html(document, 'h2', {}, [icon ? swatch(document, icon) : null, note.title]);
    const items = html(document, 'ul', {}, note.items.map((item) => html(document, 'li', {}, item)));
    const kindClass = type.kindClass ?? ((kind) => `lt-kind-${kind}`);
    return html(document, 'section', { class: `lt-note${icon ? ` ${kindClass(note.kind)}` : ''}` }, [heading, items]);
  });
  container.append(html(document, 'div', { class: 'lt-notes', 'aria-label': ui.notes }, cards));
}

// 種類の記号を、種類の色の小さな四角に入れたもの。
function swatch(document, icon) {
  const svg = toDom(el('svg', { width: 14, height: 14, viewBox: '0 0 14 14', 'aria-hidden': 'true' }, icon), document);
  return html(document, 'span', { class: 'lt-swatch' }, [svg]);
}

// 問題の一覧。エラーがあれば開いた状態で出し、図は出さない。警告だけなら閉じた状態で出す。
function showProblems(document, container, report, ui) {
  const problems = [
    ...report.errors.map((item) => ({ ...item, severity: 'error' })),
    ...report.warnings.map((item) => ({ ...item, severity: 'warning' })),
  ];
  if (problems.length === 0) return;
  const hasErrors = report.errors.length > 0;
  const list = html(document, 'ol', { class: 'lt-problem-list' }, problems.map((problem) => {
    const meta = [
      problem.target.length > 0 ? `${ui.target}: ${problem.target.join(', ')}` : null,
      `${ui.code}: `,
    ].filter(Boolean);
    return html(document, 'li', { class: 'lt-problem' }, [
      html(document, 'div', {}, [
        html(document, 'span', { class: `lt-badge lt-badge-${problem.severity}` }, ui[problem.severity]),
        problem.message,
      ]),
      html(document, 'p', { class: 'lt-meta' }, [meta.join('　'), html(document, 'code', {}, problem.code)]),
      problem.fixes.length > 0 ? html(document, 'p', { class: 'lt-meta' }, `${ui.fixes}:`) : null,
      problem.fixes.length > 0 ? html(document, 'ul', { class: 'lt-fixes' }, problem.fixes.map((fix) => html(document, 'li', {}, fix))) : null,
    ]);
  }));
  const details = html(document, 'details', { class: 'lt-problems', 'data-has-errors': hasErrors ? '' : null }, [
    html(document, 'summary', {}, ui.summary(report.errors.length, report.warnings.length)),
    hasErrors ? html(document, 'p', { class: 'lt-lead' }, ui.cannotDraw) : null,
    list,
  ]);
  details.open = hasErrors;
  container.append(details);
}

// HTML の要素を作る。children の文字列は文字のノードにする。属性の値が null なら付けない。
function html(document, tag, attrs = {}, children = []) {
  const element = document.createElement(tag);
  for (const [name, value] of Object.entries(attrs)) {
    if (value !== null && value !== undefined) element.setAttribute(name, value);
  }
  for (const child of Array.isArray(children) ? children : [children]) {
    if (child === null || child === undefined) continue;
    element.append(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return element;
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') start(document, window);
