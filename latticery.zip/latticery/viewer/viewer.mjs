// 閲覧画面の動き（ブラウザ用）。雛形 HTML に埋め込んだ JSON を読み、検証・配置・描画をして表示する。
// 処理はコマンドと同じ core/check.mjs を使う（共通仕様「6. 処理の段階」）。
// 利用者の文字は textContent と属性だけで入れ、innerHTML は使わない（共通仕様「9. 出力 HTML」）。

import { analyzeSource } from '../core/check.mjs';
import { LANGS } from '../core/i18n.mjs';
import { createTypes } from '../core/registry.mjs';
import { el, toDom } from '../core/svg.mjs';
import { savePng, saveSvg } from './export.mjs';
import { setupZoom } from './zoom.mjs';

// 固定の文言。
export const UI = {
  ja: {
    toDark: 'ダーク表示にする',
    toLight: 'ライト表示にする',
    legend: '凡例',
    notes: '説明',
    error: 'エラー',
    warning: '警告',
    summary: (errors, warnings) => [errors > 0 ? `エラー ${errors} 件` : '', warnings > 0 ? `警告 ${warnings} 件` : ''].filter(Boolean).join('・'),
    cannotDraw: 'エラーがあるため、図を表示できません。次の問題を直してください。',
    target: '対象',
    code: 'コード',
    fixes: '直し方の候補',
    noData: '図のデータが入っていません。latticery の build で、JSON を入れた HTML を作ってください。',
    viewport: '図の表示領域。ドラッグか矢印キーで移動、Ctrl（Mac は ⌘）を押しながらのホイールか ＋ − のキーで拡大・縮小、0 のキーで全体を表示',
    zoom: '拡大・縮小',
    zoomOut: '縮小',
    zoomIn: '拡大',
    fit: '全体を表示',
    actualSize: '100% で表示',
    exportTools: '書き出し',
    saveSvg: 'SVG で保存',
    savePng: 'PNG で保存',
    print: '印刷',
    exportFailed: '画像を書き出せませんでした。',
  },
  en: {
    toDark: 'Switch to dark',
    toLight: 'Switch to light',
    legend: 'Legend',
    notes: 'Notes',
    error: 'Error',
    warning: 'Warning',
    summary: (errors, warnings) => [
      errors > 0 ? `${errors} error${errors === 1 ? '' : 's'}` : '',
      warnings > 0 ? `${warnings} warning${warnings === 1 ? '' : 's'}` : '',
    ].filter(Boolean).join(', '),
    cannotDraw: 'The diagram cannot be drawn because of errors. Fix the problems below.',
    target: 'Target',
    code: 'Code',
    fixes: 'Possible fixes',
    noData: 'This file has no diagram data. Use latticery build to create an HTML file from a JSON file.',
    viewport: 'Diagram area. Drag or use the arrow keys to move. Use Ctrl (⌘ on Mac) with the mouse wheel, or the + and - keys, to zoom. Press 0 to fit.',
    zoom: 'Zoom',
    zoomOut: 'Zoom out',
    zoomIn: 'Zoom in',
    fit: 'Fit to window',
    actualSize: 'Actual size (100%)',
    exportTools: 'Export',
    saveSvg: 'Save SVG',
    savePng: 'Save PNG',
    print: 'Print',
    exportFailed: 'Could not export the image.',
  },
};

// ブラウザの言語設定（ja-JP など）から、対応している言語を選ぶ。
export function browserLang(languages) {
  return (languages ?? []).map((tag) => String(tag).toLowerCase().split('-')[0]).find((lang) => LANGS.includes(lang));
}

// 雛形にデータがまだ入っていないか（置き換えの目印の行が残っているか）。
// 置き換えの目印をこのファイルにそのまま書くと、まとめたスクリプトの中も置き換えられてしまうので、分けて書く。
export function isEmptyTemplate(source) {
  return source.trim() === ['__LATTICERY', 'DATA__'].join('_');
}

/** 閲覧画面を組み立てる。document・window はブラウザのもの。 */
export function start(document, window) {
  const $ = (id) => document.getElementById(id);
  const source = $('latticery-data').textContent;
  const types = createTypes(JSON.parse($('latticery-schemas').textContent));
  const fallbackLang = browserLang(window.navigator.languages ?? [window.navigator.language]);

  if (isEmptyTemplate(source)) {
    const lang = fallbackLang ?? 'en';
    setupPage(document, window, lang, null);
    $('lt-problems').append(html(document, 'p', { class: 'lt-lead' }, UI[lang].noData));
    return;
  }

  const { report, layout, doc, lang } = analyzeSource(source, types, { fallbackLang });
  setupPage(document, window, lang, doc);
  showProblems(document, $('lt-problems'), report, UI[lang]);
  if (!layout) return;

  const type = types[doc.type];
  const svg = toDom(type.render(layout, doc), document);
  const viewport = html(document, 'div', { class: 'lt-viewport', tabindex: '0', role: 'group', 'aria-label': UI[lang].viewport }, [svg]);
  $('lt-figure').append(viewport);
  fitText(svg);
  if (doc.legend !== false) showLegend(document, $('lt-legend'), type.legend(doc, lang), UI[lang]);
  if (doc.notes) showNotes(document, $('lt-notes'), doc.notes, type, UI[lang]);
  // 描画領域の大きさは、凡例と説明カードまで入れてから測る。
  showToolbar(document, window, $('lt-toolbar'), viewport, svg, { width: layout.width, height: layout.height }, UI[lang]);
}

// 言語・タイトル・説明・テーマの切り替えボタン。
function setupPage(document, window, lang, doc) {
  const ui = UI[lang];
  document.documentElement.lang = lang;
  if (doc && typeof doc.title === 'string') {
    document.title = doc.title;
    document.getElementById('lt-title').textContent = doc.title;
  }
  if (doc && typeof doc.description === 'string') {
    const description = document.getElementById('lt-description');
    description.textContent = doc.description;
    description.hidden = false;
  }

  // テーマの初期値は OS の設定に従う。ボタンで切り替えた後は、その選択を保つ。
  // 印刷の間はライトにする（ダークの明るい文字は、白い紙では読めないため）。
  const root = document.documentElement;
  const button = document.getElementById('lt-theme');
  const media = window.matchMedia ? window.matchMedia('(prefers-color-scheme: dark)') : null;
  let chosen = null;
  let printing = false;
  const apply = () => {
    const theme = printing ? 'light' : chosen ?? (media && media.matches ? 'dark' : 'light');
    root.setAttribute('data-theme', theme);
    button.textContent = theme === 'dark' ? ui.toLight : ui.toDark;
  };
  button.addEventListener('click', () => {
    chosen = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    apply();
  });
  if (media && media.addEventListener) media.addEventListener('change', apply);
  window.addEventListener('beforeprint', () => { printing = true; apply(); });
  window.addEventListener('afterprint', () => { printing = false; apply(); });
  apply();
  button.hidden = false;
}

// ブラウザで実際の文字の幅を測り、見積もり（data-width）を超えた文字だけを見積もりの幅に詰める。
// 配置は見積もりのまま変えない（共通仕様「10. 見た目」）。
function fitText(svg) {
  for (const text of svg.querySelectorAll('text[data-width]')) {
    const estimate = Number(text.getAttribute('data-width'));
    if (text.getComputedTextLength() > estimate) {
      text.setAttribute('textLength', estimate);
      text.setAttribute('lengthAdjust', 'spacingAndGlyphs');
    }
  }
}

// 図の上の操作の列：拡大・縮小のボタンと拡大率の表示、書き出しと印刷のボタン。
// 押しても何も変わらないボタンは aria-disabled にする（disabled にすると、押した直後にフォーカスが外れるため）。
function showToolbar(document, window, toolbar, viewport, svg, size, ui) {
  const button = (label, action, attrs = {}) => {
    const element = html(document, 'button', { type: 'button', class: 'lt-button', ...attrs }, label);
    element.addEventListener('click', () => {
      if (element.getAttribute('aria-disabled') !== 'true') action();
    });
    return element;
  };
  let zoom = null;
  const zoomOut = button('−', () => zoom.zoomOut(), { 'aria-label': ui.zoomOut, title: ui.zoomOut });
  const level = html(document, 'span', { class: 'lt-zoom-level' });
  const zoomIn = button('+', () => zoom.zoomIn(), { 'aria-label': ui.zoomIn, title: ui.zoomIn });
  const fit = button(ui.fit, () => zoom.fit());
  const actualSize = button('100%', () => zoom.actualSize(), { 'aria-label': ui.actualSize, title: ui.actualSize });

  const status = html(document, 'span', { class: 'lt-status', role: 'status' });
  const exporting = (save) => async () => {
    status.textContent = '';
    try {
      await save();
    } catch {
      status.textContent = ui.exportFailed;
    }
  };
  const saveSvgButton = button(ui.saveSvg, exporting(() => saveSvg(document, window, svg)));
  const savePngButton = button(ui.savePng, exporting(() => savePng(document, window, svg, size)));
  const print = button(ui.print, () => window.print());

  toolbar.append(
    html(document, 'div', { class: 'lt-toolbar-group', role: 'group', 'aria-label': ui.zoom }, [zoomOut, level, zoomIn, fit, actualSize]),
    html(document, 'div', { class: 'lt-toolbar-group', role: 'group', 'aria-label': ui.exportTools }, [status, saveSvgButton, savePngButton, print]),
  );
  toolbar.hidden = false;

  const disable = (element, disabled) => element.setAttribute('aria-disabled', String(disabled));
  zoom = setupZoom(window, viewport, svg, size, ({ scale, fitted, range }) => {
    level.textContent = `${Math.round(scale * 100)}%`;
    disable(zoomOut, scale <= range.min + 1e-6);
    disable(zoomIn, scale >= range.max - 1e-6);
    disable(fit, fitted);
    disable(actualSize, Math.abs(scale - 1) < 1e-6);
  });
}

function showLegend(document, container, items, ui) {
  if (items.length === 0) return;
  const list = html(document, 'ul', { class: 'lt-legend', 'aria-label': ui.legend },
    items.map((item) => html(document, 'li', { class: `lt-kind-${item.key}` }, [swatch(document, item.icon), item.label])));
  container.append(list);
}

// 説明カード。kind を指定したカードは、見出しにその種類の色と記号の印を付ける。
function showNotes(document, container, notes, type, ui) {
  const cards = notes.map((note) => {
    const icon = note.kind ? type.icon(note.kind) : null;
    const heading = html(document, 'h2', {}, [icon ? swatch(document, icon) : null, note.title]);
    const items = html(document, 'ul', {}, note.items.map((item) => html(document, 'li', {}, item)));
    return html(document, 'section', { class: `lt-note${icon ? ` lt-kind-${note.kind}` : ''}` }, [heading, items]);
  });
  container.append(html(document, 'div', { class: 'lt-notes', 'aria-label': ui.notes }, cards));
}

// 種類の記号を、種類の色の小さな四角に入れたもの。
function swatch(document, icon) {
  const svg = toDom(el('svg', { width: 14, height: 14, viewBox: '0 0 14 14', 'aria-hidden': 'true' }, icon), document);
  return html(document, 'span', { class: 'lt-swatch' }, [svg]);
}

// 問題の一覧。エラーがあれば開いた状態で出し、図は出さない。警告だけなら閉じた状態で出す。
function showProblems(document, container, report, ui) {
  const problems = [
    ...report.errors.map((item) => ({ ...item, severity: 'error' })),
    ...report.warnings.map((item) => ({ ...item, severity: 'warning' })),
  ];
  if (problems.length === 0) return;
  const hasErrors = report.errors.length > 0;
  const list = html(document, 'ol', { class: 'lt-problem-list' }, problems.map((problem) => {
    const meta = [
      problem.target.length > 0 ? `${ui.target}: ${problem.target.join(', ')}` : null,
      `${ui.code}: `,
    ].filter(Boolean);
    return html(document, 'li', { class: 'lt-problem' }, [
      html(document, 'div', {}, [
        html(document, 'span', { class: `lt-badge lt-badge-${problem.severity}` }, ui[problem.severity]),
        problem.message,
      ]),
      html(document, 'p', { class: 'lt-meta' }, [meta.join('　'), html(document, 'code', {}, problem.code)]),
      problem.fixes.length > 0 ? html(document, 'p', { class: 'lt-meta' }, `${ui.fixes}:`) : null,
      problem.fixes.length > 0 ? html(document, 'ul', { class: 'lt-fixes' }, problem.fixes.map((fix) => html(document, 'li', {}, fix))) : null,
    ]);
  }));
  const details = html(document, 'details', { class: 'lt-problems', 'data-has-errors': hasErrors ? '' : null }, [
    html(document, 'summary', {}, ui.summary(report.errors.length, report.warnings.length)),
    hasErrors ? html(document, 'p', { class: 'lt-lead' }, ui.cannotDraw) : null,
    list,
  ]);
  details.open = hasErrors;
  container.append(details);
}

// HTML の要素を作る。children の文字列は文字のノードにする。属性の値が null なら付けない。
function html(document, tag, attrs = {}, children = []) {
  const element = document.createElement(tag);
  for (const [name, value] of Object.entries(attrs)) {
    if (value !== null && value !== undefined) element.setAttribute(name, value);
  }
  for (const child of Array.isArray(children) ? children : [children]) {
    if (child === null || child === undefined) continue;
    element.append(typeof child === 'string' ? document.createTextNode(child) : child);
  }
  return element;
}

if (typeof document !== 'undefined' && typeof window !== 'undefined') start(document, window);
