// 閲覧画面の拡大・縮小と移動（共通仕様「9. 出力 HTML」の「拡大・縮小と移動」、決定記録 No.44）。
// 図の SVG を描画領域（viewport）の中に置き、表示の大きさ（style の width・height）と位置（transform）だけを変える。
// SVG の中身・viewBox・width と height の属性は変えない（書き出しは 100% の大きさで行うため）。
// style は CSSOM で変える。CSP で style 属性（'unsafe-inline'）を許していないため。

// ＋−のボタンで変える段階。ブラウザのズームと同じような値にする。
export const ZOOM_STEPS = [0.25, 0.33, 0.5, 0.67, 0.75, 0.8, 0.9, 1, 1.1, 1.25, 1.5, 1.75, 2, 2.5, 3, 4];
export const MAX_SCALE = 4;

export const MAX_HEIGHT = 720; // 描画領域の高さの上限（幅の上限 1280px は theme.css で決める。決定記録 No.57）
const MIN_HEIGHT = 240; // 描画領域の高さの下限（画面がとても低いとき）
const BOTTOM_GAP = 24; // 開いたときの画面の下端と、図の枠の下の間
const KEY_STEP = 48; // 矢印キー1回で動かす量（px）
const WHEEL_RATE = 1 / 500; // ホイールの移動量 1px あたりの拡大率の変化（指数）
const EPSILON = 1e-6;

const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

/** 図全体が描画領域に収まる拡大率。領域より小さい図は拡大しない（100% のまま）。 */
export function fitScale(size, area) {
  if (!(area.width > 0) || !(area.maxHeight > 0)) return 1;
  return Math.min(1, area.width / size.width, area.maxHeight / size.height);
}

/** 拡大率の範囲。下限は「全体を表示」の率と 25% のうち小さいほう。 */
export function scaleRange(fit) {
  return { min: Math.min(fit, ZOOM_STEPS[0]), max: MAX_SCALE };
}

/** ＋（direction が 1）・−（-1）で次に選ぶ拡大率。段階の外へは、範囲の端まで動く。 */
export function stepScale(scale, direction, range) {
  const next = direction > 0
    ? ZOOM_STEPS.find((step) => step > scale + EPSILON)
    : [...ZOOM_STEPS].reverse().find((step) => step < scale - EPSILON);
  return clamp(next ?? (direction > 0 ? range.max : range.min), range.min, range.max);
}

/**
 * 図の位置（描画領域の左上からのずれ）。図が領域より小さい向きは中央に置き、
 * 大きい向きは、領域に空きが出ない範囲に収める（図が領域の外へ出きらない）。
 */
export function clampOffset(offset, content, area) {
  if (content <= area) return (area - content) / 2;
  return clamp(offset, area - content, 0);
}

/** 描画領域の高さ。拡大すると上限（画面に収まる分）まで伸び、縮小しても「全体を表示」のときより低くしない。 */
export function areaHeight(height, scale, fit, maxHeight) {
  return Math.ceil(Math.min(maxHeight, height * Math.max(scale, fit)));
}

/** 描画領域の中の点 point を動かさずに、拡大率を from から to に変えたときの図の位置。 */
export function zoomAround(offset, point, from, to) {
  return point - (point - offset) * (to / from);
}

/**
 * 描画領域に、拡大・縮小と移動の操作を付ける。size は図の 100% の大きさ（{ width, height }）。
 * onChange は、表示が変わるたびに { scale, fitted, range } を受け取る（ボタンの表示の更新に使う）。
 * below() は、描画領域の下にあって、開いたときに画面に収めたいものの高さ（図の枠の中の凡例など）。
 * 返り値のメソッドは、ボタンから呼ぶ。setFill(true) にすると、描画領域の高さを CSS に任せ（最大化のとき）、
 * その大きさいっぱいに使う。切り替えると、全体を表示し直す。
 */
export function setupZoom(window, viewport, svg, size, onChange = () => {}, { below = () => 0 } = {}) {
  const view = { scale: 1, x: 0, y: 0, fit: 1, fitted: true, maxHeight: MIN_HEIGHT, height: 0, fill: false };
  // 図の 100% の幅。印刷のときに用紙の幅へ合わせるのに使う（theme.css）。
  viewport.style.setProperty('--lt-width', `${size.width}px`);

  // 描画領域の高さの上限。ふだんは、開いたときに画面の下端まで収まる分と MAX_HEIGHT の小さいほう
  // （ページの位置で測るので、スクロールしても変わらない）。最大化のときは、CSS で決まった高さ。
  const measure = () => {
    if (view.fill) {
      viewport.style.height = '';
      view.maxHeight = Math.max(MIN_HEIGHT, viewport.clientHeight);
    } else {
      const top = viewport.getBoundingClientRect().top + (window.scrollY ?? 0);
      view.maxHeight = Math.min(MAX_HEIGHT, Math.max(MIN_HEIGHT, window.innerHeight - top - below() - BOTTOM_GAP));
    }
    view.fit = fitScale(size, { width: viewport.clientWidth, maxHeight: view.maxHeight });
  };

  const pannable = () => size.width * view.scale > viewport.clientWidth + 0.5 || size.height * view.scale > view.height + 0.5;

  const render = () => {
    const range = scaleRange(view.fit);
    view.scale = clamp(view.scale, range.min, range.max);
    const width = size.width * view.scale;
    const height = size.height * view.scale;
    view.height = view.fill ? view.maxHeight : areaHeight(size.height, view.scale, view.fit, view.maxHeight);
    view.x = clampOffset(view.x, width, viewport.clientWidth);
    view.y = clampOffset(view.y, height, view.height);
    viewport.style.height = `${view.height}px`;
    svg.style.width = `${width}px`;
    svg.style.height = `${height}px`;
    svg.style.transform = `translate(${Math.round(view.x)}px, ${Math.round(view.y)}px)`;
    if (pannable()) viewport.setAttribute('data-pannable', '');
    else viewport.removeAttribute('data-pannable');
    onChange({ scale: view.scale, fitted: view.fitted, range });
  };

  const fit = () => {
    measure();
    view.scale = view.fit;
    view.fitted = true;
    render();
  };

  // point を省くと、描画領域の中央を中心に拡大・縮小する。
  const zoomTo = (scale, point = { x: viewport.clientWidth / 2, y: view.height / 2 }) => {
    const range = scaleRange(view.fit);
    const to = clamp(scale, range.min, range.max);
    view.x = zoomAround(view.x, point.x, view.scale, to);
    view.y = zoomAround(view.y, point.y, view.scale, to);
    view.scale = to;
    view.fitted = Math.abs(to - view.fit) < EPSILON;
    render();
  };
  const step = (direction) => zoomTo(stepScale(view.scale, direction, scaleRange(view.fit)));

  const pointOf = (event) => {
    const rect = viewport.getBoundingClientRect();
    return { x: event.clientX - rect.left - (viewport.clientLeft ?? 0), y: event.clientY - rect.top - (viewport.clientTop ?? 0) };
  };

  // Ctrl（Mac は ⌘）を押しながらのホイールと、トラックパッドのピンチ（ブラウザは Ctrl 付きのホイールとして送る）で拡大・縮小する。
  // ホイールだけならページをスクロールする。Safari のピンチは gesture のイベントで来るので、そちらも受ける。
  let gesture = null;
  viewport.addEventListener('wheel', (event) => {
    if (!(event.ctrlKey || event.metaKey) || gesture !== null) return;
    event.preventDefault();
    const unit = event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? view.height : 1;
    zoomTo(view.scale * Math.exp(-event.deltaY * unit * WHEEL_RATE), pointOf(event));
  }, { passive: false });
  viewport.addEventListener('gesturestart', (event) => {
    event.preventDefault();
    gesture = view.scale;
  });
  viewport.addEventListener('gesturechange', (event) => {
    if (gesture === null) return;
    event.preventDefault();
    zoomTo(gesture * event.scale, pointOf(event));
  });
  viewport.addEventListener('gestureend', () => { gesture = null; });

  // ドラッグ（指でも）で動かす。図が領域に収まっているときは動かさない。
  let drag = null;
  viewport.addEventListener('pointerdown', (event) => {
    if (event.button !== 0 || !pannable()) return;
    drag = { id: event.pointerId, x: event.clientX - view.x, y: event.clientY - view.y };
    viewport.setAttribute('data-dragging', '');
    // 領域の外へ出ても動かし続けられるよう、ポインターを捕まえる。捕まえられなくても、ドラッグは続ける。
    try {
      viewport.setPointerCapture(event.pointerId);
    } catch {
      // 合成したイベントなど、ポインターが押されていないときは捕まえられない。
    }
  });
  viewport.addEventListener('pointermove', (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    view.x = event.clientX - drag.x;
    view.y = event.clientY - drag.y;
    render();
  });
  const endDrag = (event) => {
    if (!drag || event.pointerId !== drag.id) return;
    drag = null;
    viewport.removeAttribute('data-dragging');
  };
  viewport.addEventListener('pointerup', endDrag);
  viewport.addEventListener('pointercancel', endDrag);

  // 描画領域にフォーカスがあるとき：矢印キーで移動、＋−で拡大・縮小、0 で全体を表示。
  // 動かせない向きの矢印キーは、ページのスクロールに任せる。Ctrl などとの組み合わせはブラウザに任せる。
  const MOVES = { ArrowLeft: [1, 0], ArrowRight: [-1, 0], ArrowUp: [0, 1], ArrowDown: [0, -1] };
  viewport.addEventListener('keydown', (event) => {
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    if (event.key in MOVES) {
      const [dx, dy] = MOVES[event.key];
      const before = [view.x, view.y];
      view.x += dx * KEY_STEP;
      view.y += dy * KEY_STEP;
      render();
      if (view.x !== before[0] || view.y !== before[1]) event.preventDefault();
      return;
    }
    const action = { '+': () => step(1), '=': () => step(1), '-': () => step(-1), 0: fit }[event.key];
    if (!action) return;
    event.preventDefault();
    action();
  });

  // 画面の大きさが変わったとき、全体を表示したままなら合わせ直す。拡大・縮小した後は、その拡大率を保つ。
  window.addEventListener('resize', () => {
    measure();
    if (view.fitted) view.scale = view.fit;
    render();
  });

  fit();
  const setFill = (on) => {
    view.fill = on;
    fit();
  };
  return { zoomIn: () => step(1), zoomOut: () => step(-1), fit, actualSize: () => zoomTo(1), setFill };
}
